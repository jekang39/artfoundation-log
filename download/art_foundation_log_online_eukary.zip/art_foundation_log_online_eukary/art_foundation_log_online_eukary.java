/* 
 * Licensed to the Apache Software Foundation (ASF) under one or more

 *  contributor license agreements.  See the NOTICE file distributed with
 *  this work for additional information regarding copyright ownership.
 *  The ASF licenses this file to You under the Apache License, Version 2.0
 *  (the "License"); you may not use this file except in compliance with
 *  the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 * 
 */
import java.io.*;
import java.util.*;
import java.text.SimpleDateFormat;
import java.util.regex.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.apache.commons.io.IOUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.math3.util.MathArrays;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;
import org.apache.commons.math3.stat.clustering.*;
import org.apache.commons.math3.stat.StatUtils;
import org.apache.commons.math3.exception.*;
import org.apache.commons.math3.stat.correlation.*;
import org.apache.commons.math3.stat.inference.TestUtils;
import org.apache.commons.math3.stat.inference.MannWhitneyUTest;
import org.apache.commons.math3.util.Combinations;
///home/centos2/ should be replaced with your directory path in your computer 
///home/centos2/java/jdk-11.0.17_linux-x64_bin.tar-1/jdk-11.0.17/bin/javac -nowarn -cp .:lib/commons-io-2.11.0.jar:lib/commons-math3-3.6.1.jar:lib/commons-lang3-3.12.0.jar:lib/commons-collections4-4.4.jar:lib/commons-lang3-3.12.0.jar art_foundation_log_online_eukary.java
///home/centos2/java/jdk-11.0.17_linux-x64_bin.tar-1/jdk-11.0.17/bin/java -cp .:lib/commons-io-2.11.0.jar:lib/commons-math3-3.6.1.jar:lib/commons-lang3-3.12.0.jar:lib/commons-collections4-4.4.jar:lib/commons-lang3-3.12.0.jar art_foundation_log_online_eukary >out_art_foundation_log_online_eukary2

/*prepare AI/stat input files based on seven modules of art_foundation_log*/


public class  art_foundation_log_online_eukary {
    

public static void main(String[] args) throws IOException,InterruptedException,Exception{

      //instantiate main
      art_foundation_log_online_eukary aa = new art_foundation_log_online_eukary();

      //instantiate inner class ddi interface  
	art_foundation_log_online_eukary.ddi_interface_module ddi_inter = new art_foundation_log_online_eukary.ddi_interface_module();

      //instantiate inner class oligomerization
    	art_foundation_log_online_eukary.oligomerization_module oligomerization = new art_foundation_log_online_eukary.oligomerization_module();

      //instantiate inner class llps_go_analysis
    	art_foundation_log_online_eukary.llps_go_analysis  llps_go = new art_foundation_log_online_eukary.llps_go_analysis();
	
      ////inner class functions
	llps_go.map_pdb_to_uniprot();

	oligomerization.make_multiple_oligo_pfams_flags();
	oligomerization.map_groupid_pfam();
	oligomerization.get_pdbid_one_uniprot();
	oligomerization.map_groupid_to_pdb();
	oligomerization.map_groupid_to_uniprot();

    	oligomerization.get_llps_uniprot();
	oligomerization.create_new_data_weka_input();
	ddi_inter.create_llps_list();
	ddi_inter.do_three_did_comp();
	ddi_inter.map_interpro_pfam();
	
	

	llps_go.map_pfam_clans_only();
	llps_go.map_sifts_pdb_pfam();

	
	llps_go.map_repeat_pfam();
	llps_go.map_binding_pfam();
	llps_go.get_interpro_binding();
	llps_go.map_drllps_to_type_conden_freq();

	
       ////inner functions end

       /////main class functions//////
	aa.map_pfam_to_eukary_gene();
       aa.combine_log("data/input_list");
     


 }

//if you want to use the program with your own eukaryotic species, you need to have a map file that contains gene and pfam assignment in the following format. gene name can not have space.
//AT1G01030:[PF02362]
//AT1G01040:[PF00035, PF00271, PF00636, PF02170, PF04851, PF14622]
//or
//AT1G01030:PF02362
//AT1G01040:PF00035, PF00271, PF00636, PF02170, PF04851, PF14622
    
LinkedHashMap<String,LinkedList<String>> eukary_to_pfam;
LinkedHashMap<LinkedList<String>,LinkedList<String>> nr_pfam_to_eukary;
LinkedList<LinkedList<String>> pfam_eukary_gene_list;
 
 void map_pfam_to_eukary_gene() throws IOException{

 	System.out.println("map_pfam_to_eukary_gene()" );
 
	Pattern space_pattern = Pattern.compile("\\s+");
	Pattern tab_pattern = Pattern.compile("\\t+");
	Pattern comma_pattern = Pattern.compile(",");
	Pattern colon_pattern = Pattern.compile(":");

	
	eukary_to_pfam= new LinkedHashMap();
	nr_pfam_to_eukary= new LinkedHashMap();
	pfam_eukary_gene_list= new LinkedList();

 
 	String path = "data/out_mix_interpro_genbank.final";
	//AT1G01030:[PF02362]
	//AT1G01040:[PF00035, PF00271, PF00636, PF02170, PF04851, PF14622]
	
	
	List<String> lines  = FileUtils.readLines(new File(path));
	
					
	for(int k = 0; k <lines.size(); k++){
				
		String one_line = lines.get(k);

		String[] colon_split = colon_pattern.split(one_line);
		String eukaryid = colon_split[0].trim();
		String pfamid = colon_split[1].trim();
		pfamid=pfamid.replaceAll("\\[","");
		pfamid=pfamid.replaceAll("\\]","");
		System.out.println("eukaryid:"+eukaryid);
		System.out.println("pfamid:"+pfamid);

		LinkedList<String> nr_pfam = new LinkedList();
		String[] comma_split = comma_pattern.split(pfamid);
		for(int i = 0; i < comma_split.length; i++){

			nr_pfam.add(comma_split[i].trim());
		}

		eukary_to_pfam.put(eukaryid,nr_pfam);

		//redundant
			
		Set<String> pfams_h_inv = new LinkedHashSet<>();
		pfams_h_inv.addAll((List)nr_pfam);
									
		// Clear the list
		((List)nr_pfam).clear();
															  
		// add the elements of set
		// with no duplicates to the list
		((List)nr_pfam).addAll(pfams_h_inv);
		Collections.sort((List)nr_pfam);
					

		if(nr_pfam_to_eukary.containsKey(nr_pfam)){
			
			LinkedList<String> exist = nr_pfam_to_eukary.get(nr_pfam);
				
			if(!exist.contains(eukaryid)){
				
				exist.add(eukaryid);
			}
				
			nr_pfam_to_eukary.put(nr_pfam, exist);
			
		}else{
			
			LinkedList<String> exist = new LinkedList();
				
			exist.add(eukaryid);
			nr_pfam_to_eukary.put(nr_pfam, exist);
		}
				
	}//k
		
	
	
	
	List<String> keys_list = new LinkedList<String>(eukary_to_pfam.keySet());
	
	for(int i = 0; i < keys_list.size(); i++){
	
		pfam_eukary_gene_list.add(eukary_to_pfam.get(keys_list.get(i)));
	}
	
	System.out.println("eukary_to_pfam.size():" + eukary_to_pfam.size());

	

}//method  




/**
* special flags.
*/
String[] nucl_inter_active_site_pfam = {"PF00074","PF00145","PF00233","PF00268","PF00334","PF00445","PF00521","PF00545","PF00548","PF00565","PF00589","PF00680","PF00730","PF00849","PF00929","PF00940","PF00947","PF01028","PF01035","PF01068","PF01131","PF01137","PF01142","PF01149","PF01150","PF01156","PF01223","PF01331","PF01416","PF01653","PF01663","PF01768","PF01829","PF01896","PF01974","PF02580","PF02852","PF02867","PF02923","PF02963","PF03013","PF03054","PF03099","PF03167","PF03372","PF04406","PF05014","PF05201","PF05202","PF05761","PF05881","PF05958","PF06087","PF06941","PF07992","PF09233","PF09414","PF09511","PF11969","PF12705"};
String[] active_site_minis_nucl_ppi_pfam = {"PF00016","PF00026","PF00042","PF00044","PF00061","PF00062","PF00068","Pllps_go_analysisF00069","PF00077","PF00082","PF00085","PF00089","PF00102","PF00106","PF00108","PF00109","PF00112","PF00113","PF00117","PF00121","PF00128","PF00132","PF00135","PF00141","PF00144","PF00148","PF00149","PF00150","PF00151","PF00155","PF00156","PF00161","PF00171","PF00179","PF00182","PF00185","PF00190","PF00194","PF00195","PF00198","PF00199","PF00206","PF00215","PF00221","PF00227","PF00231","PF00232","PF00234","PF00239","PF00245","PF00246","PF00248","PF00251","PF00255","PF00266","PF00274","PF00275","PF00278","PF00285","PF00290","PF00291","PF00293","PF00294","PF00295","PF00296","PF00300","PF00302","PF00303","PF00311","PF00326","PF00328","PF00331","PF00332","PF00342","PF00358","PF00359","PF00365","PF00367","PF00368","PF00378","PF00381","PF00383","PF00384","PF00388","PF00390","PF00391","PF00393","PF00407","PF00413","PF00425","PF00441","PF00443","PF00450","PF00457","PF00463","PF00478","PF00480","PF00490","PF00501","PF00549","PF00551","PF00557","PF00561","PF00574","PF00578","PF00581","PF00596","PF00632","PF00633","PF00648","PF00656","PF00657","PF00668","PF00675","PF00682","PF00685","PF00698","PF00701","PF00702","PF00704","PF00708","PF00709","PF00710","PF00716","PF00717","PF00719","PF00722","PF00723","PF00724","PF00728","PF00731","PF00755","PF00756","PF00759","PF00762","PF00768","PF00770","PF00781","PF00782","PF00795","PF00797","PF00799","PF00815","PF00817","PF00834","PF00837","PF00840","PF00842","PF00850","PF00851","PF00857","PF00863","PF00871","PF00877","PF00883","PF00884","PF00890","PF00891","PF00899","PF00903","PF00905","PF00925","PF00933","PF00949","PF00962","PF00975","PF00984","PF01008","PF01014","PF01019","PF01055","PF01063","PF01070","PF01081","PF01083","PF01087","PF01088","PF01095","PF01112","PF01116","PF01135","PF01144","PF01154","PF01163","PF01168","PF01174","PF01175","PF01177","PF01179","PF01180","PF01182","PF01183","PF01187","PF01206","PF01218","PF01220","PF01229","PF01230","PF01242","PF01255","PF01259","PF01261","PF01262","PF01263","PF01270","PF01274","PF01327","PF01328","PF01339","PF01341","PF01343","PF01361","PF01364","PF01370","PF01373","PF01374","PF01375","PF01379","PF01400","PF01401","PF01421","PF01425","PF01431","PF01432","PF01433","PF01435","PF01447","PF01451","PF01457","PF01464","PF01470","PF01485","PF01487","PF01494","PF01501","PF01509","PF01510","PF01513","PF01522","PF01532","PF01536","PF01538","PF01546","PF01547","PF01551","PF01553","PF01565","PF01569","PF01577","PF01583","PF01625","PF01636","PF01640","PF01641","PF01650","PF01661","PF01670","PF01674","PF01676","PF01678","PF01694","PF01707","PF01728","PF01734","PF01735","PF01738","PF01742","PF01747","PF01761","PF01764","PF01791","PF01804","PF01820","PF01828","PF01841","PF01853","PF01915","PF01916","PF01960","PF01965","PF01979","PF02011","PF02015","PF02016","PF02031","PF02055","PF02056","PF02057","PF02089","PF02099","PF02102","PF02113","PF02129","PF02137","PF02142","PF02146","PF02160","PF02163","PF02219","PF02230","PF02253","PF02255","PF02261","PF02267","PF02273","PF02275","PF02277","PF02283","PF02302","PF02317","PF02329","PF02338","PF02348","PF02374","PF02388","PF02395","PF02407","PF02423","PF02441","PF02449","PF02485","PF02504","PF02515","PF02543","PF02548","PF02551","PF02560","PF02567","PF02569","PF02570","PF02627","PF02635","PF02657","PF02675","PF02733","PF02737","PF02746","PF02763","PF02774","PF02776","PF02781","PF02788","PF02803","PF02805","PF02812","PF02816","PF02826","PF02836","PF02866","PF02868","PF02873","PF02878","PF02900","PF02901","PF02902","PF02907","PF02913","PF02917","PF02943","PF02962","PF02975","PF03031","PF03051","PF03061","PF03062","PF03065","PF03068","PF03070","PF03098","PF03150","PF03198","PF03290","PF03328","PF03360","PF03389","PF03403","PF03412","PF03416","PF03497","PF03510","PF03536","PF03543","PF03568","PF03571","PF03572","PF03573","PF03574","PF03575","PF03576","PF03610","PF03630","PF03632","PF03740","PF03767","PF03835","PF03987","PF03996","PF04072","PF04137","PF04358","PF04389","PF04413","PF04587","PF04616","PF04723","PF04734","PF04820","PF04843","PF04879","PF04909","PF04951","PF04952","PF04970","PF04996","PF05005","PF05023","PF05025","PF05028","PF05090","PF05173","PF05199","PF05222","PF05257","PF05343","PF05362","PF05381","PF05407","PF05408","PF05409","PF05410","PF05411","PF05412","PF05426","PF05448","PF05533","PF05543","PF05550","PF05572","PF05577","PF05690","PF05826","PF05840","PF05903","PF05935","PF06002","PF06026","PF06094","PF06110","PF06293","PF06314","PF06325","PF06602","PF06778","PF06964","PF07224","PF07470","PF07475","PF07476","PF07478","PF07479","PF07488","PF07555","PF07722","PF07737","PF07745","PF07819","PF07823","PF07859","PF07882","PF07910","PF07931","PF07977","PF07995","PF08124","PF08125","PF08282","PF08392","PF08501","PF08541","PF08545","PF08546","PF08694","PF08714","PF08840","PF08992","PF09009","PF09017","PF09093","PF09112","PF09113","PF09129","PF09206","PF09290","PF09338","PF09349","PF09411","PF09492","PF09768","PF10275","PF10282","PF10462","PF10566","PF10605","PF10620","PF11975","PF12146","PF12385","PF12387","PF12680","PF12695","PF12697","PF12710","PF12905","PF13088","PF13090","PF13091","PF13207","PF13279","PF13344","PF13354","PF13365","PF13378","PF13406","PF13409","PF13417","PF13419","PF13469","PF13472","PF13561","PF13574","PF13583","PF13688","PF14360","PF14370","PF14489","PF14496","PF14528","PF14566","PF14592","PF14684","PF14716","PF14754","PF14833","PF15499","PF16218","PF16363","PF16499","PF18438"};
String[] three_did_lig ={"PF00244","PF01257","PF00001","PF00004","PF00005","PF00583","PF08674","PF00022","PF16579","PF05641","PF12165","PF00266","PF01593","PF14828","PF04739","PF12895","PF00023","PF12796","PF00514","PF04729","PF00026","PF02991","PF00231","PF00430","PF00401","PF08517","PF01603","PF01426","PF00452","PF11502","PF17035","PF00653","PF03099","PF00533","PF03097","PF00439","PF02214","PF09270","PF07654","PF12265","PF02045","PF02762","PF02933","PF09079","PF15511","PF00307","PF09295","PF00504","PF00385","PF01393","PF04818","PF15800","PF05347","PF00118","PF12539","PF18392","PF00888","PF13621","PF00134","PF06058","PF01556","PF02767","PF02768","PF03604","PF05186","PF14671","PF07039","PF12180","PF03271","PF00036","PF12763","PF13499","PF13833","PF10163","PF01404","PF10447","PF09380","PF00373","PF03781","PF00498","PF17913","PF00147","PF00630","PF00039","PF00041","PF03623","PF13844","PF06212","PF00009","PF04670","PF00625","PF02213","PF13646","PF00125","PF16211","PF02301","PF00104","PF02793","PF00011","PF00012","PF04568","PF10480","PF01652","PF13895","PF00049","PF00362","PF00520","PF10401","PF02174","PF17811","PF02373","PF08007","PF01344","PF02172","PF03731","PF16672","PF01423","PF03194","PF02847","PF08923","PF00917","PF02820","PF04678","PF09637","PF05053","PF05891","PF00993","PF00969","PF04212","PF13012","PF03637","PF01618","PF00635","PF05712","PF00146","PF07555","PF05071","PF11577","PF03031","PF01592","PF02799","PF02898","PF02136","PF00213","PF00658","PF02671","PF01399","PF02747","PF00705","PF00341","PF00595","PF17820","PF00656","PF01433","PF00413","PF05193","PF01401","PF00628","PF08567","PF00640","PF00069","PF07714","PF17285","PF00235","PF00227","PF10584","PF04683","PF00160","PF12738","PF00806","PF00855","PF09311","PF11976","PF00071","PF01857","PF01030","PF08661","PF00072","PF16727","PF14622","PF02867","PF00428","PF01294","PF01775","PF01245","PF00828","PF01777","PF00327","PF08079","PF00573","PF00338","PF00253","PF00366","PF00833","PF00203","PF03297","PF00410","PF02197","PF01138","PF01193","PF04997","PF04983","PF04998","PF04560","PF03874","PF01192","PF03870","PF18261","PF00076","PF16770","PF01479","PF12209","PF01390","PF00995","PF03911","PF02556","PF00079","PF00856","PF00017","PF00018","PF07653","PF14604","PF03876","PF03145","PF02146","PF02731","PF07525","PF08286","PF00622","PF04722","PF05076","PF12470","PF02201","PF04433","PF16495","PF08231","PF00957","PF00804","PF15219","PF03849","PF00382","PF02291","PF00085","PF01833","PF00229","PF01751","PF00515","PF13414","PF13424","PF13176","PF13181","PF08558","PF00261","PF00992","PF00089","PF12148","PF00567","PF18104","PF06087","PF00240","PF02271","PF05743","PF03671","PF00021","PF12436","PF07686","PF17211","PF00790","PF01044","PF00092","PF00400","PF00568","PF00397","PF09280","PF17725","PF03366","PF00102","PF07496","PF02148"};
String[] dbd ={"PF00170","PF00319","PF00352","PF00382","PF00605","PF00808","PF01096","PF02045","PF02200","PF02467","PF03131","PF03153","PF03299","PF03529","PF03634","PF03849","PF03850","PF03957","PF04001","PF04082","PF04441","PF04516","PF04621","PF04640","PF04947","PF05687","PF05718","PF06331","PF06529","PF06546","PF06881","PF07500","PF07704","PF08164","PF08381","PF08474","PF08536","PF08574","PF08601","PF08618","PF08731","PF08744","PF08781","PF09114","PF09341","PF09734","PF09748","PF10163","PF10380","PF10406","PF10545","PF11262","PF11507","PF11521","PF11619","PF11951","PF12310","PF12336","PF12374","PF12443","PF12533","PF12598","PF12657","PF12660","PF13339","PF13453","PF13713","PF14215","PF15065","PF15317","PF15714","PF15791","PF16176","PF16421","PF16422","PF16423","PF16832","PF16833","PF17110","PF18307","PF18542","PF19536","PF20588"};
String[] ppi_phospho = {"PF00012","PF00013","PF00017","PF00018","PF00035","PF00042","PF00069","PF00091","PF00096","PF00097","PF00104","PF00106","PF00125","PF00130","PF00169","PF00174","PF00183","PF00225","PF00233","PF00240","PF00241","PF00307","PF00333","PF00388","PF00397","PF00400","PF00412","PF00439","PF00443","PF00454","PF00502","PF00505","PF00515","PF00520","PF00538","PF00552","PF00564","PF00566","PF00568","PF00595","PF00621","PF00622","PF00628","PF00632","PF00638","PF00640","PF00651","PF00702","PF00778","PF00780","PF00786","PF00787","PF00788","PF00789","PF00794","PF00808","PF00957","PF01044","PF01152","PF01163","PF01237","PF01302","PF01352","PF01368","PF01378","PF01390","PF01454","PF01465","PF01477","PF01504","PF01576","PF01633","PF01636","PF01699","PF02017","PF02138","PF02141","PF02174","PF02192","PF02196","PF02246","PF02269","PF02291","PF02309","PF02358","PF02392","PF02597","PF02736","PF02758","PF02816","PF02821","PF02824","PF02847","PF02876","PF02893","PF02932","PF02946","PF02958","PF02969","PF02991","PF03031","PF03109","PF03114","PF03144","PF03160","PF03217","PF03332","PF03368","PF03517","PF03525","PF03531","PF03540","PF03607","PF03658","PF03671","PF03703","PF03767","PF03770","PF03800","PF03801","PF03831","PF03847","PF03881","PF03953","PF03990","PF04098","PF04106","PF04110","PF04183","PF04319","PF04538","PF04655","PF04663","PF04683","PF04719","PF05116","PF05152","PF05236","PF05287","PF05445","PF05729","PF05761","PF05822","PF06017","PF06058","PF06071","PF06090","PF06107","PF06115","PF06173","PF06176","PF06232","PF06234","PF06251","PF06293","PF06294","PF06315","PF06347","PF06395","PF06458","PF06487","PF06565","PF06702","PF06713","PF06734","PF06805","PF06888","PF06941","PF07289","PF07387","PF07524","PF07563","PF07565","PF07653","PF07707","PF07714","PF07719","PF07804","PF07866","PF07914","PF07933","PF08000","PF08016","PF08154","PF08235","PF08239","PF08282","PF08416","PF08458","PF08460","PF08512","PF08567","PF08644","PF08645","PF08678","PF08757","PF08783","PF08810","PF08817","PF09123","PF09138","PF09192","PF09379","PF09380","PF09385","PF09415","PF09419","PF09469","PF09479","PF09671","PF09814","PF09949","PF10003","PF10009","PF10140","PF10182","PF10243","PF10302","PF10480","PF10531","PF10644","PF10707","PF10739","PF10756","PF10842","PF10882","PF11019","PF11095","PF11292","PF11302","PF11347","PF11434","PF11462","PF11470","PF11531","PF11543","PF11563","PF11605","PF11607","PF11620","PF11623","PF11869","PF11971","PF11973","PF11976","PF12053","PF12068","PF12208","PF12260","PF12327","PF12330","PF12436","PF12456","PF12634","PF12689","PF12710","PF12754","PF12796","PF12814","PF12913","PF13019","PF13095","PF13242","PF13246","PF13344","PF13419","PF13457","PF13465","PF13516","PF13575","PF13809","PF13881","PF13912","PF13973","PF14192","PF14317","PF14361","PF14451","PF14452","PF14453","PF14454","PF14470","PF14478","PF14531","PF14533","PF14560","PF14593","PF14603","PF14604","PF14627","PF14709","PF14719","PF14836","PF14844","PF14847","PF14881","PF14954","PF15169","PF15277","PF15404","PF15405","PF15406","PF15409","PF15410","PF15411","PF15413","PF15505","PF15510","PF15511","PF15630","PF15715","PF16207","PF16212","PF16277","PF16453","PF16457","PF16474","PF16482","PF16511","PF16534","PF16652","PF16674","PF16696","PF16726","PF16764","PF16776","PF16978","PF16979","PF17027","PF17255","PF17292","PF17339","PF17375","PF17384","PF17416","PF17417","PF17667","PF17684","PF17747","PF17748","PF17787","PF17838","PF17840","PF17842","PF17887","PF17888","PF17895","PF17902","PF17965","PF17966","PF18012","PF18036","PF18037","PF18038","PF18045","PF18101","PF18103","PF18116","PF18124","PF18129","PF18161","PF18281","PF18335","PF18343","PF18346","PF18348","PF18350","PF18354","PF18382","PF18383","PF18396","PF18469","PF18507","PF18584","PF18597","PF18629","PF18655","PF18697","PF18762","PF18877","PF18923","PF18998","PF19016","PF19039","PF19057","PF19087","PF19250","PF19974","PF20147","PF20170","PF20297","PF20302","PF20399"};
String[] coiled_coil = {"PF16326","PF11559","PF11839","PF16689","PF17675","PF15346","PF08614","PF00430","PF03258","PF04513","PF18035","PF16523","PF09730","PF10046","PF00170","PF07716","PF03131","PF07888","PF10174","PF09789","PF16516","PF09747","PF15188","PF15254","PF14923","PF14915","PF15921","PF14989","PF15295","PF10152","PF15236","PF15374","PF14917","PF14968","PF14916","PF09762","PF15482","PF18822","PF10473","PF10481","PF16574","PF14073","PF14197","PF17045","PF03879","PF16526","PF07989","PF09813","PF05710","PF04803","PF09304","PF07046","PF19220","PF18504","PF10482","PF05384","PF09267","PF04977","PF08826","PF01519","PF07889","PF09755","PF10224","PF10732","PF10805","PF11932","PF13747","PF13870","PF14235","PF15742","PF16888","PF19012","PF05335","PF11570","PF20492","PF09403","PF15665","PF06818","PF08702","PF00038","PF05377","PF02050","PF14282","PF05911","PF04999","PF12709","PF13851","PF18455","PF16559","PF15070","PF09787","PF02183","PF07111","PF16515","PF15908","PF15905","PF05622","PF09486","PF06825","PF12998","PF16034","PF16471","PF14662","PF15796","PF10205","PF06008","PF06009","PF15619","PF18654","PF18641","PF04778","PF04728","PF05557","PF05672","PF10393","PF17749","PF12795","PF16801","PF12808","PF02344","PF16735","PF01576","PF09745","PF18570","PF16312","PF08946","PF16563","PF16808","PF04508","PF02996","PF01920","PF13758","PF15898","PF09311","PF03528","PF18515","PF08912","PF12072","PF18594","PF05483","PF06428","PF17078","PF07558","PF04102","PF11365","PF02090","PF11544","PF08317","PF09006","PF15233","PF05010","PF09728","PF18394","PF10267","PF12329","PF12325","PF17489","PF13868","PF07926","PF16673","PF08954","PF00261","PF12718","PF01166","PF10212","PF03670","PF03179","PF16999","PF08776","PF16799","PF05701","PF10779","PF14182","PF07321","PF16789","PF06005","PF04576"};
String[] disordered = {"PF16620","PF04419","PF12407","PF11786","PF11787","PF11785","PF11489","PF16634","PF16635","PF16636","PF16630","PF16633","PF15441","PF16629","PF03154","PF12547","PF09041","PF16646","PF05466","PF16627","PF11600","PF02029","PF16648","PF16632","PF03964","PF16643","PF02389","PF16500","PF16607","PF16610","PF12343","PF06513","PF12406","PF12446","PF13070","PF16228","PF18970","PF16662","PF16096","PF03157","PF07382","PF12154","PF15761","PF16617","PF16625","PF16642","PF16210","PF00477","PF16605","PF16628","PF16663","PF16666","PF17445","PF16596","PF16667","PF16058","PF16665","PF16621","PF02158","PF15845","PF16601","PF08944","PF16626","PF15437","PF16616","PF16660","PF16645","PF05403","PF15240","PF09689","PF16613","PF16611","PF16612","PF16615","PF16614","PF02755","PF14797","PF16609","PF16618","PF17229","PF09050","PF16650","PF15356","PF10500","PF16664","PF16619","PF16597","PF16608","PF16031","PF16638","PF11636","PF16631","PF16195","PF16602","PF15231","PF15017","PF16623","PF14140","PF14115","PF16606","PF16624","PF16637"};

/**
* special flags lists.
*/
LinkedList<String> nucl_inter_active_site_pfam_list;
LinkedList<String> active_site_minis_nucl_ppi_pfam_list;
LinkedList<String> three_did_lig_list;
LinkedList<String> dbd_list;
LinkedList<String> ppi_phospho_list;
LinkedList<String> coiled_coil_list;
LinkedList<String> disordered_list;


      /**
     * this function is the one that actually prepares for weka input file based on seven modules.
       *
     * example: default values: pr_flag(protcad) = true (it means oligomerization data should exist), 	   llps_flag(llps) = true (it means llps data should exist). 
     *   ddi_inter _flag(3did) = true (it means 3did data should exist). you can set them false. otherwise the program will stop if no data available
	both arrays of nr (dom1,dom2) and redun (dom1,dom2,dom2) should 	  *  not be null
     *@param input file path
     *@param out_path: output file path
     */

public void  combine_log(String input_list) throws IOException,Exception {

	System.out.println("combine_log");

	//options
	Pattern comma_pattern = Pattern.compile(",");
	
	boolean pr_flag = false;
	boolean ddi_inter_flag = false; 
	boolean llps_flag = true;

	//read input list 

	LinkedList<String> cofactor_to_pfam_key = new LinkedList();
	
	List<String> input_lines  = FileUtils.readLines(new File(input_list));
	for(int k = 0; k < input_lines.size(); k++){
				
		String one_line = input_lines.get(k).trim();
		cofactor_to_pfam_key.add(one_line);
	}
	System.out.println("cofactor_to_pfam_key.size():"+cofactor_to_pfam_key.size());


	//output file path. we will create weka input file based on this output file
	String time_stamp = new SimpleDateFormat("yyyyMMddHHmm'.txt'").format(new Date());
	String out_path_all="output/weka_input." + time_stamp;
				
	//another output file path. this file includes ppi partners based on string database
	String out_path_all_partner="output/weka_input_partner." + time_stamp;
	String input_file_mv = "output/input_list." + time_stamp;

	FileUtils.writeStringToFile(new File(input_file_mv),  Arrays.toString(cofactor_to_pfam_key.toArray()), false);
				
	

	

/**
* convert special flags arrays into lists.
*/

	nucl_inter_active_site_pfam_list = new LinkedList();
	active_site_minis_nucl_ppi_pfam_list = new LinkedList();
	three_did_lig_list = new LinkedList();
	dbd_list = new LinkedList();
	ppi_phospho_list = new LinkedList();
	coiled_coil_list = new LinkedList();
	disordered_list = new LinkedList();
 
 	for(int f =0; f < nucl_inter_active_site_pfam.length; f++){

		nucl_inter_active_site_pfam_list.add(nucl_inter_active_site_pfam[f]);
	}

	for(int f =0; f < active_site_minis_nucl_ppi_pfam.length; f++){

		active_site_minis_nucl_ppi_pfam_list.add(active_site_minis_nucl_ppi_pfam[f]);
	}

	for(int f =0; f < three_did_lig.length; f++){

		three_did_lig_list.add(three_did_lig[f]);
	}

	for(int f =0; f < dbd.length; f++){

		dbd_list.add(dbd[f]);
	}

	for(int f =0; f < ppi_phospho.length; f++){

		ppi_phospho_list.add(ppi_phospho[f]);
	}

	for(int f =0; f < coiled_coil.length; f++){

		coiled_coil_list.add(coiled_coil[f]);
	}

	for(int f =0; f < disordered.length; f++){

		disordered_list.add(disordered[f]);
	}

	List<String> uniprot_to_conden_cat_big_key = new LinkedList<String>(llps_go_analysis.uniprot_to_conden_cat_big.keySet());

	LinkedList<String> uniprot_to_gene_key = new LinkedList<String>(llps_go_analysis.uniprot_to_gene.keySet());

	LinkedList<String> conden_cat_big_key = new LinkedList<String>(llps_go_analysis.conden_cat_big_to_uniprot_by_num.keySet());

	
	
	for(int s = 0; s <cofactor_to_pfam_key.size(); s++){
	
		String cofac = cofactor_to_pfam_key.get(s);
		
		
		//create a list where we will store flag's value 
		LinkedList<String> flag_value = new LinkedList();
		//////////////////////
		//get pfams belonging to llps factor
		/////////////////////

		//remove redundant pfams. we will compare non-redundant/redundant sets with 3did
		LinkedList<String> temp_nr_pfam = eukary_to_pfam.get(cofac);

		if(temp_nr_pfam != null){
		
		Set<String> pfams_h_inv = new LinkedHashSet<>();
		pfams_h_inv.addAll((List)temp_nr_pfam);
									
		// Clear the list
		((List)temp_nr_pfam).clear();
															  
		// add the elements of set
		// with no duplicates to the list
		((List)temp_nr_pfam).addAll(pfams_h_inv);

		//sort them to make comparison later
		Collections.sort((List)temp_nr_pfam);
		LinkedList<String> atxg_temp_nr_pfam = nr_pfam_to_eukary.get(temp_nr_pfam);

		//make all possible combinations of pfam dimers.
		//considering llps properties, get all combinations better

		LinkedList<LinkedList<String>> nr_dimer = new LinkedList();

		for(int f = 0; f < temp_nr_pfam.size(); f++){

			for(int g = 0; g < temp_nr_pfam.size(); g++){

				LinkedList<String> dimer = new LinkedList();
				dimer.add(temp_nr_pfam.get(f));
				dimer.add(temp_nr_pfam.get(g));
				Collections.sort((List)dimer);

				if(!nr_dimer.contains(dimer)){

					nr_dimer.add(dimer);
					System.out.println("nr_dimer:"+Arrays.toString(dimer.toArray()));
							
				}

			}//g
		}//f

		/*get 3did comparisons on interfaces between non-redundant pfam sets and redundant pfam sets. non-redundant pfam means those entries where only one pfam domain exists for each pfam id. e.g. PF00270, PF00271. redundant pfam means those entries where multiple pfam domains exist for each pfam id. e.g. PF00270, PF00270, PF00270, PF00271, PF00271.
*/
		String[] three_did_anova = new String[13];

		LinkedList<String>[] exist = ddi_interface_module.three_did_comp.get(temp_nr_pfam);
		boolean ddi_inter_null_check = false;
		if(exist != null){

			if(exist[0]!=null && exist[1]!=null){

				ddi_inter_null_check = true;
				if(exist[0].size() > 1 && exist[1].size() > 1){

					double[][] sample1 = new double[13][exist[0].size()];

					for(int w = 0; w < exist[0].size(); w++){

						String val = exist[0].get(w);
						val=val.replaceAll("\\[","");
						val=val.replaceAll("\\]","");

						String[] split_val = comma_pattern.split(val);
						for(int r = 0; r < split_val.length; r++){

							sample1[r][w] = new Double(split_val[r]).doubleValue();

						}

					}
							

					double[][] sample2 = new double[13][exist[1].size()];

					for(int w = 0; w < exist[1].size(); w++){

						String val = exist[1].get(w);
						val=val.replaceAll("\\[","");
						val=val.replaceAll("\\]","");

						String[] split_val = comma_pattern.split(val);
						for(int r = 0; r < split_val.length; r++){

							sample2[r][w] = new Double(split_val[r]).doubleValue();

						}

					}

					for(int w = 0; w < sample1.length; w++){

						//write = write + "mw;" + e+"@"+f+"@"+g+"@"+mwtest+ "," ;

						Collection<double[]> col = new LinkedList();
						col.add(sample1[w]);
						col.add(sample2[w]);
						double onewayf_val = TestUtils.oneWayAnovaFValue(col);
						double onewayp_val = TestUtils.oneWayAnovaPValue(col);

						String sig = "false";

						if(onewayp_val < 0.3){

							sig = "true";

						}

						three_did_anova[w] = sig;
									
									
					}

				}else if(exist[0].size() > 1 && exist[1].size() <= 1){

					for(int w = 0; w < 13; w++){
						three_did_anova[w] = "no_data1";
					}

				}else if(exist[0].size() <= 1 && exist[1].size() > 1){

					for(int w = 0; w < 13; w++){
						three_did_anova[w] = "no_data2";
					}

				}else if(exist[0].size() <= 1 && exist[1].size() <= 1){

					for(int w = 0; w < 13; w++){
						three_did_anova[w] = "no_data3";
					}

				}


			}else if(exist[0]!=null && exist[1]==null){

				for(int w = 0; w < 13; w++){

					three_did_anova[w] = "null_data1";
				}


			}else if(exist[0]==null && exist[1]!=null){

				for(int w = 0; w < 13; w++){
					three_did_anova[w] = "null_data2";
				}


			}else if(exist[0]==null && exist[1]==null){

				for(int w = 0; w < 13; w++){
					three_did_anova[w] = "null_data3";
				}
			}//null
		}//null

		//if you set restriction of 3did data availability false, the program proceeds even if no 3did data available. otherwise it will stop

		boolean ddi_inter_proceed = false;
		if(ddi_inter_flag){
			if(ddi_inter_null_check){

				ddi_inter_proceed = true;
			}
		}else{ 

			ddi_inter_proceed = true;
		}

		if(ddi_inter_proceed){ 

			//groupid is oligomerization entry accession num that we chose to use from ProtCAD.
			LinkedList<String> groupid_list = oligomerization_module.nr_pfam_to_groupid.get(temp_nr_pfam);

			if(groupid_list != null){
				if(groupid_list.size() > 1){

					System.out.println("multiple groupids:" + Arrays.toString(groupid_list.toArray()));
				}
			}

			//if you set restriction of oligomerization data availability false, the program proceeds even if no oligomerization data available. otherwise it will stop

			boolean pr_proceed = false;
			if(pr_flag){
				if(groupid_list != null){

					pr_proceed = true;
				}
			}else{ 

				pr_proceed = true;
			}

			//System.out.println("groupid_list:"+ Arrays.toString(groupid_list.toArray()));

			LinkedList<String> uni_list = llps_go_analysis.sifts_nr_pfam_uniprot_new.get(temp_nr_pfam);
			//System.out.println("uni_list:"+ Arrays.toString(uni_list.toArray()));

			
			LinkedList<String> atxg_list = new LinkedList();
			atxg_list.addAll(atxg_temp_nr_pfam);
			
			if(pr_proceed){

				if(uni_list != null){

					atxg_list.addAll(uni_list);
				}

				//////remove redundant entries in atxg_list///////
				pfams_h_inv = new LinkedHashSet<>();
				pfams_h_inv.addAll((List)atxg_list);
										
				// Clear the list
				((List)atxg_list).clear();
																  
				// add the elements of set
				// with no duplicates to the list
				((List)atxg_list).addAll(pfams_h_inv);
				
				
				
				/*oligomerization was created based on pdb. each pdb file contained info on uniprot id.
				therefore we get uniprot ids associated with groupids

				per groupid (oligomerization), find how many uniprots associated, and what each uniprot llps property is*/

				LinkedList<String> uni_groupid_list = new LinkedList();
				if(groupid_list != null){
				
					for(int y = 0; y < groupid_list.size(); y ++){

								uni_groupid_list.addAll(oligomerization_module.groupid_to_uniprot.get(groupid_list.get(y)));
				
					}
				}
				System.out.println("uni_groupid_list:" + cofac + ":" + temp_nr_pfam + ":" +Arrays.toString(uni_groupid_list.toArray()));
				if(uni_groupid_list.size()!=0){
					//////remove redundant entries in uni_groupid_list///////
					pfams_h_inv = new LinkedHashSet<>();
					pfams_h_inv.addAll((List)uni_groupid_list);
											
					// Clear the list
					((List)uni_groupid_list).clear();
																	  
					// add the elements of set
					// with no duplicates to the list
					((List)uni_groupid_list).addAll(pfams_h_inv);

					//check if any of uniprots have llps
					//retrieve llps info, it starts here: 

					//get intersection between uniprots associated with this pfam-groupids and llps factors in llps module. uniprot_to_gene_key is llps associated uniprot ids from drllps
					List<String> intersect_uni_llps = uni_groupid_list.stream().filter(uniprot_to_gene_key::contains).collect(Collectors.toList());	 

					System.out.println("intersect_uni_llps:" + cofac + ":" + temp_nr_pfam + ":" + Arrays.toString(intersect_uni_llps.toArray()));
					//there are 265 different llps types:llps_go_analysis.conden_cat_big
					//check if this llps factor associated with any of them
					String[] check_find=new String[llps_go_analysis.conden_cat_big.length];
					//check whether any of uniprots belonging to llps_go_analysis.conden_cat_big have all, partial, or none of pfams belonging to this llps factor 
					String[] match_str = new String[llps_go_analysis.conden_cat_big.length];
					//get uniprot id that has maximum of pfam match
					String[] final_uniid = new String[llps_go_analysis.conden_cat_big.length];
					//get llps functional type of uniprot id that has maximum of pfam match
					String[] final_type = new String[llps_go_analysis.conden_cat_big.length];
					//get pfams of uniprot id that has maximum of pfam match
					String[] uni_hit_pfam = new String[llps_go_analysis.conden_cat_big.length];
					//get pfams of intersection between the uniprot id and llps factor (query)
					String[] intersect_pfam = new String[llps_go_analysis.conden_cat_big.length];
					//get pfams of unique to llps factor (query)
					String[] ddi_inter_uniq = new String[llps_go_analysis.conden_cat_big.length];
					//get pfams of uniprot id that has maximum of pfam match
					String[] uniprot_uniq = new String[llps_go_analysis.conden_cat_big.length];
					
					boolean[] find = new boolean[llps_go_analysis.conden_cat_big.length];
					boolean[] find_sec = new boolean[llps_go_analysis.conden_cat_big.length];

					String[][] check_find_intermedi=new String[llps_go_analysis.conden_cat_big.length][intersect_uni_llps.size()];
					String[][] match_str_intermedi = new String[llps_go_analysis.conden_cat_big.length][intersect_uni_llps.size()];
					String[][] final_uniid_intermedi = new String[llps_go_analysis.conden_cat_big.length][intersect_uni_llps.size()];
					String[][] final_type_uniid_intermedi = new String[llps_go_analysis.conden_cat_big.length][intersect_uni_llps.size()];
					String[][] uni_hit_pfam_uniid_intermedi = new String[llps_go_analysis.conden_cat_big.length][intersect_uni_llps.size()];
					String[][] intersect_pfam_uniid_intermedi = new String[llps_go_analysis.conden_cat_big.length][intersect_uni_llps.size()];
					String[][] ddi_inter_uniq_uniid_intermedi = new String[llps_go_analysis.conden_cat_big.length][intersect_uni_llps.size()];
					String[][] uniprot_uniq_uniid_intermedi = new String[llps_go_analysis.conden_cat_big.length][intersect_uni_llps.size()];

					double[][] max_inter_intermedi = new double[llps_go_analysis.conden_cat_big.length][intersect_uni_llps.size()];

					for(int q = 0; q < llps_go_analysis.conden_cat_big.length; q++){
						for(int x = 0; x <intersect_uni_llps.size(); x++){
							max_inter_intermedi[q][x]=0.0;
						}
					}
						
					LinkedList<String>[][] hit_pfams_intermedi = new LinkedList[llps_go_analysis.conden_cat_big.length][intersect_uni_llps.size()];
					LinkedList<String>[][] hit_uni_pfams_intermedi = new LinkedList[llps_go_analysis.conden_cat_big.length][intersect_uni_llps.size()];
					//List<String> intersect_nr_arraylist = new LinkedList();

					if(intersect_uni_llps.size() > 0){//if the query has llps property

						
						for(int x = 0; x <intersect_uni_llps.size(); x++){//uniprot keys
						
							String uniid = intersect_uni_llps.get(x).toUpperCase();
							Boolean[] conden_check_intermedi = llps_go_analysis.uniprot_to_conden_cat_big.get(uniid);
							
							LinkedList<String> pfams = llps_go_analysis.uniprot_to_pfam_conden.get(uniid);

							//System.out.println("pfams size:" + cofac + ":" + temp_nr_pfam + ":" + uniid + ":" + pfams+ ":" +Arrays.toString(conden_check_intermedi));

							if(pfams != null){
								//////remove redundant///////
								pfams_h_inv = new LinkedHashSet<>();
								pfams_h_inv.addAll((List)pfams);
														
								// Clear the list
								((List)pfams).clear();
																				  
								// add the elements of set
								// with no duplicates to the list
								((List)pfams).addAll(pfams_h_inv);
								Collections.sort((List)pfams);
										
								Set<String> intersect_nr_arraylist =  temp_nr_pfam.stream().filter(pfams::contains).collect(Collectors.toCollection(LinkedHashSet::new));
								//convert arraylist to linkedlist
								//System.out.println("intersect_nr:" + cofac + ":" + temp_nr_pfam + ":" + Arrays.toString(intersect_nr_arraylist.toArray()));
								
								for(int q = 0; q < llps_go_analysis.conden_cat_big.length; q++){

									if(conden_check_intermedi[q].booleanValue()){

										//System.out.println("uniid exist:"+ cofac + ":" + temp_nr_pfam + ":" +  uniid + ":" + llps_go_analysis.conden_cat_big[q]);

										if(temp_nr_pfam.containsAll(pfams) && pfams.containsAll(temp_nr_pfam) && temp_nr_pfam.size() == pfams.size()){
											
												//System.out.println("temp_nr_pfam.size() == pfams.size(): " + cofac + ":" + temp_nr_pfam);
												match_str_intermedi[q][x] = "all_pfam_llps_conden";
												max_inter_intermedi[q][x] =pfams.size()*1.0;
												check_find_intermedi[q][x]="true";
												final_uniid_intermedi[q][x] =uniid;
																final_type_uniid_intermedi[q][x]=llps_go_analysis.uniprot_to_func_type.get(final_uniid_intermedi[q]);
												hit_pfams_intermedi[q][x] = pfams;
												hit_uni_pfams_intermedi[q][x] = pfams;

												//System.out.println("== hit_uni_pfams_intermedi[q][x]:" + cofac + ":" + temp_nr_pfam + ":" +  Arrays.toString(hit_uni_pfams_intermedi[q][x].toArray()));
												//at_least_one_all = true;
												

											}else if(intersect_nr_arraylist.size() > 0){
																								check_find_intermedi[q][x] = "true";
												//System.out.println("intersect_nr_arraylist.size() > 0:" + cofac + ":" + temp_nr_pfam);
												match_str_intermedi[q][x] = "partial_pfam_llps_conden";
												

												if(intersect_nr_arraylist.size()>max_inter_intermedi[q][x]){
													max_inter_intermedi[q][x] = intersect_nr_arraylist.size()*1.0;
													final_uniid_intermedi[q][x] =uniid;
													final_type_uniid_intermedi[q][x]=llps_go_analysis.uniprot_to_func_type.get(final_uniid_intermedi[q][x]);
													hit_pfams_intermedi[q][x] = new LinkedList();
													hit_pfams_intermedi[q][x].addAll(intersect_nr_arraylist);
													hit_uni_pfams_intermedi[q][x] = pfams;

													//System.out.println("< hit_uni_pfams_intermedi[q][x]:" + cofac + ":" + temp_nr_pfam + ":" + Arrays.toString(hit_uni_pfams_intermedi[q][x].toArray()));
												}
											}else{
												//System.out.println("1403 else");
												match_str_intermedi[q][x] = "shouldexist_no_pfam";
												max_inter_intermedi[q][x] = 0.0;
												
												//System.out.println("shouldexist_none  hit_uni_pfams_intermedi[q][x]:" + cofac + ":" + temp_nr_pfam + ":" + Arrays.toString(temp_nr_pfam.toArray()));
											}
										   

									}//if(conden_check[q].booleanValue())
									else{
										//System.out.println("else");
										match_str_intermedi[q][x] = "absent_not_null_pfam";
										max_inter_intermedi[q][x] = 0.0;
										
										//System.out.println("absent_not_null_none  hit_uni_pfams_intermedi[q][x]:" + cofac + ":" + temp_nr_pfam + ":" + Arrays.toString(temp_nr_pfam.toArray()));
									}
								}//q
							}//not null
							else{

								for(int q = 0; q < llps_go_analysis.conden_cat_big.length; q++){

									if(conden_check_intermedi[q].booleanValue()){
										match_str_intermedi[q][x] = "shouldexist_null_pfam";
										max_inter_intermedi[q][x] = 0.0;
										
										//System.out.println("shouldexist_null_pfam  hit_uni_pfams_intermedi[q][x]:" + cofac + ":" + temp_nr_pfam + ":" + Arrays.toString(temp_nr_pfam.toArray()));
									}else{
										match_str_intermedi[q][x] = "absent_null_pfam";
										max_inter_intermedi[q][x] = 0.0;
										
										//System.out.println("absent_null_pfam  hit_uni_pfams_intermedi[q][x]:" + cofac + ":" + temp_nr_pfam + ":" + Arrays.toString(temp_nr_pfam.toArray()));
									}
								}//q

							}	

						}//x unis from llps

					
						//System.out.println("intersect_uni_llps:" +cofac + ":" + temp_nr_pfam + ":" +  Arrays.toString(intersect_uni_llps.toArray()));

						for(int x = 0; x <llps_go_analysis.conden_cat_big.length; x++){
							
							//boolean null_check = false;
							
							//if(max_inter_intermedi[x] != null){

							
								double[] perm = new double[intersect_uni_llps.size()];
								for(int q = 0; q <intersect_uni_llps.size(); q++){
									perm[q] = q*1.0;
								}

								MathArrays.sortInPlace(max_inter_intermedi[x], MathArrays.OrderDirection.DECREASING,perm);

								//System.out.println("max_inter_intermedi[x]:" + cofac + ":" + temp_nr_pfam + ":" + max_inter_intermedi[x][0]+":"+(int)perm[0]);

								if(max_inter_intermedi[x][0] != 0.0){

									find[x] = true;
									check_find[x] = check_find_intermedi[x][(int)perm[0]];
									final_uniid[x] = final_uniid_intermedi[x][(int)perm[0]];
									final_type[x] = final_type_uniid_intermedi[x][(int)perm[0]];
									uni_hit_pfam[x] = Arrays.toString(hit_uni_pfams_intermedi[x][(int)perm[0]].toArray());
									intersect_pfam[x] = Arrays.toString(hit_pfams_intermedi[x][(int)perm[0]].toArray());
									match_str[x] = match_str_intermedi[x][(int)perm[0]];
									List<String> uniq_nr2 = new LinkedList<>(temp_nr_pfam);
									uniq_nr2.removeAll(hit_pfams_intermedi[x][(int)perm[0]]);
									List<String> uniq_nr3 = new LinkedList<>(hit_uni_pfams_intermedi[x][(int)perm[0]]);
									uniq_nr3.removeAll(hit_pfams_intermedi[x][(int)perm[0]]);

									ddi_inter_uniq[x] =  Arrays.toString(uniq_nr2.toArray());
									uniprot_uniq[x] =  Arrays.toString(uniq_nr3.toArray());
									//System.out.println(">0 match_str[x]:" + cofac + ":" + temp_nr_pfam + ":" + final_uniid[x]);
								}

								//conden_write = conden_write   + llps_go_analysis.conden_cat_big[q] + ":" + match_str[q] + ":" + final_uniid[q] + ":" +final_type[q] + ":" + check_find[q] + ":" + Arrays.toString(hit_uni_pfams.toArray()) + ":" + Arrays.toString(hit_pfams.toArray()) + ":"+ Arrays.toString(uniq_nr2.toArray()) + ":" + Arrays.toString(uniq_nr3.toArray()) + ":";
								
							//}//null check
						}//x
					}//intersect size > 0
					//System.out.println("conden_cat_big_key.size():" + conden_cat_big_key.size());
					for(int q = 0; q < llps_go_analysis.conden_cat_big.length; q++){

						int max_inter = 0;
						int match_flag = -1;//no match - no intersection
						LinkedList<String> hit_pfams = new LinkedList();
						LinkedList<String> hit_uni_pfams = new LinkedList();
						List<String> intersect_nr_partial = new LinkedList();
							
						if(!find[q]){
				
							
							String conden_cat_big = llps_go_analysis.conden_cat_big[q];
							//System.out.println("1498 conden_cat_big:" + cofac + ":" + temp_nr_pfam + ":" + conden_cat_big);
							LinkedHashMap<String,LinkedList<String>> pfams_num_uni = llps_go_analysis.conden_cat_big_to_uniprot_by_num.get(conden_cat_big);

							if(pfams_num_uni != null){

								List<String> keys_list = new LinkedList<String>(pfams_num_uni.keySet());

								for(int x =keys_list.size()-1; x >=0 ; x--){

									int pfam_num = new Integer(keys_list.get(x)).intValue();
									//if(pfam_num > temp_nr_pfam.size()){

										LinkedList<String> uni_list_cond = pfams_num_uni.get(keys_list.get(x));

										for(int y = 0; y < uni_list_cond.size(); y++){

											String uniprot_partial = uni_list_cond.get(y);
												
											LinkedList<String> uni_pfams = llps_go_analysis.uniprot_to_pfam_conden.get(uniprot_partial);
												
												
											if(uni_pfams != null){

												//System.out.println("llps_list pfams:"+ Arrays.toString(pfams.toArray()));
												
												//////remove redundant///////
												/////////////////////////////
																	
												pfams_h_inv = new LinkedHashSet<>();
													pfams_h_inv.addAll((List)uni_pfams);
																	
												// Clear the list
												((List)uni_pfams).clear();
																							  
												// add the elements of set
												// with no duplicates to the list
													((List)uni_pfams).addAll(pfams_h_inv);
													Collections.sort((List)uni_pfams);
													
												intersect_nr_partial = temp_nr_pfam.stream().filter(uni_pfams::contains).collect(Collectors.toList());	
									 				
												//System.out.println("intersect_nr_partial:"+ Arrays.toString(intersect_nr_partial.toArray()));

												if(intersect_nr_partial.size() > 0){

													match_flag = 0;
													find_sec[q] = true;
														
													if(max_inter < intersect_nr_partial.size()){
														max_inter = intersect_nr_partial.size();
														hit_pfams = new LinkedList();
															hit_pfams.addAll(intersect_nr_partial);
														hit_uni_pfams = new LinkedList();
															hit_uni_pfams.addAll(uni_pfams);
														List<String> uniq_nr2 = new LinkedList<>(temp_nr_pfam);
														uniq_nr2.removeAll(hit_pfams);
														List<String> uniq_nr3 = new LinkedList<>(hit_uni_pfams);
														uniq_nr3.removeAll(hit_pfams);

														uni_hit_pfam[q] = Arrays.toString(hit_uni_pfams.toArray());
														intersect_pfam[q] =  Arrays.toString(hit_pfams.toArray());
														ddi_inter_uniq[q] =  Arrays.toString(uniq_nr2.toArray());
														uniprot_uniq[q] =  Arrays.toString(uniq_nr3.toArray());
														final_uniid[q] =uniprot_partial;
															final_type[q]=llps_go_analysis.uniprot_to_func_type.get(final_uniid[q]);
														//System.out.println("find_sec true final_uniid[q]:" + cofac + ":" + temp_nr_pfam + ":" + final_uniid[q]);

														//check_find[q] = "any_uniprot_partial_true";
														//match_str[q] = "any_uniprot_partial_pfam";
													}
												
												}//>0
											}//not null
									
										}//y
									//}//pfam_num.size() > temp_nr_pfam.size()
								
								}//x
							}//not null
							
						//}//find false

						//if(!find[q]){
			
							String[] na_order = {"absent_null_pfam","absent_not_null_pfam","shouldexist_null_pfam","shouldexist_no_pfam"
};
							//System.out.println("1578 find[q]:" + cofac + ":" + temp_nr_pfam + ":" + conden_cat_big);
							int sel = -1;
							for(int x = 0; x <intersect_uni_llps.size(); x++){
								//System.out.println("1581 match_str_intermedi[q][x]:" +match_str_intermedi[q][x]);

								for(int y =0; y < na_order.length; y++){
									
									if(match_str_intermedi[q][x].equals(na_order[y])){
										if(sel < y){

											sel = y;
											
										}
									}
								}
							}//x
							//System.out.println("1594 sel:" +sel +":"+na_order[sel]);

							if(!find_sec[q]){
								hit_pfams = new LinkedList();
								hit_pfams.add("none");
								hit_uni_pfams = new LinkedList();
								hit_uni_pfams.add("none");
								match_flag = -1;
								if(sel == 0){

									match_str[q] ="absent_null_pfam"; 
									final_uniid[q] = "absent_null_NA";
									final_type[q] = "absent_null_NA";
									check_find[q] = "absent_null_false";
								}else if(sel == 1 ){

									match_str[q] = "absent_not_null_pfam";
									final_uniid[q] = "absent_not_null_NA";
									final_type[q] = "absent_not_null_NA";
									check_find[q] = "absent_not_null_false";
								}else if(sel == 2){

									match_str[q] = "shouldexist_null_pfam";
									final_uniid[q] = "shouldexist_null_NA";
									final_type[q] = "shouldexist_null_NA";
									check_find[q] = "shouldexist_null_false";
								}else if(sel == 3){

									match_str[q] = "shouldexist_no_pfam";
									final_uniid[q] = "shouldexist_no_NA";
									final_type[q] = "shouldexist_no_NA";
									check_find[q] = "shouldexist_no_false";
								}else{

									match_str[q] = "any_uniprot_partial_no_pfam";
									final_uniid[q] = "any_uniprot_partial_NA";
									final_type[q] = "any_uniprot_partial_NA";
									check_find[q] = "any_uniprot_partial_false";

								}
							}else{

								if(sel == 0){

									match_str[q] ="absent_null_pfam"; 
									check_find[q] = "absent_null_false";
								}else if(sel == 1 ){

									match_str[q] = "absent_not_null_pfam";
									check_find[q] = "absent_not_null_false";
								}else if(sel == 2){

									match_str[q] = "shouldexist_null_pfam";
									check_find[q] = "shouldexist_null_false";
								}else if(sel == 3){

									match_str[q] = "shouldexist_no_pfam";
									check_find[q] = "shouldexist_no_false";
								}else{

									match_str[q] = "any_uniprot_partial_pfam";
									check_find[q] = "any_uniprot_partial_true";
								}
							}//else
	
						}//if not find not find_sec

						if(!find_sec[q]){
						
							List<String> uniq_nr2 = new LinkedList<>(temp_nr_pfam);
							uniq_nr2.removeAll(hit_pfams);
							List<String> uniq_nr3 = new LinkedList<>(hit_uni_pfams);
							uniq_nr3.removeAll(hit_pfams);

							uni_hit_pfam[q] = Arrays.toString(hit_uni_pfams.toArray());
							intersect_pfam[q] =  Arrays.toString(hit_pfams.toArray());
							ddi_inter_uniq[q] =  Arrays.toString(uniq_nr2.toArray());
							uniprot_uniq[q] =  Arrays.toString(uniq_nr3.toArray());
						}
					
					}//q llps type

	////////////////////////////////////////////////////////////////////////
					
					//dimer freq

					//condensates
					LinkedList<Double>[][] conden_type_freq = new LinkedList[llps_go_analysis.conden_cat_big.length][2];
					for(int u = 0; u < llps_go_analysis.conden_cat_big.length; u++){
						for(int g = 0; g < 2; g++){

							conden_type_freq[u][g] = new LinkedList();
						}
					}

					for(int u = 0; u < nr_dimer.size(); u++){

						LinkedList<String> nr_dimer_indi = nr_dimer.get(u);
						//System.out.println("nr_dimer_indi:"+Arrays.toString(nr_dimer_indi.toArray()));

						Integer[] cond_val_freq = llps_go_analysis.dimer_pfam_to_conden.get(nr_dimer_indi);

						if(cond_val_freq != null){

							//System.out.println("cond_val_freq:"+Arrays.toString(cond_val_freq));

							List<String> conden_inter = nr_dimer_indi.stream().filter(ddi_interface_module.llps_array_list::contains).collect(Collectors.toList());
							
							int llps_ind = -1;
							if(conden_inter.size() >0){
								llps_ind = 0;//if dimer has llps pfam
							}else{
								llps_ind = 1;
							}

							
							for(int g =0; g < llps_go_analysis.conden_cat_big.length; g++){

								if(llps_ind == 0){

									if(cond_val_freq[g] != 0){
										conden_type_freq[g][0].add(cond_val_freq[g]*1.0);
									}
								}else{
									if(cond_val_freq[g] != 0){
										conden_type_freq[g][1].add(cond_val_freq[g]*1.0);
									}
								}
								
							}
						}	
					}//u
									

					
					String conden_freq_answer_val = "CONDEN_TYPE;";
						
					
					for(int g =0; g < llps_go_analysis.conden_cat_big.length; g++){

			    			if(conden_type_freq[g][0].size() != 0 && conden_type_freq[g][1].size() != 0){
							double[] sample1 = ArrayUtils.toPrimitive(conden_type_freq[g][0].toArray(new Double[0]));
							double[] sample2 = ArrayUtils.toPrimitive(conden_type_freq[g][1].toArray(new Double[0]));

							double onewayp_val = 1.0;

							if(sample1.length > 1 && sample2.length > 1){
								Collection<double[]> col = new LinkedList();
								col.add(sample1);
								col.add(sample2);
								//double onewayf_val = TestUtils.oneWayAnovaFValue(col);
								onewayp_val = TestUtils.oneWayAnovaPValue(col);

								if(onewayp_val<0.3){
										
									conden_freq_answer_val = conden_freq_answer_val + llps_go_analysis.conden_cat_big[g] + "@sig;";
								}else{
									conden_freq_answer_val = conden_freq_answer_val + llps_go_analysis.conden_cat_big[g] + "@notsig;";
								}

							}else{

								if(conden_type_freq[g][0].size() >1 && conden_type_freq[g][1].size() ==1){
									conden_freq_answer_val = conden_freq_answer_val + llps_go_analysis.conden_cat_big[g] + "@llps>1-non-llps=1;";
								}else if(conden_type_freq[g][0].size() ==1 && conden_type_freq[g][1].size() >1){
									conden_freq_answer_val = conden_freq_answer_val + llps_go_analysis.conden_cat_big[g] + "@llps=1-non-llps>1;";
								}else{
									conden_freq_answer_val = conden_freq_answer_val + llps_go_analysis.conden_cat_big[g] + "@llps=1-non-llps=1;";
								}

							}
						}else if(conden_type_freq[g][0].size() != 0 && conden_type_freq[g][1].size() == 0){
							if(conden_type_freq[g][0].size() >1){

								conden_freq_answer_val = conden_freq_answer_val+ llps_go_analysis.conden_cat_big[g]+"@data-llps-only;";
							}else{

								conden_freq_answer_val = conden_freq_answer_val+ llps_go_analysis.conden_cat_big[g]+"@data-llps-one-entry-only;";
							}
						}else if(conden_type_freq[g][0].size() == 0 && conden_type_freq[g][1].size() != 0){
							if(conden_type_freq[g][1].size() >1){

								conden_freq_answer_val = conden_freq_answer_val+ llps_go_analysis.conden_cat_big[g]+"@data-non-llps-only;";
							}else{

								conden_freq_answer_val = conden_freq_answer_val+ llps_go_analysis.conden_cat_big[g]+"@data-non-llps-one-entry-only;";
							}
						}else if(conden_type_freq[g][0].size() == 0 && conden_type_freq[g][1].size() == 0){
							conden_freq_answer_val = conden_freq_answer_val + llps_go_analysis.conden_cat_big[g]+"@no-data-llps-non-llps;";
						}
								
					}
						
					//one pfam
					//condensates
					LinkedList<Double>[][] conden_type_freq_one_pfam = new LinkedList[llps_go_analysis.conden_cat_big.length][2];
					for(int u = 0; u < llps_go_analysis.conden_cat_big.length; u++){
						for(int g = 0; g < 2; g++){

							conden_type_freq_one_pfam[u][g] = new LinkedList();
						}
					}

					for(int u = 0; u < temp_nr_pfam.size(); u++){

						String one_pfam_indi = temp_nr_pfam.get(u);
						//System.out.println("1753 one_pfam_indi:" + one_pfam_indi);
						LinkedList<String> one_pfam_list = new LinkedList();
						one_pfam_list.add(one_pfam_indi);
						
						Integer[] cond_val_freq = llps_go_analysis.one_pfam_to_conden.get(one_pfam_indi);
						//System.out.println("cond_val_freq one_pfam:"+Arrays.toString(cond_val_freq));

						if(cond_val_freq != null){

							List<String> conden_inter = one_pfam_list.stream().filter(ddi_interface_module.llps_array_list::contains).collect(Collectors.toList());
							
							int llps_ind = -1;
							if(conden_inter.size() >0){
								llps_ind = 0;//if one pfam has llps pfam
							}else{
								llps_ind = 1;
							}

							
							for(int g =0; g < llps_go_analysis.conden_cat_big.length; g++){

								if(llps_ind == 0){
									if(cond_val_freq[g] != 0){
										conden_type_freq_one_pfam[g][0].add(cond_val_freq[g]*1.0);
									}
								}else{

									if(cond_val_freq[g] != 0){
										conden_type_freq_one_pfam[g][1].add(cond_val_freq[g]*1.0);
									}
								}
								
							}
						}	
					}//u
									

					
					String conden_freq_answer_val_one_pfam = "CONDEN_TYPE;";
						
					
					for(int g =0; g < llps_go_analysis.conden_cat_big.length; g++){

			    			if(conden_type_freq_one_pfam[g][0].size() != 0 && conden_type_freq_one_pfam[g][1].size() != 0){
							double[] sample1 = ArrayUtils.toPrimitive(conden_type_freq_one_pfam[g][0].toArray(new Double[0]));
							double[] sample2 = ArrayUtils.toPrimitive(conden_type_freq_one_pfam[g][1].toArray(new Double[0]));

							double onewayp_val = 1.0;

							if(sample1.length > 1 && sample2.length > 1){
								Collection<double[]> col = new LinkedList();
								col.add(sample1);
								col.add(sample2);
								//double onewayf_val = TestUtils.oneWayAnovaFValue(col);
								onewayp_val = TestUtils.oneWayAnovaPValue(col);

								if(onewayp_val<0.3){
										
									conden_freq_answer_val_one_pfam = conden_freq_answer_val_one_pfam + llps_go_analysis.conden_cat_big[g] + "@one_pfam_sig;";
								}else{
									conden_freq_answer_val_one_pfam = conden_freq_answer_val_one_pfam + llps_go_analysis.conden_cat_big[g] + "@one_pfam_notsig;";
								}

							}else{

								if(conden_type_freq_one_pfam[g][0].size() >1 && conden_type_freq_one_pfam[g][1].size() ==1){
									conden_freq_answer_val_one_pfam = conden_freq_answer_val_one_pfam + llps_go_analysis.conden_cat_big[g] + "@one_pfam_llps>1-non-llps=1;";
								}else if(conden_type_freq_one_pfam[g][0].size() ==1 && conden_type_freq_one_pfam[g][1].size() >1){
									conden_freq_answer_val_one_pfam = conden_freq_answer_val_one_pfam + llps_go_analysis.conden_cat_big[g] + "@one_pfam_llps=1-non-llps>1;";
								}else{
									conden_freq_answer_val_one_pfam = conden_freq_answer_val_one_pfam + llps_go_analysis.conden_cat_big[g] + "@one_pfam_llps=1-non-llps=1;";
								}

							}
						}else if(conden_type_freq_one_pfam[g][0].size() != 0 && conden_type_freq_one_pfam[g][1].size() == 0){
							if(conden_type_freq_one_pfam[g][0].size() >1){

								conden_freq_answer_val_one_pfam = conden_freq_answer_val_one_pfam+ llps_go_analysis.conden_cat_big[g]+"@one_pfam_data-llps-only;";
							}else{

								conden_freq_answer_val_one_pfam = conden_freq_answer_val_one_pfam+ llps_go_analysis.conden_cat_big[g]+"@one_pfam_data-llps-one-entry-only;";
							}
						}else if(conden_type_freq_one_pfam[g][0].size() == 0 && conden_type_freq_one_pfam[g][1].size() != 0){
							if(conden_type_freq_one_pfam[g][1].size() >1){

								conden_freq_answer_val_one_pfam = conden_freq_answer_val_one_pfam+ llps_go_analysis.conden_cat_big[g]+"@one_pfam_data-non-llps-only;";
							}else{

								conden_freq_answer_val_one_pfam = conden_freq_answer_val_one_pfam+ llps_go_analysis.conden_cat_big[g]+"@one_pfam_data-non-llps-one-entry-only;";
							}
						}else if(conden_type_freq_one_pfam[g][0].size() == 0 && conden_type_freq_one_pfam[g][1].size() == 0){
							conden_freq_answer_val_one_pfam = conden_freq_answer_val_one_pfam + llps_go_analysis.conden_cat_big[g]+"@one_pfam_no-data-llps-non-llps;";
						}
								
					}

		//////////////////////////////////////////////////
					//condensates
					
					LinkedList<Double>[][] conden_llps_func_type_freq = new LinkedList[llps_go_analysis.llps_func_type.length][2];
					for(int u = 0; u < llps_go_analysis.llps_func_type.length; u++){
						for(int g = 0; g < 2; g++){

							conden_llps_func_type_freq[u][g] = new LinkedList();
						}
					}

					for(int u = 0; u < nr_dimer.size(); u++){

						LinkedList<String> nr_dimer_indi = nr_dimer.get(u);
						
						Integer[] cond_freq = llps_go_analysis.dimer_pfam_to_type.get(nr_dimer_indi);

						if(cond_freq != null){

							List<String> conden_inter = nr_dimer_indi.stream().filter(ddi_interface_module.llps_array_list::contains).collect(Collectors.toList());
							
							int llps_ind = -1;
							if(conden_inter.size() >0){
								llps_ind = 0;
							}else{
								llps_ind = 1;
							}

							
							for(int g =0; g < llps_go_analysis.llps_func_type.length; g++){

								if(llps_ind == 0){
									if(cond_freq[g] != 0){
										conden_llps_func_type_freq[g][0].add(cond_freq[g]*1.0);
									}
								}else{

									if(cond_freq[g] != 0){
										conden_llps_func_type_freq[g][1].add(cond_freq[g]*1.0);
									}
								}
								
							}	
						}//null
					}
						
					
					String conden_type_freq_answer_val = "CONDEN_FUNC_LLPS;";

					for(int g =0; g < llps_go_analysis.llps_func_type.length; g++){

			    			if(conden_llps_func_type_freq[g][0].size() != 0 && conden_llps_func_type_freq[g][1].size() != 0){

							double[] sample1 = ArrayUtils.toPrimitive(conden_llps_func_type_freq[g][0].toArray(new Double[0]));
							double[] sample2 = ArrayUtils.toPrimitive(conden_llps_func_type_freq[g][1].toArray(new Double[0]));

							double onewayp_val = 1.0;
							if(sample1.length > 1 && sample2.length > 1){
								Collection<double[]> col = new LinkedList();
								col.add(sample1);
								col.add(sample2);
								//double onewayf_val = TestUtils.oneWayAnovaFValue(col);
								onewayp_val = TestUtils.oneWayAnovaPValue(col);

								if(onewayp_val<0.3){
										
									conden_type_freq_answer_val = conden_type_freq_answer_val + llps_go_analysis.llps_func_type[g] + "@sig;";
								}else{
									conden_type_freq_answer_val = conden_type_freq_answer_val + llps_go_analysis.llps_func_type[g] + "@notsig;";
								}

							}else{

								if(conden_llps_func_type_freq[g][0].size() >1 && conden_llps_func_type_freq[g][1].size() ==1){
									conden_type_freq_answer_val = conden_type_freq_answer_val+ llps_go_analysis.llps_func_type[g]+  "@llps>1-non-llps=1;";

								}else if(conden_llps_func_type_freq[g][0].size() ==1 && conden_llps_func_type_freq[g][1].size() >1){
									conden_type_freq_answer_val = conden_type_freq_answer_val+ llps_go_analysis.llps_func_type[g] + "@llps=1-non-llps>1;";

								}else{
									conden_type_freq_answer_val = conden_type_freq_answer_val+ llps_go_analysis.llps_func_type[g] + "@llps=1-non-llps=1;";
								}

							}
						}else if(conden_llps_func_type_freq[g][0].size() != 0 && conden_llps_func_type_freq[g][1].size() == 0){
							

							if(conden_llps_func_type_freq[g][0].size() >1){

								conden_type_freq_answer_val = conden_type_freq_answer_val+ llps_go_analysis.llps_func_type[g]+"@data-llps-only;";
							}else{

								conden_type_freq_answer_val = conden_type_freq_answer_val+ llps_go_analysis.llps_func_type[g]+"@data-llps-one-entry-only;";
							}
						}else if(conden_llps_func_type_freq[g][0].size() == 0 && conden_llps_func_type_freq[g][1].size() != 0){
							if(conden_llps_func_type_freq[g][1].size() >1){

								conden_type_freq_answer_val = conden_type_freq_answer_val+ llps_go_analysis.llps_func_type[g]+"@data-non-llps-only;";
							}else{

								conden_type_freq_answer_val = conden_type_freq_answer_val+ llps_go_analysis.llps_func_type[g]+"@data-non-llps-one-entry-only;";
							}
						}else if(conden_type_freq[g][0].size() == 0 && conden_type_freq[g][1].size() == 0){
							conden_type_freq_answer_val = conden_type_freq_answer_val+ llps_go_analysis.llps_func_type[g]+"@no-data-llps-non-llps;";
						}
		 					
					}

					//condensates
					
					LinkedList<Double>[][] conden_llps_func_type_freq_one_pfam = new LinkedList[llps_go_analysis.llps_func_type.length][2];
					for(int u = 0; u < llps_go_analysis.llps_func_type.length; u++){
						for(int g = 0; g < 2; g++){

							conden_llps_func_type_freq_one_pfam[u][g] = new LinkedList();
						}
					}

					for(int u = 0; u < temp_nr_pfam.size(); u++){

						String one_pfam_indi = temp_nr_pfam.get(u);
						LinkedList<String> one_pfam_list = new LinkedList();
						one_pfam_list.add(one_pfam_indi);
						
						Integer[] cond_freq = llps_go_analysis.one_pfam_to_type.get(one_pfam_indi);

						if(cond_freq != null){

							List<String> conden_inter = one_pfam_list.stream().filter(ddi_interface_module.llps_array_list::contains).collect(Collectors.toList());
							
							int llps_ind = -1;
							if(conden_inter.size() >0){
								llps_ind = 0;
							}else{
								llps_ind = 1;
							}

							
							for(int g =0; g < llps_go_analysis.llps_func_type.length; g++){

								if(llps_ind == 0){
									if(cond_freq[g] != 0){
										conden_llps_func_type_freq_one_pfam[g][0].add(cond_freq[g]*1.0);
									}
								}else{
									if(cond_freq[g] != 0){
										conden_llps_func_type_freq_one_pfam[g][1].add(cond_freq[g]*1.0);
									}
								}
								
							}	
						}//null
					}
						
					
					String conden_type_freq_answer_val_one_pfam = "CONDEN_FUNC_LLPS;";

					for(int g =0; g < llps_go_analysis.llps_func_type.length; g++){

			    			if(conden_llps_func_type_freq_one_pfam[g][0].size() != 0 && conden_llps_func_type_freq_one_pfam[g][1].size() != 0){

							double[] sample1 = ArrayUtils.toPrimitive(conden_llps_func_type_freq_one_pfam[g][0].toArray(new Double[0]));
							double[] sample2 = ArrayUtils.toPrimitive(conden_llps_func_type_freq_one_pfam[g][1].toArray(new Double[0]));

							double onewayp_val = 1.0;
							if(sample1.length > 1 && sample2.length > 1){
								Collection<double[]> col = new LinkedList();
								col.add(sample1);
								col.add(sample2);
								//double onewayf_val = TestUtils.oneWayAnovaFValue(col);
								onewayp_val = TestUtils.oneWayAnovaPValue(col);

								if(onewayp_val<0.3){
										
									conden_type_freq_answer_val_one_pfam = conden_type_freq_answer_val_one_pfam + llps_go_analysis.llps_func_type[g] + "@one_pfam_sig;";
								}else{
									conden_type_freq_answer_val_one_pfam = conden_type_freq_answer_val_one_pfam + llps_go_analysis.llps_func_type[g] + "@one_pfam_notsig;";
								}

							}else{

								if(conden_llps_func_type_freq_one_pfam[g][0].size() >1 && conden_llps_func_type_freq_one_pfam[g][1].size() ==1){
									conden_type_freq_answer_val_one_pfam = conden_type_freq_answer_val_one_pfam+ llps_go_analysis.llps_func_type[g]+  "@one_pfam_llps>1-non-llps=1;";

								}else if(conden_llps_func_type_freq_one_pfam[g][0].size() ==1 && conden_llps_func_type_freq_one_pfam[g][1].size() >1){
									conden_type_freq_answer_val_one_pfam = conden_type_freq_answer_val_one_pfam+ llps_go_analysis.llps_func_type[g] + "@one_pfam_llps=1-non-llps>1;";

								}else{
									conden_type_freq_answer_val_one_pfam = conden_type_freq_answer_val_one_pfam+ llps_go_analysis.llps_func_type[g] + "@one_pfam_llps=1-non-llps=1;";
								}

							}
						}else if(conden_llps_func_type_freq_one_pfam[g][0].size() != 0 && conden_llps_func_type_freq_one_pfam[g][1].size() == 0){
							

							if(conden_llps_func_type_freq_one_pfam[g][0].size() >1){

								conden_type_freq_answer_val_one_pfam = conden_type_freq_answer_val_one_pfam+ llps_go_analysis.llps_func_type[g]+"@one_pfam_data-llps-only;";
							}else{

								conden_type_freq_answer_val_one_pfam = conden_type_freq_answer_val_one_pfam+ llps_go_analysis.llps_func_type[g]+"@one_pfam_data-llps-one-entry-only;";
							}
						}else if(conden_llps_func_type_freq_one_pfam[g][0].size() == 0 && conden_llps_func_type_freq_one_pfam[g][1].size() != 0){
							if(conden_llps_func_type_freq_one_pfam[g][1].size() >1){

								conden_type_freq_answer_val_one_pfam = conden_type_freq_answer_val_one_pfam+ llps_go_analysis.llps_func_type[g]+"@one_pfam_data-non-llps-only;";
							}else{

								conden_type_freq_answer_val_one_pfam = conden_type_freq_answer_val_one_pfam+ llps_go_analysis.llps_func_type[g]+"@one_pfam_data-non-llps-one-entry-only;";
							}
						}else if(conden_type_freq[g][0].size() == 0 && conden_type_freq[g][1].size() == 0){
							conden_type_freq_answer_val_one_pfam = conden_type_freq_answer_val_one_pfam+ llps_go_analysis.llps_func_type[g]+"@one_pfam_no-data-llps-non-llps;";
						}
		 					
					}
				
	///////////////////////////////////////////freq ends//////////////////////////////////////

					//retrieve llps info ends here

					//special flags start here

					int llps_pfam_flag = 0;
					List<String> llps_pfam_inter = temp_nr_pfam.stream().filter(ddi_interface_module.llps_array_list::contains).collect(Collectors.toList());
					
					String llps_pfam_flag_val ="NA";
					if(llps_pfam_inter.size() > 0){

						llps_pfam_flag = llps_pfam_inter.size();
						llps_pfam_flag_val = Arrays.toString(llps_pfam_inter.toArray());
						flag_value.add(llps_pfam_flag_val);
					}else{
						flag_value.add(llps_pfam_flag_val);
					}


					int repeat_flag = 0;
					List<String> repeat = temp_nr_pfam.stream().filter(llps_go_analysis.repeat_all::contains).collect(Collectors.toList());
					
					String repeat_flag_val = "NA";
					if(repeat.size() > 0){

						repeat_flag = repeat.size();
						repeat_flag_val = Arrays.toString(repeat.toArray());
						flag_value.add(repeat_flag_val);
						
					}else{
						flag_value.add(repeat_flag_val);
					}

					int binding_flag = 0;
					List<String> binding = temp_nr_pfam.stream().filter(llps_go_analysis.binding_all::contains).collect(Collectors.toList());
					
					String binding_flag_val = "NA";
					if(binding.size() > 0){

						binding_flag = binding.size();
						binding_flag_val = Arrays.toString(binding.toArray());
						flag_value.add(binding_flag_val);

					}else{
						flag_value.add(binding_flag_val);
					}

					int interpro_binding_flag = 0;
					List<String> interpro_binding2 = temp_nr_pfam.stream().filter(llps_go_analysis.interpro_binding_list::contains).collect(Collectors.toList());
					
					String interpro_binding_flag_val = "NA";
					if(interpro_binding2.size() > 0){

						interpro_binding_flag = interpro_binding2.size();
						interpro_binding_flag_val = Arrays.toString(interpro_binding2.toArray());
						flag_value.add(interpro_binding_flag_val);
					}else{
						flag_value.add(interpro_binding_flag_val);
					}

					int interpro_activity_flag = 0;
					List<String> interpro_activity2 = temp_nr_pfam.stream().filter(llps_go_analysis.interpro_activity_list::contains).collect(Collectors.toList());
					
					String interpro_activity2_flag_val ="NA";
					if(interpro_activity2.size() > 0){

						interpro_activity_flag = interpro_activity2.size();
						interpro_activity2_flag_val = Arrays.toString(interpro_activity2.toArray());
						flag_value.add(interpro_activity2_flag_val);

					}else{
						flag_value.add(interpro_activity2_flag_val);
					}


					int nucl_inter_active_site_pfam_list_flag = 0;
					List<String> nucl_inter_active_site_pfam_list_inter = temp_nr_pfam.stream().filter(nucl_inter_active_site_pfam_list::contains).collect(Collectors.toList());
					
					String nucl_inter_active_site_pfam_list_inter_flag_val = "NA";
					if(nucl_inter_active_site_pfam_list_inter.size() > 0){

						nucl_inter_active_site_pfam_list_flag = nucl_inter_active_site_pfam_list_inter.size();
						nucl_inter_active_site_pfam_list_inter_flag_val = Arrays.toString(nucl_inter_active_site_pfam_list_inter.toArray());
						flag_value.add(nucl_inter_active_site_pfam_list_inter_flag_val);

					}else{
						flag_value.add(nucl_inter_active_site_pfam_list_inter_flag_val);
					}

					int active_site_minis_nucl_ppi_pfam_list_flag = 0;
					List<String> active_site_minis_nucl_ppi_pfam_list_inter = temp_nr_pfam.stream().filter(active_site_minis_nucl_ppi_pfam_list::contains).collect(Collectors.toList());
					
					String active_site_minis_nucl_ppi_pfam_list_inter_flag_val = "NA";
					if(active_site_minis_nucl_ppi_pfam_list_inter.size() > 0){

						active_site_minis_nucl_ppi_pfam_list_flag = active_site_minis_nucl_ppi_pfam_list_inter.size();
						active_site_minis_nucl_ppi_pfam_list_inter_flag_val = Arrays.toString(active_site_minis_nucl_ppi_pfam_list_inter.toArray());
						flag_value.add(active_site_minis_nucl_ppi_pfam_list_inter_flag_val);

					}else{
						flag_value.add(active_site_minis_nucl_ppi_pfam_list_inter_flag_val);
					}

			   		int three_did_lig_list_flag = 0;
					List<String> three_did_lig_list_inter = temp_nr_pfam.stream().filter(three_did_lig_list::contains).collect(Collectors.toList());
					
					String three_flag_val = "NA";
					if(three_did_lig_list_inter.size() > 0){

						three_did_lig_list_flag = three_did_lig_list_inter.size();

						three_flag_val = Arrays.toString(three_did_lig_list_inter.toArray());
						flag_value.add(three_flag_val);
						

					}else{
						flag_value.add(three_flag_val);
					}

					int dbd_list_flag = 0;
					List<String> dbd_list_inter = temp_nr_pfam.stream().filter(dbd_list::contains).collect(Collectors.toList());
					
					String dbd_list_inter_flag_val = "NA";
					if(dbd_list_inter.size() > 0){

						dbd_list_flag = dbd_list_inter.size();
						dbd_list_inter_flag_val = Arrays.toString(dbd_list_inter.toArray());
						flag_value.add(dbd_list_inter_flag_val);

					}else{
						flag_value.add(dbd_list_inter_flag_val);
					}

					int ppi_phospho_list_flag = 0;
					List<String> ppi_phospho_list_inter = temp_nr_pfam.stream().filter(ppi_phospho_list::contains).collect(Collectors.toList());
					
					String ppi_phospho_list_inter_flag_val = "NA";
					if(ppi_phospho_list_inter.size() > 0){

						ppi_phospho_list_flag = ppi_phospho_list_inter.size();
						ppi_phospho_list_inter_flag_val = Arrays.toString(ppi_phospho_list_inter.toArray());
						flag_value.add(ppi_phospho_list_inter_flag_val);

					}else{
						flag_value.add(ppi_phospho_list_inter_flag_val);
					}

					int coiled_coil_list_flag = 0;
					List<String> coiled_coil_list_inter = temp_nr_pfam.stream().filter(coiled_coil_list::contains).collect(Collectors.toList());
					
					String coiled_coil_list_inter_flag_val = "NA";
					if(coiled_coil_list_inter.size() > 0){

						coiled_coil_list_flag = coiled_coil_list_inter.size();
						coiled_coil_list_inter_flag_val = Arrays.toString(coiled_coil_list_inter.toArray());
						flag_value.add(coiled_coil_list_inter_flag_val);

					}else{
						flag_value.add(coiled_coil_list_inter_flag_val);
					}
					//System.out.println("coiled_coil_list_flag:"+ coiled_coil_list_flag);

					int disordered_list_flag = 0;
					List<String> disordered_list_inter = temp_nr_pfam.stream().filter(disordered_list::contains).collect(Collectors.toList());
					
					String disordered_list_inter_flag_val = "NA";
					if(disordered_list_inter.size() > 0){

						disordered_list_flag = disordered_list_inter.size();
						disordered_list_inter_flag_val = Arrays.toString(disordered_list_inter.toArray());
						flag_value.add(disordered_list_inter_flag_val);
					}else{
						flag_value.add(disordered_list_inter_flag_val);
					}

					int multiple_oligo_flag = 0;
					Set<String> multiple_oligo_inter = temp_nr_pfam.stream().filter(oligomerization_module.multiple_oligo_flag::contains).collect(Collectors.toCollection(LinkedHashSet::new));
					
					String multiple_oligo_inter_flag_val = "NA";
					if(multiple_oligo_inter.size() > 0){

						multiple_oligo_flag =multiple_oligo_inter.size();
						multiple_oligo_inter_flag_val = Arrays.toString(multiple_oligo_inter.toArray());
						flag_value.add(multiple_oligo_inter_flag_val);
					}else{
						flag_value.add(multiple_oligo_inter_flag_val);
					}

					//special flags ends here
		///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
					//go/po analysis starts here: analysis done in two levels:one gene (uniprot) level and the other domain dimer level, one_pfam

				
				
		////////////////write to file starts here///////////////////////////////////////////////////

				LinkedList<String> write_id = new LinkedList();
				if(groupid_list == null){

					write_id.addAll(uni_groupid_list);

				}else{

					write_id.addAll(groupid_list);
				}

				for(int t = 0; t < write_id.size(); t++){

					String prot_val = "";

					if(groupid_list == null){ 

						prot_val = "NA";
					}else{

						prot_val = oligomerization_module.groupid_to_final_data.get(groupid_list.get(t));

						prot_val = prot_val + oligomerization_module.groupid_to_raw_data.get(groupid_list.get(t));
					}
									//prot_val = prot_val.substring(0,prot_val.lastIndexOf(","));
					
					String groupid_list_val = "";
					if(groupid_list == null){ 

						groupid_list_val = "NA";
					}else{
						groupid_list_val = groupid_list.get(t);
					}

					String uni_list_val = "";
					if(uni_list == null){ 

						uni_list_val = "NA";
					}else{
						uni_list_val = Arrays.toString(uni_list.toArray());
					}

					String atxg_list_val = "";
					if(atxg_list == null){ 

						atxg_list_val = "NA";
					}else{
						atxg_list_val = Arrays.toString(atxg_list.toArray());
					}
					

					String write = cofac + "_" + Arrays.toString(temp_nr_pfam.toArray()) +  "_" + groupid_list_val + "_" + Arrays.toString(uni_groupid_list.toArray()) + "_" + uni_list_val + "_" + atxg_list_val + ":" +   prot_val + "," + Arrays.toString(three_did_anova) + ","  +llps_pfam_flag+ ","  +  repeat_flag + "," + binding_flag + "," + interpro_binding_flag + "," + interpro_activity_flag + "," + nucl_inter_active_site_pfam_list_flag + "," + active_site_minis_nucl_ppi_pfam_list_flag + "," + three_did_lig_list_flag + "," + dbd_list_flag + "," + ppi_phospho_list_flag + "," + coiled_coil_list_flag + "," + disordered_list_flag + "," + multiple_oligo_flag + "," + Arrays.toString(flag_value.toArray()) + ":" +  conden_freq_answer_val + ":" + conden_freq_answer_val_one_pfam + ":" + conden_type_freq_answer_val+ ":" + conden_type_freq_answer_val_one_pfam+ ":" + "llpsOrNot;" + Arrays.toString(match_str)  + ":llpsType;" + Arrays.toString(final_type) + ":llpsChkUniprot;" + Arrays.toString(check_find) + ":llpsUniprot;" + Arrays.toString(final_uniid) + ":uniprotPfam;" + Arrays.toString(uni_hit_pfam)  + ":intersectPfam;" + Arrays.toString(intersect_pfam) + ":uniqToQueryPfam;" + Arrays.toString(ddi_inter_uniq) + ":uniqToUniprotPfam;" + Arrays.toString(uniprot_uniq);

					FileUtils.writeStringToFile(new File(out_path_all), (write  +  "\n"), true);

				}//t
			}//not null
			else{
				String write = Arrays.toString(temp_nr_pfam.toArray()) +":no data found\n";
				FileUtils.writeStringToFile(new File(out_path_all), write, true);
			}	
		}//pr_proceed
	}//ddi_inter_proceed
 
	}//pfam not null
}//s ddi_inter key


} //method

/////////

///////////////////

static class oligomerization_module{


static String[] oligo_type_class = {"C1_obligate_monomer_obligate",
"C1_obligate_hetero_single_oligomer_obligate",
"homo_obligate_monomer_oligomer_moderate",
"homo_obligate_oligomer_obligate",
"hetero_obligate_monomer_oligomer_moderate",
"hetero_obligate_oligomer_obligate",
"homo_hetero_moderate_monomer_obligate",
"homo_hetero_moderate_monomer_oligomer_moderate",
"homo_hetero_moderate_oligomer_obligate"};

static String[] oligo_class = {"CMA","CMB","COA","COB","DMA","DMB","DOA","DOB","OA","OB","TA","TB","IA","IB"};
static String[] oligo_class_homo = {"CMA","COA","DMA","DOA","OA","TA","IA"};
static String[] oligo_class_hetero = {"CMB","COB","DMB","DOB","OB","TB","IB"};

static LinkedList<String>[][][][] groupid_oli_gene_count; 
static LinkedList<String>[][] groupid_oli_gene_count_big; 

static LinkedHashMap<String,String>[][][][] distr_list;
static LinkedHashMap<String,String>[][] distr_list_big;

static LinkedHashMap<String,String> distr;
static LinkedHashMap<String,String> answer_hash;



static LinkedHashMap<String,LinkedList<String>> groupid_to_nr_pfam;//multiple monomer
static LinkedHashMap<LinkedList<String>,LinkedList<String>> nr_pfam_to_groupid;//nr pfam to groupid


void  map_groupid_pfam()  throws IOException{

	System.out.println("map_groupid_oli_gene_count:" );

	groupid_to_nr_pfam = new LinkedHashMap();
	nr_pfam_to_groupid = new LinkedHashMap();

	Pattern space_pattern = Pattern.compile("\\s+");
	Pattern comma_pattern = Pattern.compile(",");
	Pattern at_pattern = Pattern.compile("@");
	Pattern colon_pattern = Pattern.compile(":");
	Pattern underbar_pattern = Pattern.compile("_");

	String sub_path = "data/out_pfam_dimer_protcad_9_inter_intra_interface_domain_9_oligo_stat.get_groupid_dimer.4.per_groupid.dimer_fix1";

	List<String> lines  = FileUtils.readLines(new File(sub_path));


					
	for(int k = 0; k < lines.size(); k++){
		//per_groupid:dimer:10008:[PF01546, PF07687]@[PF07687, PF07687]@[PF01546, PF01546]:2:even:COA:2:odd::homo_obligate_oligomer_obligate:0:0:80:0:0:0		
		String one_line = lines.get(k).trim();

		if(!one_line.contains("homo_obligate_monomer_obligate")){

			String[] colon_split = colon_pattern.split(one_line);
			String id = colon_split[2].trim();
			String[] at_split = at_pattern.split(colon_split[3].trim());
			
			LinkedList<LinkedList<String>> pfams = new LinkedList();
			LinkedList<String> nr_pfams = new LinkedList();
			
			for(int i = 0; i < at_split.length; i++){

				String indi = at_split[i].trim();
				indi=indi.replaceAll("\\[","");
				indi=indi.replaceAll("\\]","");
				String[] comma_split = comma_pattern.split(indi.trim());

				LinkedList<String> dimer = new LinkedList();

				dimer.add(comma_split[0].trim());
				dimer.add(comma_split[1].trim());
				Collections.sort((List)dimer);
				
				pfams.add(dimer);
				
				if(!nr_pfams.contains(comma_split[0].trim())){
				
					nr_pfams.add(comma_split[0].trim());
				}
				
				if(!nr_pfams.contains(comma_split[1].trim())){
				
					nr_pfams.add(comma_split[1].trim());
				}
				
				
			}//i

			Collections.sort((List)nr_pfams);
			groupid_to_nr_pfam.put(id,nr_pfams);
			
			if(nr_pfam_to_groupid.containsKey(nr_pfams)){
			
				LinkedList<String> exist = nr_pfam_to_groupid.get(nr_pfams);
				exist.add(id);
				nr_pfam_to_groupid.put(nr_pfams,exist);
			}else{
			
				LinkedList<String> exist = new LinkedList();
				exist.add(id);
				nr_pfam_to_groupid.put(nr_pfams,exist);
			}
		}//if
	}//k
    }//method

static String[] multiple_oligo_pfams = {"PF00043","PF00044","PF00125","PF00400","PF00441","PF00520","PF00571","PF00628","PF00696","PF00705","PF00994","PF01233","PF01243","PF01397","PF01466","PF01546","PF01842","PF02747","PF02770","PF02771","PF02798","PF02799","PF02800","PF02861","PF03453","PF03454","PF03931","PF03936","PF05641","PF07687","PF08263","PF10615","PF12799","PF13499","PF13840","PF13855","PF16211","PF18511","PF18791","PF20141"};

    static LinkedList<String> multiple_oligo_flag;

    void  make_multiple_oligo_pfams_flags() throws IOException{

	multiple_oligo_flag = new LinkedList();
					
	for(int k = 0; k < multiple_oligo_pfams.length; k++){
				
		multiple_oligo_flag.add(multiple_oligo_pfams[k]);
	}
		
    } 

static LinkedList<String> pdb_one_uniprot;

    void  get_pdbid_one_uniprot()  throws IOException{

	pdb_one_uniprot = new LinkedList();

	String path = "data/pdb_chain_uniprot.lst.sort.k1.k2.k3.pdb.uniprot.sort.uniq.c.diff.uniprot.count.2.1.id.sort.join.sort.uniq.pdbid.sort.uniq";

	List<String> lines  = FileUtils.readLines(new File(path));
	//PF14868, PF14377:0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0

					
	for(int k = 0; k < lines.size(); k++){
				
		String one_line = lines.get(k).trim();
		pdb_one_uniprot.add(one_line);
	}
		
    } 


static LinkedHashMap<String,LinkedList<String>> groupid_to_pdb;

void  map_groupid_to_pdb()  throws IOException{

	groupid_to_pdb = new LinkedHashMap();
	
	
	Pattern space_pattern = Pattern.compile("\\s+");
	Pattern tab_pattern = Pattern.compile("\\t+");
	Pattern comma_pattern = Pattern.compile(",");
	Pattern colon_pattern = Pattern.compile(":");
	Pattern left_pattern = Pattern.compile("left");
	Pattern semi_pattern = Pattern.compile(";");
	
	//String path = "/home/centos2/out_map_groupid_pdb_from_oligomerization_assem";
	String path = "data/out_final_dynamic_db_creation2_check.final";
 	//864:[1p2i, 1p2j, 1p2k, 1tpa, 2fi3, 2fi4, 2fi5, 2ftl, 2ftm, 2ptc, 2tgp, 2tpi, 3btd, 3bte, 3btf, 3btg, 3bth, 3btk, 3btm, 3btq, 3btt, 3btw, 3tpi, 4tpi, 4y0y, 4y0z, 4y10, 4y11, 1ejm, 1eaw, 6bx8, 3p92, 3p95, 3uir, 2r9p, 4dg4, 6har, 4wwy, 3l33, 3l3t, 4u32, 1brb, 1brc, 1co7, 1f5r, 1f7z, 1fy8, 1ykt, 1ylc, 1yld, 3fp6, 3fp8, 3tgi, 3tgj, 3tgk, 3m7q, 1zr0, 1tfx, 2uuy, 3gym, 4wxv, 4u30, 6gfi, 3d65, 1yc0, 4isl, 4isn, 4iso, 1zjd, 5c67, 1p2m, 1p2n, 1p2o, 1p2q, 1t7c, 1t8l, 1t8m, 1t8n, 1t8o, 1bzx, 1taw, 3uou, 2ra3, 3t62, 4bnr, 3otj, 5nx1, 5nx3]
	
	List<String> groupid_lines  = FileUtils.readLines(new File(path));
	
	for(int q = 0; q < groupid_lines.size(); q++){
		
		String one_line = groupid_lines.get(q).toUpperCase();
		String[] colon_split = colon_pattern.split(one_line);
		String groupid = colon_split[0].trim();
		String pdbs = colon_split[1].trim();
		pdbs.replaceAll("\\[","");
		pdbs.replaceAll("\\]","");

		String[] comma_split = comma_pattern.split(pdbs);
		for(int w = 0; w < comma_split.length; w++){

			String pdb = comma_split[w].trim();

			if(groupid_to_pdb.containsKey(groupid)){

				LinkedList<String> exist = groupid_to_pdb.get(groupid);

				if(!exist.contains(pdb)){

					exist.add(pdb);
				}
				groupid_to_pdb.put(groupid,exist);
				//System.out.println("chech pdb uni:"+pdb+":"+Arrays.toString(exist.toArray()));
							
			}else{

				LinkedList<String> exist = new LinkedList();
				exist.add(pdb);
				groupid_to_pdb.put(groupid,exist);
					//System.out.println("chech pdb uni 0:"+pdb+":"+Arrays.toString(exist.toArray()));
			}
		}//w
	}//q
}//method
	
static LinkedHashMap<String,LinkedList<String>> uniprot_to_groupid; 
static LinkedHashMap<String,LinkedList<String>> groupid_to_uniprot;

void  map_groupid_to_uniprot()  throws IOException{

	String path = "data/out_final_dynamic_db_creation2_check.final";

	//String path = "/home/centos2/out_map_groupid_pdb_from_oligomerization_assem";
 	//864:[1p2i, 1p2j, 1p2k, 1tpa, 2fi3, 2fi4, 2fi5, 2ftl, 2ftm, 2ptc, 2tgp, 2tpi, 3btd, 3bte, 3btf, 3btg, 3bth, 3btk, 3btm, 3btq, 3btt, 3btw, 3tpi, 4tpi, 4y0y, 4y0z, 4y10, 4y11, 1ejm, 1eaw, 6bx8, 3p92, 3p95, 3uir, 2r9p, 4dg4, 6har, 4wwy, 3l33, 3l3t, 4u32, 1brb, 1brc, 1co7, 1f5r, 1f7z, 1fy8, 1ykt, 1ylc, 1yld, 3fp6, 3fp8, 3tgi, 3tgj, 3tgk, 3m7q, 1zr0, 1tfx, 2uuy, 3gym, 4wxv, 4u30, 6gfi, 3d65, 1yc0, 4isl, 4isn, 4iso, 1zjd, 5c67, 1p2m, 1p2n, 1p2o, 1p2q, 1t7c, 1t8l, 1t8m, 1t8n, 1t8o, 1bzx, 1taw, 3uou, 2ra3, 3t62, 4bnr, 3otj, 5nx1, 5nx3]

	groupid_to_uniprot = new LinkedHashMap();
	uniprot_to_groupid = new LinkedHashMap();

	Pattern space_pattern = Pattern.compile("\\s+");
	Pattern tab_pattern = Pattern.compile("\\t+");
	Pattern comma_pattern = Pattern.compile(",");
	Pattern colon_pattern = Pattern.compile(":");
	Pattern left_pattern = Pattern.compile("left");
	Pattern semi_pattern = Pattern.compile(";");

	List<String> lines  = FileUtils.readLines(new File(path));
	
	for(int k = 0; k <lines.size(); k++){
				
		String one_line = lines.get(k).toUpperCase();
		String[] colon_split = colon_pattern.split(one_line);
		String groupid = colon_split[0].trim();
		String pdbs = colon_split[1].trim();
		pdbs.replaceAll("\\[","");
		pdbs.replaceAll("\\]","");

		String[] comma_split = comma_pattern.split(pdbs);
		LinkedList<String> uniprots = new LinkedList();

		for(int q = 0; q < comma_split.length; q++){

			String pdb = comma_split[q].trim();

			if(llps_go_analysis.pdb_to_uniprot.get(pdb) != null){

				uniprots.addAll(llps_go_analysis.pdb_to_uniprot.get(pdb));
			}
		}

		//////remove redundant///////
		/////////////////////////////
					
		Set<String> pfams_h_inv = new LinkedHashSet<>();
		pfams_h_inv.addAll((List)uniprots);
					
		// Clear the list
		((List)uniprots).clear();
											  
		// add the elements of set
		// with no duplicates to the list
		((List)uniprots).addAll(pfams_h_inv);

		if(groupid_to_uniprot.containsKey(groupid)){

			LinkedList<String> exist = groupid_to_uniprot.get(groupid);
			exist.addAll(uniprots);
			pfams_h_inv = new LinkedHashSet<>();
			pfams_h_inv.addAll((List)exist);
					
			// Clear the list
			((List)exist).clear();
											  
			// add the elements of set
			// with no duplicates to the list
			((List)exist).addAll(pfams_h_inv);
			groupid_to_uniprot.put(groupid,exist);

		}else{
			groupid_to_uniprot.put(groupid,uniprots);
		}
		
		
	}//k

	List<String> keys = new LinkedList<String>(groupid_to_uniprot.keySet());
	for(int i = 0; i < keys.size(); i++){

		String groupid = keys.get(i);
		LinkedList<String> uniprots = groupid_to_uniprot.get(keys.get(i));

		System.out.println("groupid_to_uniprot:" + keys.get(i) +":" + Arrays.toString(uniprots.toArray()));
		for(int f = 0; f < uniprots.size(); f++){

			String uniprot = uniprots.get(f);

			if(uniprot_to_groupid.containsKey(uniprot)){

				LinkedList<String> exist = uniprot_to_groupid.get(uniprot);
				if(!exist.contains(groupid)){
					exist.add(groupid);
				}
				
				uniprot_to_groupid.put(uniprot,exist);

			}else{
				LinkedList<String> exist = new LinkedList();
				exist.add(groupid);
				uniprot_to_groupid.put(uniprot,uniprots);
			}
		}//f

		//System.out.println(keys.get(i) + ":" + groupid_to_uniprot.get(keys.get(i)));
	}
     
	System.out.println("groupid_to_uniprot:"+groupid_to_uniprot.size());
	System.out.println("uniprot_to_groupid:"+uniprot_to_groupid.size());
		
    }//method


static LinkedList<String> llps_uniprot;

void  get_llps_uniprot()  throws IOException{

	llps_uniprot = new LinkedList();

	String path = "data/LLPS.txt.uniprot.sort";

	List<String> lines  = FileUtils.readLines(new File(path));
	//PF14868, PF14377:0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0

					
	for(int k = 0; k < lines.size(); k++){
				
		String one_line = lines.get(k).trim();
		llps_uniprot.add(one_line);
	}
	System.out.println("llps_uniprot:" +llps_uniprot.size());	
    } 


	static String[] oligo_weka_input_col_name = {"groupid_dimer_pfam_intra_inter_sum1","groupid_dimer_pfam_intra_inter_sum2","groupid_dimer_pfam_intra_inter_sum3","groupid_dimer_pfam_intra_inter_sum4","groupid_dimer_pfam_intra_inter_sum5","groupid_dimer_pfam_intra_inter_sum6","groupid_dimer_pfam_oli_stat_sum1","groupid_dimer_pfam_oli_stat_sum2","groupid_dimer_pfam_oli_stat_sum3","groupid_dimer_pfam_oli_stat_sum4","groupid_dimer_pfam_oli_stat_sum5","groupid_dimer_pfam_oli_stat_sum6","groupid_dimer_pfam_oli_stat_sum7","groupid_dimer_pfam_oli_stat_sum8","groupid_dimer_pfam_oli_stat_sum9","groupid_dimer_pfam_oli_stat_sum10","groupid_dimer_pfam_oli_stat_sum11","groupid_dimer_pfam_even_sum1","groupid_dimer_pfam_even_sum2","groupid_dimer_pfam_even_sum3","groupid_dimer_pfam_even_sum4","groupid_dimer_pfam_even_sum5","groupid_dimer_pfam_even_sum6","groupid_dimer_pfam_even_sum7","groupid_dimer_pfam_even_sum8","groupid_dimer_pfam_even_sum9","groupid_dimer_pfam_even_sum10","groupid_dimer_pfam_even_sum11","groupid_dimer_pfam_even_sum12","groupid_dimer_pfam_even_sum13","groupid_dimer_pfam_even_sum14","groupid_dimer_pfam_odd_sum1","groupid_dimer_pfam_odd_sum2","groupid_dimer_pfam_odd_sum3","groupid_dimer_pfam_odd_sum4","groupid_dimer_pfam_odd_sum5","groupid_dimer_pfam_odd_sum6","groupid_dimer_pfam_odd_sum7","groupid_dimer_pfam_odd_sum8","groupid_dimer_pfam_odd_sum9","groupid_dimer_pfam_odd_sum10","groupid_dimer_pfam_odd_sum11","groupid_dimer_pfam_odd_sum12","groupid_dimer_pfam_odd_sum13","groupid_dimer_pfam_odd_sum14","dimer_groupid_sing_all_max_sum","one_pfam_groupid_sing_intra_inter_freq_sum1","one_pfam_groupid_sing_intra_inter_freq_sum2","one_pfam_groupid_sing_intra_inter_freq_sum3","one_pfam_groupid_sing_intra_inter_freq_sum4","one_pfam_groupid_sing_intra_inter_freq_sum5","one_pfam_groupid_sing_intra_inter_freq_sum6","one_pfam_groupid_sing_oli_stat_sum1","one_pfam_groupid_sing_oli_stat_sum2","one_pfam_groupid_sing_oli_stat_sum3","one_pfam_groupid_sing_oli_stat_sum4","one_pfam_groupid_sing_oli_stat_sum5","one_pfam_groupid_sing_oli_stat_sum6","one_pfam_groupid_sing_oli_stat_sum7","one_pfam_groupid_sing_oli_stat_sum8","one_pfam_groupid_sing_oli_stat_sum9","one_pfam_groupid_sing_oli_stat_sum10","one_pfam_groupid_sing_oli_stat_sum11","one_pfam_groupid_sing_even_sum1","one_pfam_groupid_sing_even_sum2","one_pfam_groupid_sing_even_sum3","one_pfam_groupid_sing_even_sum4","one_pfam_groupid_sing_even_sum5","one_pfam_groupid_sing_even_sum6","one_pfam_groupid_sing_even_sum7","one_pfam_groupid_sing_even_sum8","one_pfam_groupid_sing_even_sum9","one_pfam_groupid_sing_even_sum10","one_pfam_groupid_sing_even_sum11","one_pfam_groupid_sing_even_sum12","one_pfam_groupid_sing_even_sum13","one_pfam_groupid_sing_even_sum14","one_pfam_groupid_sing_odd_sum1","one_pfam_groupid_sing_odd_sum2","one_pfam_groupid_sing_odd_sum3","one_pfam_groupid_sing_odd_sum4","one_pfam_groupid_sing_odd_sum5","one_pfam_groupid_sing_odd_sum6","one_pfam_groupid_sing_odd_sum7","one_pfam_groupid_sing_odd_sum8","one_pfam_groupid_sing_odd_sum9","one_pfam_groupid_sing_odd_sum10","one_pfam_groupid_sing_odd_sum11","one_pfam_groupid_sing_odd_sum12","one_pfam_groupid_sing_odd_sum13","one_pfam_groupid_sing_odd_sum14","one_pfam_groupid_sing_all_max_sum","dimer_sing_oli_sum1","dimer_sing_oli_sum2","dimer_sing_oli_sum3","dimer_sing_oli_sum4","dimer_sing_oli_sum5","dimer_sing_oli_sum6","dimer_sing_oli_sum7","dimer_sing_oli_sum8","dimer_sing_oli_sum9","dimer_sing_oli_sum10","dimer_sing_oli_sum11","dimer_sing_intra_inter_freq_sum1","dimer_sing_intra_inter_freq_sum2","dimer_sing_intra_inter_freq_sum3","dimer_sing_intra_inter_freq_sum4","dimer_sing_intra_inter_freq_sum5","dimer_sing_intra_inter_freq_sum6","dimer_sing_intra_inter_freq_sum7","dimer_sing_intra_inter_freq_sum8","dimer_sing_intra_inter_freq_sum9","dimer_sing_intra_inter_freq_sum10","dimer_sing_intra_inter_freq_sum11","dimer_multi_oli_sum1","dimer_multi_oli_sum2","dimer_multi_oli_sum3","dimer_multi_oli_sum4","dimer_multi_oli_sum5","dimer_multi_oli_sum6","dimer_multi_oli_sum7","dimer_multi_oli_sum8","dimer_multi_oli_sum9","dimer_multi_oli_sum10","dimer_multi_oli_sum11","dimer_multi_intra_inter_freq_sum1","dimer_multi_intra_inter_freq_sum2","dimer_multi_intra_inter_freq_sum3","dimer_multi_intra_inter_freq_sum4","dimer_multi_intra_inter_freq_sum5","dimer_multi_intra_inter_freq_sum6","dimer_multi_intra_inter_freq_sum7","dimer_multi_intra_inter_freq_sum8","dimer_multi_intra_inter_freq_sum9","dimer_multi_intra_inter_freq_sum10","dimer_multi_intra_inter_freq_sum11","one_pfam_sing_intra_inter_freq_sum1","one_pfam_sing_intra_inter_freq_sum2","one_pfam_sing_intra_inter_freq_sum3","one_pfam_sing_intra_inter_freq_sum4","one_pfam_sing_intra_inter_freq_sum5","one_pfam_sing_intra_inter_freq_sum6","one_pfam_sing_intra_inter_freq_sum7","one_pfam_sing_intra_inter_freq_sum8","one_pfam_sing_intra_inter_freq_sum9","one_pfam_sing_intra_inter_freq_sum10","one_pfam_sing_intra_inter_freq_sum11","one_pfam_multi_intra_inter_freq_sum1","one_pfam_multi_intra_inter_freq_sum2","one_pfam_multi_intra_inter_freq_sum3","one_pfam_multi_intra_inter_freq_sum4","one_pfam_multi_intra_inter_freq_sum5","one_pfam_multi_intra_inter_freq_sum6","one_pfam_multi_intra_inter_freq_sum7","one_pfam_multi_intra_inter_freq_sum8","one_pfam_multi_intra_inter_freq_sum9","one_pfam_multi_intra_inter_freq_sum10","one_pfam_multi_intra_inter_freq_sum11","one_pfam_sing_oli_stat_sum1","one_pfam_sing_oli_stat_sum2","one_pfam_sing_oli_stat_sum3","one_pfam_sing_oli_stat_sum4","one_pfam_sing_oli_stat_sum5","one_pfam_sing_oli_stat_sum6","one_pfam_sing_oli_stat_sum7","one_pfam_sing_oli_stat_sum8","one_pfam_sing_oli_stat_sum9","one_pfam_sing_oli_stat_sum10","one_pfam_sing_oli_stat_sum11","one_pfam_multi_oli_stat_sum1","one_pfam_multi_oli_stat_sum2","one_pfam_multi_oli_stat_sum3","one_pfam_multi_oli_stat_sum4","one_pfam_multi_oli_stat_sum5","one_pfam_multi_oli_stat_sum6","one_pfam_multi_oli_stat_sum7","one_pfam_multi_oli_stat_sum8","one_pfam_multi_oli_stat_sum9","one_pfam_multi_oli_stat_sum10","one_pfam_multi_oli_stat_sum11","cell_loc1","cell_loc2","cell_loc3","cell_loc4","cell_loc5","cell_loc6","cell_loc7","cell_loc8","cell_loc9","cell_loc10","cell_loc11","cell_loc12","cell_loc13","cell_loc14","cell_loc15","cell_loc16"};

static int[] oligo_weka_input_start_num={0,6,11,14,14,1,6,11,14,14,1,11,11,11,11,11,11,11,11,16};

static String[] oligo_weka_input_new_final_col_name = {"groupid_dimer_pfam_intra_inter_sum1","groupid_dimer_pfam_intra_inter_sum2","groupid_dimer_pfam_intra_inter_sum3","groupid_dimer_pfam_intra_inter_sum4","groupid_dimer_pfam_intra_inter_sum5","groupid_dimer_pfam_intra_inter_sum6","groupid_dimer_pfam_oli_stat_sum1","groupid_dimer_pfam_oli_stat_sum2","groupid_dimer_pfam_oli_stat_sum3","groupid_dimer_pfam_oli_stat_sum4","groupid_dimer_pfam_oli_stat_sum5","groupid_dimer_pfam_oli_stat_sum6","groupid_dimer_pfam_oli_stat_sum7","groupid_dimer_pfam_oli_stat_sum8","groupid_dimer_pfam_oli_stat_sum9","groupid_dimer_pfam_oli_stat_sum10","groupid_dimer_pfam_oli_stat_sum11","groupid_dimer_pfam_even_odd_sum1","groupid_dimer_pfam_even_odd_sum2","groupid_dimer_pfam_even_odd_sum3","groupid_dimer_pfam_even_odd_sum4","groupid_dimer_pfam_even_odd_sum5","groupid_dimer_pfam_even_odd_sum6","groupid_dimer_pfam_even_odd_sum7","groupid_dimer_pfam_even_odd_sum8","groupid_dimer_pfam_even_odd_sum9","groupid_dimer_pfam_even_odd_sum10","groupid_dimer_pfam_even_odd_sum11","groupid_dimer_pfam_even_odd_sum12","groupid_dimer_pfam_even_odd_sum13","groupid_dimer_pfam_even_odd_sum14","dimer_groupid_sing_all_max_sum","one_pfam_groupid_sing_intra_inter_freq_sum1","one_pfam_groupid_sing_intra_inter_freq_sum2","one_pfam_groupid_sing_intra_inter_freq_sum3","one_pfam_groupid_sing_intra_inter_freq_sum4","one_pfam_groupid_sing_intra_inter_freq_sum5","one_pfam_groupid_sing_intra_inter_freq_sum6","one_pfam_groupid_sing_oli_stat_sum1","one_pfam_groupid_sing_oli_stat_sum2","one_pfam_groupid_sing_oli_stat_sum3","one_pfam_groupid_sing_oli_stat_sum4","one_pfam_groupid_sing_oli_stat_sum5","one_pfam_groupid_sing_oli_stat_sum6","one_pfam_groupid_sing_oli_stat_sum7","one_pfam_groupid_sing_oli_stat_sum8","one_pfam_groupid_sing_oli_stat_sum9","one_pfam_groupid_sing_oli_stat_sum10","one_pfam_groupid_sing_oli_stat_sum11","one_pfam_groupid_sing_even_odd_sum1","one_pfam_groupid_sing_even_odd_sum2","one_pfam_groupid_sing_even_odd_sum3","one_pfam_groupid_sing_even_odd_sum4","one_pfam_groupid_sing_even_odd_sum5","one_pfam_groupid_sing_even_odd_sum6","one_pfam_groupid_sing_even_odd_sum7","one_pfam_groupid_sing_even_odd_sum8","one_pfam_groupid_sing_even_odd_sum9","one_pfam_groupid_sing_even_odd_sum10","one_pfam_groupid_sing_even_odd_sum11","one_pfam_groupid_sing_even_odd_sum12","one_pfam_groupid_sing_even_odd_sum13","one_pfam_groupid_sing_even_odd_sum14","one_pfam_groupid_sing_all_max_sum","dimer_sing_oli_sum1","dimer_sing_oli_sum2","dimer_sing_oli_sum3","dimer_sing_oli_sum4","dimer_sing_oli_sum5","dimer_sing_oli_sum6","dimer_sing_oli_sum7","dimer_sing_oli_sum8","dimer_sing_oli_sum9","dimer_sing_oli_sum10","dimer_sing_oli_sum11","dimer_sing_intra_inter_freq_sum1","dimer_sing_intra_inter_freq_sum2","dimer_sing_intra_inter_freq_sum3","dimer_sing_intra_inter_freq_sum4","dimer_sing_intra_inter_freq_sum5","dimer_sing_intra_inter_freq_sum6","dimer_sing_intra_inter_freq_sum7","dimer_sing_intra_inter_freq_sum8","dimer_sing_intra_inter_freq_sum9","dimer_sing_intra_inter_freq_sum10","dimer_sing_intra_inter_freq_sum11","dimer_multi_oli_sum1","dimer_multi_oli_sum2","dimer_multi_oli_sum3","dimer_multi_oli_sum4","dimer_multi_oli_sum5","dimer_multi_oli_sum6","dimer_multi_oli_sum7","dimer_multi_oli_sum8","dimer_multi_oli_sum9","dimer_multi_oli_sum10","dimer_multi_oli_sum11","dimer_multi_intra_inter_freq_sum1","dimer_multi_intra_inter_freq_sum2","dimer_multi_intra_inter_freq_sum3","dimer_multi_intra_inter_freq_sum4","dimer_multi_intra_inter_freq_sum5","dimer_multi_intra_inter_freq_sum6","dimer_multi_intra_inter_freq_sum7","dimer_multi_intra_inter_freq_sum8","dimer_multi_intra_inter_freq_sum9","dimer_multi_intra_inter_freq_sum10","dimer_multi_intra_inter_freq_sum11","one_pfam_sing_intra_inter_freq_sum1","one_pfam_sing_intra_inter_freq_sum2","one_pfam_sing_intra_inter_freq_sum3","one_pfam_sing_intra_inter_freq_sum4","one_pfam_sing_intra_inter_freq_sum5","one_pfam_sing_intra_inter_freq_sum6","one_pfam_sing_intra_inter_freq_sum7","one_pfam_sing_intra_inter_freq_sum8","one_pfam_sing_intra_inter_freq_sum9","one_pfam_sing_intra_inter_freq_sum10","one_pfam_sing_intra_inter_freq_sum11","one_pfam_multi_intra_inter_freq_sum1","one_pfam_multi_intra_inter_freq_sum2","one_pfam_multi_intra_inter_freq_sum3","one_pfam_multi_intra_inter_freq_sum4","one_pfam_multi_intra_inter_freq_sum5","one_pfam_multi_intra_inter_freq_sum6","one_pfam_multi_intra_inter_freq_sum7","one_pfam_multi_intra_inter_freq_sum8","one_pfam_multi_intra_inter_freq_sum9","one_pfam_multi_intra_inter_freq_sum10","one_pfam_multi_intra_inter_freq_sum11","one_pfam_sing_oli_stat_sum1","one_pfam_sing_oli_stat_sum2","one_pfam_sing_oli_stat_sum3","one_pfam_sing_oli_stat_sum4","one_pfam_sing_oli_stat_sum5","one_pfam_sing_oli_stat_sum6","one_pfam_sing_oli_stat_sum7","one_pfam_sing_oli_stat_sum8","one_pfam_sing_oli_stat_sum9","one_pfam_sing_oli_stat_sum10","one_pfam_sing_oli_stat_sum11","one_pfam_multi_oli_stat_sum1","one_pfam_multi_oli_stat_sum2","one_pfam_multi_oli_stat_sum3","one_pfam_multi_oli_stat_sum4","one_pfam_multi_oli_stat_sum5","one_pfam_multi_oli_stat_sum6","one_pfam_multi_oli_stat_sum7","one_pfam_multi_oli_stat_sum8","one_pfam_multi_oli_stat_sum9","one_pfam_multi_oli_stat_sum10","one_pfam_multi_oli_stat_sum11","cell_loc1","cell_loc2","cell_loc3","cell_loc4","cell_loc5","cell_loc6","cell_loc7","cell_loc8","cell_loc9","cell_loc10","cell_loc11","cell_loc12","cell_loc13","cell_loc14","cell_loc15","cell_loc16"};

static String[] oligo_weka_input_col_name_uniq = {"groupid_dimer_pfam_intra_inter_sum","groupid_dimer_pfam_oli_stat_sum","groupid_dimer_pfam_even_sum","groupid_dimer_pfam_odd_sum","dimer_groupid_sing_all_max_sum","one_pfam_groupid_sing_intra_inter_freq_sum","one_pfam_groupid_sing_oli_stat_sum","one_pfam_groupid_sing_even_sum","one_pfam_groupid_sing_odd_sum","one_pfam_groupid_sing_all_max_sum","dimer_sing_oli_sum","dimer_sing_intra_inter_freq_sum","dimer_multi_oli_sum","dimer_multi_intra_inter_freq_sum","one_pfam_sing_intra_inter_freq_sum","one_pfam_multi_intra_inter_freq_sum","one_pfam_sing_oli_stat_sum","one_pfam_multi_oli_stat_sum","cell_loc"};

	//read fixed datasheet that contains homo_hetero_moderate

static LinkedHashMap<String,String> groupid_to_final_data;
static LinkedHashMap<String,String> groupid_to_raw_data;

void create_new_data_weka_input() throws IOException{

	System.out.println("create_new_data_weka_input()");

	Pattern space_pattern = Pattern.compile("\\s+");
	Pattern tab_pattern = Pattern.compile("	");
	Pattern comma_pattern = Pattern.compile(",");
	Pattern colon_pattern = Pattern.compile(":");
	Pattern at_pattern = Pattern.compile("@");
	
	String path = "data/out_final_dynamic_db_creation.03212023.homo_hetero_moder_fix";
//10008:[PF01546, PF07687]@[PF07687, PF07687]@[PF01546, PF01546]@:0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,12,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,18,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,0,0,0,4,52,0,0,0,0,0,0,0,0,2219,221,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,12,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,0,0,0,0,0,0,10,0,0,0,0,0,0,0,0,homo_obligate_oligomer_obligate
	
	
//0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,12,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,18,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,0,0,0,4,52,0,0,0,0,0,0,0,0,2219,221,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,12,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,4,0,0,0,0,0,0,10,0,0,0,0,0,0,0,0,homo_obligate_oligomer_obligate
//0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,28,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,28,0,0,0,8,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,0,0,0,0,1,0,0,0,0,0,0,0,0,5,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,28,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,homo_obligate_oligomer_obligate
	
	groupid_to_nr_pfam = new LinkedHashMap(); 
	groupid_to_final_data  = new LinkedHashMap(); 
	groupid_to_raw_data  = new LinkedHashMap(); 
	
	List<String> lines  = FileUtils.readLines(new File(path));
	int[] sum = new int[oligo_weka_input_start_num.length-1];
	
	for(int z = 0; z < lines.size(); z++){
		
			String one_line = lines.get(z);
			////System.out.println("raw data:" + one_line);
			String[] one_line_colon = colon_pattern.split(one_line);
			String groupid = one_line_colon[0].trim();
			groupid_to_raw_data.put(groupid,one_line.substring(one_line.lastIndexOf(":")+1,one_line.length()));
			
			LinkedList<String> nr_pfams = new LinkedList();
			String[] one_line_at = at_pattern.split(one_line_colon[1].trim());
			for(int y= 0; y < one_line_at.length; y++){
			
				String pfam_indi = one_line_at[y].trim();
				pfam_indi = pfam_indi.replaceAll("\\[","");
				pfam_indi = pfam_indi.replaceAll("\\]","");
				String[] one_line_comma = comma_pattern.split(pfam_indi);
				String pfam1 = one_line_comma[0].trim();
				String pfam2 = one_line_comma[1].trim();
				
				if(!nr_pfams.contains(pfam1)){
				
					nr_pfams.add(pfam1);
				}
				if(!nr_pfams.contains(pfam2)){
				
					nr_pfams.add(pfam2);
				}
				
			}
			Collections.sort((List)nr_pfams);
			groupid_to_nr_pfam.put(groupid,nr_pfams);

		
			String[] one_line_tab = comma_pattern.split(one_line_colon[2].trim());
			double[] new_data = new double[196];
			
			sum = new int[oligo_weka_input_start_num.length-1];
			
			for(int w = 0; w < oligo_weka_input_start_num.length-1; w++){

				double[] data = new double[oligo_weka_input_start_num[w+1]];
				int count = 0;
				
				for(int q = sum[w]; q < sum[w] + oligo_weka_input_start_num[w+1]; q++){
				
					data[count] = new Double(one_line_tab[q].trim()).doubleValue()+0.5;
					
					count = count+1;

				}
				
				if(w != oligo_weka_input_start_num.length-2){
				
					for(int r=0; r<=w+1;r++){
					
						sum[w+1] = sum[w+1] + oligo_weka_input_start_num[r];
					}
				}
				if(StatUtils.min(data) == StatUtils.max(data)){
				
					for(int e = 0; e < data.length; e++){

						new_data[sum[w]+e] = StatUtils.min(data);
						
					}
				}else{
				

					double[] norm_data = StatUtils.normalize(data);

					for(int e = 0; e < norm_data.length; e++){

						new_data[sum[w]+e] = norm_data[e];
						
					}
				}
				
				
			}

			double[] final_data = new double[196];
			
			
			for(int w = 0; w < oligo_weka_input_start_num.length-1; w++){
			
				if(w==2 || w==7){

					double[] data = new double[oligo_weka_input_start_num[w+1]];
					int count = 0;
					
					
					for(int q = sum[w]; q < sum[w] + oligo_weka_input_start_num[w+1]; q++){
					
						data[count] = new_data[q]/(new_data[q]+ new_data[q+14]);	
						
						count = count+1;	
						
					}
					
					if(StatUtils.min(data) == StatUtils.max(data)){
				
						for(int e = 0; e < data.length; e++){

							final_data[sum[w]+e] = StatUtils.min(data);
							
						}
					}else{
					

						double[] norm_data = StatUtils.normalize(data);

						for(int e = 0; e < norm_data.length; e++){

							final_data[sum[w]+e] = norm_data[e];
							
						}
					}
					
					
					
					
				}else if(w==3 || w==8){
				
				
					for(int q = sum[w]; q < sum[w] + oligo_weka_input_start_num[w+1]; q++){
						final_data[q] =Double.NaN;	
					}
						
					
						
				}else{
				
					
					for(int q = sum[w]; q < sum[w] + oligo_weka_input_start_num[w+1]; q++){
						final_data[q] = new_data[q];	
					}
					

				}

			}
			
			double[] new_final = new double[196-28];
			int count = 0;
			
			for(int q = 0; q < final_data.length; q++){
			
				if(!new Double(final_data[q]).toString().equals("NaN")){
					
					new_final[count] = final_data[q];
					
					count = count +1;	
				}
			}
				
			
			groupid_to_final_data.put(groupid,Arrays.toString(new_final) + "," + one_line_tab[one_line_tab.length-1]);

		
	}//z
    }//method


}//subclass

static class ddi_interface_module {

LinkedHashMap<String,String> interpro_to_pfam;  
void  map_interpro_pfam()  throws IOException{

	interpro_to_pfam = new LinkedHashMap();
	String path = "data/map_interpro_pfam.raw.txt";
 	//101m PF00042
	//102l PF00959
	//103l PF00959
	//pdb_to_uniprot

	Pattern space_pattern = Pattern.compile("\\s+");
	Pattern tab_pattern = Pattern.compile("\\t+");
	Pattern comma_pattern = Pattern.compile(",");
	Pattern colon_pattern = Pattern.compile(":");

	
	List<String> lines  = FileUtils.readLines(new File(path));
	
					
	for(int k = 0; k <lines.size(); k++){
				
		String one_line = lines.get(k);

		if(one_line.contains("interpro id")){

			//System.out.println("interpro id1");
			String[] space_split = space_pattern.split(one_line);
			String interid = space_split[1].trim();
			interid = interid.replaceFirst("id=","");
			interid = interid.replaceAll("\"","");

			for(int q = k+1; q < lines.size(); q++){

				String next_line = lines.get(q);

				if(next_line.contains("interpro id")){
					//System.out.println("interpro id2");
					break;
				}

				
				if(next_line.contains("PFAM")){
					//System.out.println("pfam");
					String[] space_split2 = space_pattern.split(next_line);

					for(int w = 0;w < space_split2.length; w++){

						if(space_split2[w].contains("dbkey=")){
			
							//System.out.println("dbkey");
							String pfamid = space_split2[w].trim();
							pfamid = pfamid.replaceFirst("dbkey=","");
							pfamid = pfamid.replaceAll("\"","");

							//System.out.println(interid + ":" + pfamid);
							interpro_to_pfam.put(interid,pfamid);
							break;
						}

					}

				}
			}
		}
	}

    }//method

	

static LinkedList<LinkedList<String>> three_did_llps_3did;
void  get_three_did_llps_3did()  throws IOException{

	System.out.println("get_three_did_llps_3did()");

	three_did_llps_3did = new LinkedList();

	String path = "/home/centos2/weka_input/compare/pfams.sort.uniq";

	List<String> lines  = FileUtils.readLines(new File(path));
	//8663 [5b75, 5b76, 5b77, 5b78, 4llb, 5u2j, 6oie, 3v43, 4lk9, 4lka, 5szb, 5szc, 2kwj, 2kwk]
	
	Pattern comma_pattern = Pattern.compile(",");
				
	for(int k = 0; k < lines.size(); k++){
				
		String one_line = lines.get(k).trim();
		one_line=one_line.replaceAll("\\[","");
		one_line=one_line.replaceAll("\\]","");
		String[] comma_split = comma_pattern.split(one_line);
		LinkedList<String> temp = new LinkedList();
		for(int p = 0; p < comma_split.length; p++){

			temp.add(comma_split[p].trim());
		}
		Collections.sort((List)temp);
		three_did_llps_3did.add(temp);
		
	}
		
    } 			
static String[][] log_intersect = {
{"PF00004,PF17862"},
{"PF00005,PF00664"},
{"PF00011,PF00525"},
{"PF00012,PF02179"},
{"PF00016,PF00101,PF02788"},
{"PF00017,PF00018"},
{"PF00017,PF00018,PF07714"},
{"PF00021,PF01289,PF17440"},
{"PF00022,PF00626"},
{"PF00022,PF02181"},
{"PF00022,PF02755"},
{"PF00023,PF12796"},
{"PF00025,PF01369"},
{"PF00025,PF01465"},
{"PF00025,PF11527"},
{"PF00031,PF00112"},
{"PF00036,PF01023"},
{"PF00043,PF02798"},
{"PF00043,PF13417"},
{"PF00044,PF02800"},
{"PF00046,PF05920"},
{"PF00056,PF02866"},
{"PF00060,PF01094,PF10613"},
{"PF00060,PF10613"},
{"PF00069,PF00134,PF02984"},
{"PF00069,PF00433"},
{"PF00069,PF00627"},
{"PF00069,PF01335"},
{"PF00069,PF03261"},
{"PF00069,PF03941"},
{"PF00069,PF07686"},
{"PF00069,PF08332"},
{"PF00071,PF00169"},
{"PF00071,PF00621"},
{"PF00071,PF02115"},
{"PF00071,PF08337"},
{"PF00071,PF09457"},
{"PF00071,PF12796"},
{"PF00076,PF08075"},
{"PF00076,PF13869"},
{"PF00080,PF00403"},
{"PF00081,PF02777"},
{"PF00085,PF13848"},
{"PF00091,PF03953"},
{"PF00098,PF00313"},
{"PF00107,PF08240"},
{"PF00107,PF16884"},
{"PF00108,PF02803"},
{"PF00112,PF08127"},
{"PF00112,PF08773"},
{"PF00113,PF03952"},
{"PF00117,PF06418"},
{"PF00118,PF00166"},
{"PF00120,PF03951"},
{"PF00125,PF16211"},
{"PF00149,PF04152"},
{"PF00149,PF08321"},
{"PF00149,PF15276,PF16891"},
{"PF00149,PF16891"},
{"PF00169,PF16746"},
{"PF00170,PF07716"},
{"PF00175,PF00970"},
{"PF00179,PF14570"},
{"PF00183,PF02518"},
{"PF00185,PF02729"},
{"PF00206,PF10397"},
{"PF00206,PF10415"},
{"PF00208,PF02812"},
{"PF00224,PF02887"},
{"PF00226,PF01556"},
{"PF00233,PF01590"},
{"PF00240,PF00443"},
{"PF00240,PF01088"},
{"PF00270,PF00271"},
{"PF00270,PF00271,PF02854"},
{"PF00271,PF09532"},
{"PF00324,PF03522"},
{"PF00349,PF03727"},
{"PF00373,PF09379,PF09380"},
{"PF00378,PF00725,PF02737"},
{"PF00385,PF00628"},
{"PF00390,PF03949"},
{"PF00393,PF03446"},
{"PF00397,PF15498"},
{"PF00400,PF12265"},
{"PF00438,PF02772,PF02773"},
{"PF00439,PF00628"},
{"PF00449,PF01979"},
{"PF00479,PF02781"},
{"PF00498,PF16183"},
{"PF00503,PF00615"},
{"PF00503,PF09128"},
{"PF00505,PF09011"},
{"PF00514,PF01749,PF16186"},
{"PF00515,PF13414"},
{"PF00534,PF00862"},
{"PF00543,PF00696"},
{"PF00554,PF16179"},
{"PF00557,PF05195"},
{"PF00565,PF00567"},
{"PF00578,PF02195,PF10417"},
{"PF00578,PF10417"},
{"PF00587,PF02403"},
{"PF00612,PF13499"},
{"PF00650,PF03765"},
{"PF00651,PF00888,PF07707"},
{"PF00658,PF07145"},
{"PF00670,PF05221"},
{"PF00676,PF02779,PF02780"},
{"PF00705,PF02747"},
{"PF00725,PF02737"},
{"PF00731,PF01259"},
{"PF00763,PF02882"},
{"PF00781,PF19279"},
{"PF00782,PF14671"},
{"PF00808,PF02045"},
{"PF00853,PF02312"},
{"PF00856,PF05033"},
{"PF00899,PF02991"},
{"PF00928,PF01217,PF01602"},
{"PF00995,PF04840"},
{"PF01118,PF02774"},
{"PF01233,PF02799"},
{"PF01368,PF02833"},
{"PF01379,PF03900"},
{"PF01380,PF13522"},
{"PF01394,PF09268,PF13838"},
{"PF01398,PF08084"},
{"PF01564,PF17284"},
{"PF01652,PF05456"},
{"PF01717,PF08267"},
{"PF01729,PF02749"},
{"PF01808,PF02142"},
{"PF01926,PF06071"},
{"PF02171,PF16487"},
{"PF02210,PF06312"},
{"PF02263,PF02841"},
{"PF02798,PF13410"},
{"PF02798,PF14497"},
{"PF02902,PF11976"},
{"PF03171,PF14226"},
{"PF03178,PF10433"},
{"PF03357,PF04652"},
{"PF03435,PF16653"},
{"PF03446,PF14833"},
{"PF03556,PF10557"},
{"PF03568,PF04856"},
{"PF03657,PF17833"},
{"PF03807,PF14748"},
{"PF03828,PF19088"},
{"PF03966,PF08241"},
{"PF04054,PF04153"},
{"PF04078,PF12842"},
{"PF05652,PF11969"},
{"PF06337,PF14836"},
{"PF07738,PF10541,PF18580"},
{"PF08240,PF13602"},
{"PF10637,PF13661"},
{"PF12424,PF13499"},
{"PF12796,PF13857"},
{"PF13374,PF13424"},
{"PF13410,PF13417"},
{"PF13414,PF13844"},
{"PF13499,PF13833"},
{"PF13793,PF14572"},
{"PF14604,PF19745"},
{"PF14822,PF15674"}
};
static String[] llps_pfam = {"PF00001","PF00003","PF00004","PF00005","PF00006","PF00008","PF00009","PF00011","PF00012","PF00013","PF00014","PF00017","PF00018","PF00021","PF00022","PF00023","PF00025","PF00027","PF00028","PF00031","PF00034","PF00035","PF00036","PF00038","PF00040","PF00041","PF00043","PF00044","PF00045","PF00046","PF00047","PF00048","PF00050","PF00053","PF00055","PF00056","PF00057","PF00059","PF00060","PF00061","PF00062","PF00063","PF00066","PF00069","PF00071","PF00074","PF00075","PF00076","PF00078","PF00079","PF00080","PF00081","PF00082","PF00083","PF00084","PF00085","PF00086","PF00087","PF00089","PF00090","PF00091","PF00096","PF00097","PF00098","PF00101","PF00102","PF00104","PF00105","PF00106","PF00107","PF00108","PF00109","PF00112","PF00113","PF00116","PF00117","PF00118","PF00120","PF00121","PF00122","PF00125","PF00128","PF00129","PF00130","PF00132","PF00134","PF00135","PF00136","PF00137","PF00145","PF00147","PF00149","PF00152","PF00155","PF00157","PF00160","PF00162","PF00163","PF00164","PF00166","PF00167","PF00168","PF00169","PF00170","PF00171","PF00173","PF00175","PF00176","PF00177","PF00178","PF00179","PF00180","PF00181","PF00183","PF00185","PF00188","PF00189","PF00191","PF00194","PF00198","PF00200","PF00202","PF00203","PF00204","PF00205","PF00206","PF00207","PF00208","PF00209","PF00210","PF00215","PF00217","PF00219","PF00224","PF00225","PF00226","PF00227","PF00230","PF00233","PF00235","PF00237","PF00238","PF00240","PF00241","PF00244","PF00248","PF00249","PF00251","PF00252","PF00254","PF00255","PF00261","PF00262","PF00266","PF00268","PF00270","PF00271","PF00273","PF00274","PF00275","PF00276","PF00278","PF00281","PF00282","PF00285","PF00287","PF00289","PF00291","PF00293","PF00294","PF00295","PF00297","PF00298","PF00300","PF00307","PF00312","PF00313","PF00317","PF00318","PF00324","PF00326","PF00327","PF00329","PF00333","PF00334","PF00335","PF00337","PF00338","PF00339","PF00341","PF00342","PF00343","PF00344","PF00346","PF00347","PF00348","PF00349","PF00350","PF00352","PF00354","PF00355","PF00362","PF00364","PF00365","PF00366","PF00373","PF00375","PF00378","PF00380","PF00382","PF00383","PF00384","PF00385","PF00386","PF00389","PF00390","PF00393","PF00394","PF00397","PF00398","PF00400","PF00405","PF00406","PF00410","PF00411","PF00412","PF00413","PF00415","PF00416","PF00418","PF00428","PF00433","PF00435","PF00436","PF00438","PF00439","PF00443","PF00445","PF00447","PF00448","PF00452","PF00453","PF00454","PF00456","PF00458","PF00459","PF00462","PF00464","PF00466","PF00467","PF00474","PF00479","PF00483","PF00485","PF00488","PF00491","PF00493","PF00498","PF00503","PF00504","PF00505","PF00514","PF00515","PF00520","PF00521","PF00525","PF00531","PF00533","PF00534","PF00536","PF00538","PF00542","PF00543","PF00549","PF00550","PF00551","PF00554","PF00557","PF00560","PF00562","PF00564","PF00565","PF00566","PF00567","PF00568","PF00569","PF00570","PF00571","PF00572","PF00573","PF00574","PF00575","PF00578","PF00579","PF00581","PF00582","PF00583","PF00587","PF00588","PF00595","PF00610","PF00611","PF00612","PF00613","PF00614","PF00615","PF00616","PF00617","PF00618","PF00619","PF00620","PF00621","PF00622","PF00623","PF00625","PF00626","PF00627","PF00628","PF00630","PF00631","PF00632","PF00634","PF00635","PF00636","PF00638","PF00639","PF00640","PF00641","PF00642","PF00643","PF00644","PF00645","PF00646","PF00647","PF00648","PF00650","PF00651","PF00653","PF00654","PF00656","PF00657","PF00658","PF00659","PF00664","PF00666","PF00670","PF00673","PF00675","PF00676","PF00679","PF00681","PF00682","PF00684","PF00687","PF00689","PF00690","PF00698","PF00702","PF00704","PF00705","PF00709","PF00714","PF00719","PF00725","PF00730","PF00731","PF00735","PF00736","PF00749","PF00750","PF00752","PF00753","PF00754","PF00755","PF00758","PF00763","PF00766","PF00769","PF00773","PF00778","PF00779","PF00781","PF00782","PF00786","PF00787","PF00788","PF00789","PF00790","PF00791","PF00792","PF00794","PF00806","PF00811","PF00822","PF00827","PF00828","PF00831","PF00832","PF00833","PF00838","PF00849","PF00850","PF00853","PF00855","PF00856","PF00862","PF00867","PF00868","PF00870","PF00887","PF00888","PF00899","PF00900","PF00903","PF00917","PF00920","PF00923","PF00927","PF00928","PF00930","PF00932","PF00935","PF00940","PF00955","PF00956","PF00957","PF00970","PF00975","PF00977","PF00988","PF00994","PF00995","PF01000","PF01008","PF01012","PF01015","PF01017","PF01020","PF01023","PF01028","PF01031","PF01039","PF01042","PF01044","PF01048","PF01064","PF01068","PF01080","PF01084","PF01088","PF01090","PF01092","PF01094","PF01096","PF01112","PF01115","PF01118","PF01119","PF01126","PF01131","PF01133","PF01135","PF01137","PF01138","PF01139","PF01145","PF01149","PF01151","PF01153","PF01157","PF01158","PF01159","PF01161","PF01163","PF01172","PF01176","PF01182","PF01189","PF01191","PF01192","PF01193","PF01194","PF01196","PF01198","PF01199","PF01200","PF01201","PF01209","PF01214","PF01215","PF01217","PF01221","PF01230","PF01237","PF01241","PF01245","PF01246","PF01247","PF01248","PF01249","PF01251","PF01253","PF01257","PF01259","PF01267","PF01269","PF01280","PF01282","PF01283","PF01287","PF01291","PF01294","PF01296","PF01302","PF01323","PF01327","PF01335","PF01336","PF01342","PF01344","PF01363","PF01365","PF01368","PF01369","PF01370","PF01379","PF01380","PF01381","PF01388","PF01392","PF01393","PF01394","PF01398","PF01399","PF01403","PF01404","PF01408","PF01409","PF01410","PF01411","PF01412","PF01416","PF01417","PF01421","PF01423","PF01424","PF01426","PF01429","PF01434","PF01436","PF01437","PF01442","PF01448","PF01451","PF01454","PF01459","PF01465","PF01466","PF01472","PF01479","PF01480","PF01496","PF01504","PF01505","PF01509","PF01512","PF01535","PF01556","PF01557","PF01564","PF01565","PF01575","PF01585","PF01588","PF01590","PF01593","PF01596","PF01599","PF01602","PF01603","PF01608","PF01612","PF01624","PF01625","PF01648","PF01652","PF01655","PF01661","PF01663","PF01667","PF01693","PF01704","PF01712","PF01713","PF01716","PF01717","PF01728","PF01729","PF01746","PF01747","PF01749","PF01751","PF01756","PF01759","PF01765","PF01775","PF01776","PF01777","PF01778","PF01779","PF01781","PF01798","PF01805","PF01808","PF01813","PF01821","PF01825","PF01833","PF01834","PF01835","PF01841","PF01842","PF01843","PF01846","PF01849","PF01851","PF01852","PF01853","PF01857","PF01858","PF01868","PF01869","PF01873","PF01876","PF01878","PF01896","PF01900","PF01907","PF01909","PF01912","PF01918","PF01920","PF01922","PF01926","PF01929","PF01936","PF01946","PF01965","PF01966","PF01979","PF01991","PF01992","PF02002","PF02008","PF02020","PF02023","PF02026","PF02036","PF02037","PF02045","PF02078","PF02109","PF02121","PF02135","PF02136","PF02137","PF02140","PF02142","PF02145","PF02146","PF02148","PF02149","PF02150","PF02155","PF02167","PF02170","PF02171","PF02172","PF02177","PF02179","PF02180","PF02181","PF02182","PF02185","PF02186","PF02187","PF02188","PF02190","PF02191","PF02192","PF02196","PF02197","PF02198","PF02201","PF02205","PF02209","PF02210","PF02212","PF02213","PF02214","PF02229","PF02234","PF02245","PF02251","PF02252","PF02259","PF02260","PF02263","PF02270","PF02271","PF02272","PF02274","PF02284","PF02290","PF02295","PF02296","PF02297","PF02301","PF02312","PF02320","PF02330","PF02348","PF02359","PF02362","PF02368","PF02373","PF02375","PF02390","PF02403","PF02423","PF02436","PF02463","PF02507","PF02518","PF02536","PF02598","PF02605","PF02629","PF02630","PF02729","PF02731","PF02735","PF02736","PF02737","PF02747","PF02749","PF02750","PF02752","PF02755","PF02758","PF02759","PF02770","PF02772","PF02773","PF02774","PF02775","PF02776","PF02777","PF02779","PF02780","PF02781","PF02784","PF02785","PF02786","PF02787","PF02790","PF02792","PF02798","PF02800","PF02801","PF02803","PF02807","PF02809","PF02812","PF02815","PF02817","PF02824","PF02825","PF02826","PF02828","PF02833","PF02841","PF02845","PF02847","PF02852","PF02854","PF02861","PF02864","PF02865","PF02866","PF02867","PF02872","PF02874","PF02877","PF02881","PF02882","PF02883","PF02887","PF02889","PF02891","PF02911","PF02919","PF02921","PF02922","PF02928","PF02931","PF02932","PF02933","PF02936","PF02937","PF02938","PF02946","PF02953","PF02961","PF02984","PF02985","PF02991","PF02996","PF03002","PF03024","PF03028","PF03061","PF03066","PF03068","PF03081","PF03096","PF03097","PF03098","PF03104","PF03114","PF03127","PF03129","PF03133","PF03143","PF03144","PF03159","PF03165","PF03166","PF03171","PF03177","PF03178","PF03179","PF03188","PF03199","PF03200","PF03215","PF03221","PF03223","PF03224","PF03234","PF03244","PF03256","PF03259","PF03271","PF03281","PF03297","PF03344","PF03345","PF03357","PF03360","PF03366","PF03368","PF03372","PF03398","PF03399","PF03435","PF03439","PF03446","PF03463","PF03464","PF03465","PF03467","PF03477","PF03483","PF03484","PF03485","PF03491","PF03494","PF03501","PF03511","PF03520","PF03522","PF03531","PF03542","PF03568","PF03587","PF03604","PF03607","PF03623","PF03635","PF03637","PF03643","PF03657","PF03719","PF03725","PF03726","PF03727","PF03730","PF03731","PF03736","PF03764","PF03765","PF03800","PF03801","PF03807","PF03810","PF03813","PF03822","PF03828","PF03849","PF03853","PF03868","PF03870","PF03871","PF03874","PF03876","PF03900","PF03909","PF03911","PF03914","PF03917","PF03921","PF03931","PF03932","PF03939","PF03941","PF03943","PF03946","PF03947","PF03949","PF03950","PF03951","PF03952","PF03953","PF03966","PF03985","PF03998","PF03999","PF04000","PF04003","PF04006","PF04030","PF04032","PF04037","PF04045","PF04046","PF04051","PF04053","PF04054","PF04056","PF04062","PF04063","PF04064","PF04065","PF04078","PF04084","PF04086","PF04096","PF04130","PF04135","PF04146","PF04147","PF04152","PF04153","PF04158","PF04189","PF04192","PF04212","PF04218","PF04275","PF04280","PF04300","PF04388","PF04408","PF04410","PF04423","PF04427","PF04433","PF04438","PF04525","PF04536","PF04548","PF04557","PF04558","PF04560","PF04561","PF04563","PF04564","PF04565","PF04566","PF04567","PF04574","PF04588","PF04597","PF04615","PF04652","PF04675","PF04678","PF04679","PF04683","PF04716","PF04727","PF04729","PF04752","PF04762","PF04774","PF04795","PF04803","PF04810","PF04811","PF04815","PF04818","PF04824","PF04825","PF04851","PF04856","PF04857","PF04869","PF04900","PF04934","PF04935","PF04938","PF04950","PF04960","PF04968","PF04969","PF04970","PF04981","PF04983","PF04990","PF04992","PF04997","PF04998","PF05000","PF05001","PF05008","PF05026","PF05028","PF05033","PF05047","PF05064","PF05071","PF05091","PF05127","PF05147","PF05148","PF05168","PF05179","PF05182","PF05185","PF05188","PF05189","PF05190","PF05191","PF05192","PF05193","PF05195","PF05221","PF05240","PF05291","PF05301","PF05326","PF05327","PF05347","PF05348","PF05362","PF05368","PF05383","PF05406","PF05456","PF05470","PF05486","PF05615","PF05625","PF05641","PF05652","PF05676","PF05700","PF05706","PF05712","PF05724","PF05743","PF05746","PF05773","PF05783","PF05793","PF05817","PF05821","PF05856","PF05881","PF05890","PF05891","PF05918","PF05920","PF05923","PF05924","PF05964","PF05965","PF05972","PF05997","PF06001","PF06017","PF06047","PF06058","PF06068","PF06071","PF06110","PF06201","PF06212","PF06220","PF06229","PF06244","PF06268","PF06325","PF06337","PF06367","PF06371","PF06372","PF06417","PF06418","PF06459","PF06461","PF06465","PF06470","PF06479","PF06480","PF06487","PF06522","PF06544","PF06631","PF06657","PF06701","PF06703","PF06732","PF06733","PF06747","PF06777","PF06816","PF06831","PF06858","PF06870","PF06881","PF06883","PF06920","PF06957","PF06978","PF06984","PF06991","PF07145","PF07159","PF07177","PF07202","PF07225","PF07289","PF07347","PF07412","PF07496","PF07500","PF07521","PF07528","PF07529","PF07533","PF07539","PF07540","PF07541","PF07562","PF07565","PF07569","PF07574","PF07575","PF07645","PF07647","PF07650","PF07653","PF07654","PF07677","PF07678","PF07679","PF07684","PF07686","PF07690","PF07703","PF07707","PF07710","PF07714","PF07717","PF07724","PF07728","PF07731","PF07732","PF07738","PF07774","PF07807","PF07808","PF07809","PF07815","PF07817","PF07834","PF07890","PF07933","PF07934","PF07965","PF07974","PF07975","PF07986","PF07989","PF07992","PF08005","PF08007","PF08016","PF08033","PF08059","PF08063","PF08064","PF08066","PF08068","PF08069","PF08070","PF08071","PF08072","PF08073","PF08074","PF08075","PF08079","PF08082","PF08083","PF08084","PF08122","PF08127","PF08142","PF08144","PF08145","PF08146","PF08148","PF08149","PF08152","PF08153","PF08154","PF08155","PF08156","PF08157","PF08159","PF08163","PF08164","PF08170","PF08174","PF08205","PF08208","PF08210","PF08214","PF08216","PF08228","PF08236","PF08240","PF08241","PF08242","PF08243","PF08244","PF08266","PF08267","PF08271","PF08282","PF08297","PF08312","PF08326","PF08327","PF08332","PF08337","PF08344","PF08351","PF08355","PF08356","PF08375","PF08385","PF08389","PF08393","PF08397","PF08399","PF08403","PF08423","PF08442","PF08447","PF08454","PF08473","PF08477","PF08492","PF08512","PF08513","PF08514","PF08515","PF08516","PF08519","PF08523","PF08526","PF08527","PF08534","PF08536","PF08542","PF08543","PF08558","PF08563","PF08564","PF08565","PF08567","PF08572","PF08584","PF08585","PF08597","PF08603","PF08606","PF08623","PF08624","PF08625","PF08640","PF08644","PF08646","PF08652","PF08659","PF08662","PF08675","PF08683","PF08698","PF08699","PF08701","PF08702","PF08709","PF08711","PF08712","PF08725","PF08726","PF08746","PF08752","PF08758","PF08766","PF08767","PF08771","PF08772","PF08773","PF08776","PF08777","PF08778","PF08783","PF08785","PF08790","PF08797","PF08799","PF08801","PF08824","PF08880","PF08911","PF08912","PF08913","PF08914","PF08919","PF08920","PF08953","PF08996","PF09011","PF09036","PF09038","PF09058","PF09066","PF09079","PF09088","PF09090","PF09110","PF09111","PF09141","PF09162","PF09165","PF09173","PF09180","PF09197","PF09202","PF09229","PF09237","PF09268","PF09280","PF09286","PF09292","PF09325","PF09326","PF09334","PF09336","PF09358","PF09360","PF09368","PF09377","PF09379","PF09380","PF09382","PF09384","PF09398","PF09405","PF09409","PF09416","PF09420","PF09429","PF09431","PF09432","PF09439","PF09440","PF09454","PF09457","PF09465","PF09470","PF09532","PF09635","PF09735","PF09736","PF09740","PF09748","PF09770","PF09782","PF09783","PF09785","PF09812","PF10037","PF10075","PF10163","PF10168","PF10169","PF10175","PF10183","PF10187","PF10205","PF10208","PF10212","PF10249","PF10255","PF10259","PF10276","PF10291","PF10357","PF10369","PF10373","PF10374","PF10395","PF10409","PF10415","PF10417","PF10421","PF10431","PF10433","PF10436","PF10444","PF10447","PF10456","PF10482","PF10515","PF10522","PF10523","PF10531","PF10557","PF10559","PF10568","PF10584","PF10585","PF10587","PF10588","PF10589","PF10596","PF10597","PF10598","PF10600","PF10602","PF10607","PF10608","PF10613","PF10637","PF10744","PF10785","PF10996","PF11095","PF11221","PF11262","PF11413","PF11414","PF11521","PF11532","PF11540","PF11544","PF11577","PF11608","PF11626","PF11627","PF11629","PF11640","PF11648","PF11698","PF11715","PF11717","PF11718","PF11732","PF11778","PF11801","PF11816","PF11831","PF11835","PF11841","PF11864","PF11865","PF11894","PF11919","PF11931","PF11934","PF11935","PF11942","PF11957","PF11969","PF11976","PF11987","PF12009","PF12024","PF12030","PF12047","PF12052","PF12066","PF12108","PF12110","PF12125","PF12134","PF12148","PF12152","PF12153","PF12162","PF12165","PF12171","PF12178","PF12179","PF12180","PF12185","PF12194","PF12196","PF12202","PF12205","PF12209","PF12210","PF12220","PF12230","PF12265","PF12295","PF12308","PF12328","PF12338","PF12348","PF12352","PF12353","PF12357","PF12372","PF12397","PF12424","PF12465","PF12513","PF12515","PF12534","PF12589","PF12619","PF12643","PF12678","PF12697","PF12701","PF12738","PF12743","PF12756","PF12763","PF12765","PF12774","PF12775","PF12777","PF12780","PF12781","PF12796","PF12799","PF12815","PF12830","PF12838","PF12842","PF12848","PF12850","PF12859","PF12872","PF12874","PF12894","PF12895","PF12923","PF12924","PF12925","PF12937","PF13012","PF13085","PF13086","PF13087","PF13097","PF13176","PF13177","PF13180","PF13181","PF13202","PF13234","PF13246","PF13297","PF13299","PF13306","PF13307","PF13339","PF13360","PF13365","PF13374","PF13405","PF13409","PF13410","PF13414","PF13417","PF13419","PF13424","PF13432","PF13445","PF13460","PF13481","PF13489","PF13499","PF13510","PF13513","PF13516","PF13519","PF13522","PF13561","PF13589","PF13602","PF13637","PF13638","PF13639","PF13646","PF13649","PF13656","PF13661","PF13696","PF13710","PF13716","PF13718","PF13725","PF13765","PF13768","PF13771","PF13774","PF13793","PF13833","PF13838","PF13844","PF13848","PF13855","PF13857","PF13862","PF13869","PF13893","PF13895","PF13907","PF13909","PF13912","PF13919","PF13920","PF13921","PF13923","PF13927","PF13934","PF13949","PF13959","PF14204","PF14226","PF14260","PF14304","PF14306","PF14324","PF14370","PF14374","PF14382","PF14396","PF14429","PF14447","PF14492","PF14497","PF14520","PF14523","PF14538","PF14551","PF14559","PF14570","PF14572","PF14580","PF14604","PF14608","PF14619","PF14622","PF14631","PF14632","PF14633","PF14634","PF14635","PF14639","PF14641","PF14671","PF14674","PF14675","PF14676","PF14677","PF14678","PF14679","PF14680","PF14693","PF14700","PF14705","PF14709","PF14721","PF14732","PF14748","PF14749","PF14779","PF14826","PF14833","PF14835","PF14836","PF14887","PF14943","PF15007","PF15017","PF15019","PF15028","PF15247","PF15375","PF15410","PF15433","PF15454","PF15459","PF15499","PF15663","PF15684","PF15692","PF15693","PF15694","PF15785","PF15798","PF15801","PF15865","PF15901","PF15902","PF15963","PF15985","PF16004","PF16028","PF16050","PF16095","PF16113","PF16114","PF16121","PF16122","PF16123","PF16124","PF16134","PF16158","PF16172","PF16174","PF16179","PF16186","PF16190","PF16191","PF16195","PF16197","PF16198","PF16205","PF16207","PF16209","PF16211","PF16212","PF16274","PF16275","PF16276","PF16300","PF16320","PF16366","PF16367","PF16381","PF16399","PF16413","PF16415","PF16417","PF16418","PF16419","PF16450","PF16453","PF16454","PF16471","PF16474","PF16482","PF16484","PF16486","PF16487","PF16488","PF16489","PF16495","PF16500","PF16507","PF16511","PF16512","PF16515","PF16516","PF16517","PF16521","PF16531","PF16540","PF16544","PF16547","PF16550","PF16553","PF16558","PF16562","PF16568","PF16577","PF16579","PF16589","PF16609","PF16623","PF16652","PF16653","PF16661","PF16672","PF16673","PF16687","PF16689","PF16705","PF16717","PF16739","PF16741","PF16744","PF16746","PF16752","PF16759","PF16770","PF16772","PF16780","PF16796","PF16835","PF16837","PF16843","PF16856","PF16866","PF16870","PF16880","PF16884","PF16886","PF16891","PF16897","PF16898","PF16906","PF16920","PF16923","PF16953","PF16969","PF17004","PF17035","PF17047","PF17125","PF17144","PF17146","PF17205","PF17207","PF17215","PF17216","PF17229","PF17250","PF17284","PF17285","PF17286","PF17292","PF17403","PF17404","PF17405","PF17406","PF17407","PF17490","PF17674","PF17681","PF17683","PF17759","PF17772","PF17777","PF17781","PF17789","PF17790","PF17791","PF17797","PF17799","PF17800","PF17807","PF17809","PF17811","PF17814","PF17815","PF17820","PF17830","PF17832","PF17833","PF17835","PF17838","PF17840","PF17846","PF17848","PF17849","PF17852","PF17855","PF17856","PF17857","PF17862","PF17865","PF17867","PF17871","PF17872","PF17875","PF17877","PF17888","PF17902","PF17903","PF17904","PF17905","PF17907","PF17911","PF17913","PF17942","PF17947","PF17959","PF17960","PF17976","PF17978","PF17981","PF17982","PF18004","PF18005","PF18020","PF18031","PF18038","PF18044","PF18048","PF18051","PF18055","PF18077","PF18102","PF18109","PF18111","PF18114","PF18119","PF18121","PF18122","PF18129","PF18131","PF18141","PF18147","PF18148","PF18149","PF18150","PF18190","PF18196","PF18198","PF18199","PF18245","PF18262","PF18263","PF18290","PF18293","PF18307","PF18311","PF18314","PF18323","PF18325","PF18332","PF18334","PF18336","PF18346","PF18360","PF18372","PF18373","PF18375","PF18385","PF18386","PF18391","PF18392","PF18394","PF18396","PF18397","PF18409","PF18414","PF18420","PF18428","PF18436","PF18452","PF18455","PF18485","PF18503","PF18507","PF18514","PF18520","PF18521","PF18531","PF18544","PF18552","PF18553","PF18554","PF18569","PF18580","PF18596","PF18606","PF18609","PF18613","PF18633","PF18694","PF18704","PF18770","PF18777","PF18779","PF18784","PF18787","PF18797","PF18808","PF18816","PF18826","PF18829","PF18911","PF19047","PF19088","PF19273","PF19303","PF19326","PF19340","PF19440","PF19445","PF19521","PF19704","PF19712","PF19745","PF20145","PF20168","PF20170","PF20266","PF20268","PF20416","PF20421","PF20422","PF20492","PF20502","PF20514","PF20518","PF20519"};

	static String[] lig_pfam_list = {"PF00244","PF01257","PF00001","PF00004","PF00005","PF00583","PF08674","PF00022","PF16579","PF05641","PF12165","PF01593","PF00266","PF04739","PF12895","PF00023","PF12796","PF00514","PF04729","PF00026","PF02991","PF00231","PF00430","PF00401","PF08517","PF01603","PF01426","PF00452","PF11502","PF17035","PF00653","PF03099","PF00533","PF03097","PF00439","PF02214","PF09270","PF07654","PF12265","PF02045","PF02762","PF02933","PF09079","PF15511","PF00307","PF09295","PF00504","PF00385","PF01393","PF04818","PF15800","PF05347","PF00118","PF12539","PF18392","PF00888","PF13621","PF00134","PF07478","PF01820","PF06058","PF01556","PF02767","PF02768","PF03604","PF05186","PF14671","PF07039","PF01221","PF12180","PF03271","PF00036","PF12763","PF13499","PF13833","PF10163","PF01404","PF10447","PF09380","PF00373","PF03781","PF00498","PF17913","PF00147","PF00630","PF00039","PF00041","PF03623","PF13844","PF06212","PF00009","PF04670","PF00625","PF02213","PF13646","PF00125","PF16211","PF02301","PF00104","PF02793","PF00011","PF00012","PF04568","PF10480","PF01652","PF13895","PF00049","PF00362","PF00520","PF10401","PF02174","PF17811","PF02373","PF08007","PF01344","PF02172","PF03731","PF16672","PF10437","PF01423","PF03194","PF02847","PF08923","PF00917","PF02820","PF04678","PF09637","PF05053","PF05891","PF00993","PF00969","PF04212","PF13012","PF03637","PF01618","PF00635","PF05712","PF00146","PF07555","PF05071","PF11577","PF03031","PF01592","PF02799","PF02898","PF02136","PF00213","PF00658","PF02671","PF01399","PF02747","PF00705","PF00341","PF00595","PF17820","PF00656","PF01433","PF00413","PF05193","PF01401","PF00628","PF08567","PF00640","PF00069","PF07714","PF17285","PF00235","PF00160","PF00227","PF10584","PF04683","PF12738","PF00806","PF00855","PF09311","PF11976","PF00071","PF01857","PF01030","PF08661","PF00072","PF16727","PF14622","PF02867","PF00428","PF01294","PF01775","PF01245","PF00828","PF01777","PF00327","PF08079","PF00573","PF00338","PF00253","PF00366","PF00833","PF00203","PF03297","PF00410","PF02197","PF09511","PF01193","PF04997","PF04983","PF04998","PF04560","PF03874","PF01192","PF03870","PF01138","PF18261","PF00076","PF16770","PF01479","PF12209","PF00995","PF03911","PF02556","PF00079","PF00856","PF00017","PF00018","PF07653","PF14604","PF03876","PF03145","PF02146","PF02731","PF07525","PF08286","PF00622","PF04722","PF05076","PF12470","PF02201","PF04433","PF16495","PF08231","PF00957","PF00804","PF15219","PF03849","PF00382","PF02291","PF00085","PF01833","PF00229","PF01751","PF00515","PF13414","PF13424","PF13176","PF13181","PF08558","PF08302","PF08303","PF00261","PF00992","PF00089","PF12148","PF00567","PF18104","PF06087","PF00240","PF02271","PF05743","PF03671","PF00021","PF12436","PF17211","PF00790","PF01044","PF07686","PF00092","PF00400","PF00568","PF00397","PF09280","PF17725","PF03366","PF00102","PF07496","PF02148"};

static String[] col_name_13 = {"ddi_num","dmi_num","howmany_regions","region_one_count","region_one_count_div_by_howmany_regions","per_region_std","per_region_mean","per_region_skew","per_region_kurto","res_num","res_num_div_by_howmany_regions","oligo_num","oligomerization_uniq_arch_max"};

static LinkedList<String> llps_array_list;
static LinkedList<String> lig_array_list;


static LinkedHashMap<LinkedList<String>, LinkedList<String>[]> three_did_comp;
static LinkedHashMap<LinkedList<String>, String> three_did_llps;
static LinkedHashMap<LinkedList<String>, String> three_did_lig;

void create_llps_list() throws IOException{

	System.out.println("create_llps_list()");

	lig_array_list = new LinkedList();
	llps_array_list = new LinkedList();
	

	for(int i = 0; i < lig_pfam_list.length; i++){

		lig_array_list.add(lig_pfam_list[i]);
		
	}

	for(int i = 0; i < llps_pfam.length; i++){


		llps_array_list.add(llps_pfam[i]);
	}

}
void do_three_did_comp() throws IOException{

	System.out.println("do_three_did_comp()");

	Pattern space_pattern = Pattern.compile("\\s+");
	Pattern tab_pattern = Pattern.compile("	");
	Pattern comma_pattern = Pattern.compile(",");
	Pattern colon_pattern = Pattern.compile(":");

	three_did_comp = new LinkedHashMap();
	three_did_llps = new LinkedHashMap();
	three_did_lig = new LinkedHashMap();

	
	String path = "data/out_three_did_domain_to_pfam_make_interface_dimers_cross_protcad_uniq_arch.final.intersect.protcad.uniqarch";
		
	List<String> lines  = FileUtils.readLines(new File(path));
		
	for(int z = 0; z < lines.size(); z++){
		
			String one_line = lines.get(z);
			////System.out.println(one_line);
			
			String[] one_line_tab = colon_pattern.split(one_line);

			String all_pfams = one_line_tab[0].trim();
			all_pfams=all_pfams.replaceAll("\\[","");
			all_pfams=all_pfams.replaceAll("\\]","");

			String nr_pfams = one_line_tab[1].trim();
			nr_pfams=nr_pfams.replaceAll("\\[","");
			nr_pfams=nr_pfams.replaceAll("\\]","");

			LinkedList<String> all_array = new LinkedList();
			String[] one_line_comma = comma_pattern.split(all_pfams);

			for(int p = 0; p < one_line_comma.length; p++){

				one_line_comma[p] = one_line_comma[p].trim();
				all_array.add(one_line_comma[p]);
			}

			LinkedList<String> nr_array = new LinkedList();
			one_line_comma = comma_pattern.split(nr_pfams);

			for(int p = 0; p < one_line_comma.length; p++){

				one_line_comma[p] = one_line_comma[p].trim();
				nr_array.add(one_line_comma[p]);
			}

			Collections.sort((List)all_array);
			Collections.sort((List)nr_array);


			List<String> s1 = nr_array.stream().filter(llps_array_list::contains).collect(Collectors.toList());

			if(s1.size() >1){
				
				three_did_llps.put(nr_array,"llps_"+s1.size());
			}else{
				three_did_llps.put(nr_array,"llps_0");
			}

			/*newlist = new LinkedList<>(nr_array);
			s1 = new HashSet<String>((List)newlist);
			s2 = new HashSet<String>((List)lig_array_list);
			s1.retainAll(s2);*/

			s1 = nr_array.stream().filter(lig_array_list::contains).collect(Collectors.toList());

			if(s1.size() >1){
				
				three_did_lig.put(nr_array,"lig_"+s1.size());
			}else{
				three_did_lig.put(nr_array,"lig_0");
			}

			int cat_ind = -1;

			if(all_array.size() == nr_array.size()){

				cat_ind = 0;

			}else{

				cat_ind = 1;
			}
			
			if(three_did_comp.containsKey(nr_array)){

				
				LinkedList<String>[] exist = three_did_comp.get(nr_array);
	

				if(exist[cat_ind] == null){

					exist[cat_ind] = new LinkedList();
				}

				exist[cat_ind].add(one_line_tab[2]);
				three_did_comp.put(nr_array,exist);

			}else{

				LinkedList<String>[] exist = new LinkedList[2];
				exist[cat_ind] = new LinkedList();
				exist[cat_ind].add(one_line_tab[2]);
				three_did_comp.put(nr_array,exist);
			}

			//}//three_did_llps_3did contains
			
		}//z
								
}
}//class

static class llps_go_analysis {

  

		
////////////////////

static String[] nucleus_atxg_llps_pfam = {"PF00004","PF00005","PF00006","PF00009","PF00010","PF00012","PF00013","PF00022","PF00023","PF00025","PF00034","PF00043","PF00044","PF00046","PF00056","PF00067","PF00069","PF00071","PF00076","PF00082","PF00085","PF00091","PF00098","PF00101","PF00107","PF00112","PF00113","PF00118","PF00121","PF00122","PF00125","PF00132","PF00133","PF00134","PF00139","PF00152","PF00153","PF00156","PF00160","PF00166","PF00168","PF00169","PF00170","PF00173","PF00176","PF00177","PF00180","PF00181","PF00183","PF00185","PF00191","PF00199","PF00202","PF00213","PF00215","PF00225","PF00226","PF00227","PF00230","PF00235","PF00237","PF00240","PF00244","PF00249","PF00254","PF00255","PF00266","PF00270","PF00271","PF00274","PF00275","PF00278","PF00281","PF00291","PF00297","PF00298","PF00312","PF00330","PF00333","PF00334","PF00347","PF00350","PF00355","PF00365","PF00380","PF00382","PF00385","PF00389","PF00393","PF00394","PF00396","PF00400","PF00403","PF00408","PF00416","PF00430","PF00438","PF00443","PF00447","PF00456","PF00462","PF00464","PF00466","PF00467","PF00483","PF00493","PF00498","PF00501","PF00504","PF00505","PF00514","PF00521","PF00536","PF00544","PF00560","PF00562","PF00564","PF00578","PF00582","PF00583","PF00587","PF00614","PF00623","PF00627","PF00628","PF00632","PF00637","PF00638","PF00639","PF00641","PF00642","PF00647","PF00658","PF00670","PF00673","PF00676","PF00679","PF00690","PF00694","PF00702","PF00705","PF00719","PF00749","PF00759","PF00808","PF00831","PF00833","PF00838","PF00855","PF00856","PF00888","PF00890","PF00899","PF00923","PF00956","PF00957","PF00962","PF00984","PF00995","PF01000","PF01015","PF01020","PF01031","PF01042","PF01055","PF01084","PF01090","PF01096","PF01103","PF01133","PF01138","PF01159","PF01179","PF01189","PF01191","PF01193","PF01200","PF01201","PF01246","PF01248","PF01269","PF01280","PF01282","PF01293","PF01336","PF01344","PF01357","PF01370","PF01381","PF01394","PF01398","PF01399","PF01423","PF01434","PF01453","PF01459","PF01466","PF01472","PF01480","PF01509","PF01535","PF01566","PF01599","PF01652","PF01655","PF01749","PF01758","PF01778","PF01781","PF01798","PF01803","PF01805","PF01849","PF01851","PF01852","PF01875","PF01920","PF01926","PF01929","PF02136","PF02142","PF02167","PF02178","PF02201","PF02212","PF02213","PF02330","PF02359","PF02362","PF02373","PF02466","PF02518","PF02672","PF02701","PF02728","PF02729","PF02747","PF02772","PF02773","PF02779","PF02780","PF02784","PF02786","PF02787","PF02792","PF02798","PF02800","PF02809","PF02826","PF02854","PF02861","PF02866","PF02874","PF02878","PF02879","PF02880","PF02889","PF02910","PF02921","PF02933","PF02990","PF03097","PF03129","PF03141","PF03143","PF03144","PF03151","PF03159","PF03178","PF03214","PF03219","PF03223","PF03224","PF03330","PF03343","PF03345","PF03357","PF03358","PF03439","PF03446","PF03468","PF03470","PF03479","PF03657","PF03719","PF03720","PF03721","PF03725","PF03764","PF03789","PF03790","PF03791","PF03822","PF03868","PF03871","PF03909","PF03911","PF03931","PF03946","PF03947","PF03950","PF03952","PF03953","PF03985","PF03989","PF03998","PF03999","PF04000","PF04037","PF04043","PF04046","PF04051","PF04096","PF04097","PF04117","PF04130","PF04153","PF04258","PF04406","PF04408","PF04427","PF04504","PF04548","PF04560","PF04561","PF04563","PF04565","PF04570","PF04601","PF04627","PF04641","PF04674","PF04676","PF04677","PF04696","PF04755","PF04780","PF04781","PF04937","PF04959","PF04969","PF04983","PF04990","PF04992","PF04997","PF04998","PF05000","PF05001","PF05002","PF05022","PF05064","PF05221","PF05327","PF05470","PF05602","PF05664","PF05676","PF05699","PF05700","PF05753","PF05890","PF05918","PF05920","PF06012","PF06025","PF06047","PF06058","PF06102","PF06424","PF06461","PF06465","PF06628","PF06703","PF06858","PF06862","PF06870","PF06883","PF06886","PF06972","PF06984","PF07001","PF07058","PF07244","PF07500","PF07714","PF07716","PF07717","PF07724","PF07731","PF07732","PF07738","PF07939","PF07946","PF07977","PF08068","PF08069","PF08082","PF08083","PF08084","PF08149","PF08152","PF08155","PF08156","PF08246","PF08263","PF08264","PF08271","PF08355","PF08356","PF08375","PF08514","PF08523","PF08536","PF08542","PF08551","PF08567","PF08640","PF08642","PF08701","PF08711","PF08766","PF08911","PF08920","PF09032","PF09088","PF09090","PF09173","PF09180","PF09239","PF09268","PF09336","PF09358","PF09368","PF09405","PF09409","PF09420","PF09440","PF09728","PF09731","PF09785","PF09793","PF10250","PF10291","PF10417","PF10431","PF10433","PF10441","PF10447","PF10557","PF10584","PF10585","PF10596","PF10597","PF10598","PF10602","PF11255","PF11698","PF11831","PF11886","PF11931","PF11942","PF11987","PF12066","PF12108","PF12134","PF12165","PF12171","PF12230","PF12265","PF12338","PF12357","PF12554","PF12580","PF12763","PF12796","PF12848","PF12854","PF12874","PF12894","PF13041","PF13085","PF13181","PF13193","PF13202","PF13297","PF13301","PF13405","PF13410","PF13415","PF13418","PF13428","PF13499","PF13516","PF13519","PF13534","PF13656","PF13774","PF13793","PF13802","PF13812","PF13837","PF13838","PF13855","PF13874","PF13883","PF13921","PF13923","PF13934","PF13943","PF13949","PF14372","PF14377","PF14382","PF14497","PF14541","PF14543","PF14551","PF14572","PF14580","PF14604","PF14617","PF14619","PF14870","PF15519","PF15862","PF15906","PF15985","PF16004","PF16045","PF16186","PF16190","PF16191","PF16198","PF16211","PF16450","PF16835","PF16837","PF16863","PF16884","PF16886","PF16899","PF16906","PF16969","PF17125","PF17135","PF17207","PF17681","PF17777","PF17781","PF17800","PF17833","PF17835","PF17846","PF17855","PF17862","PF17871","PF18044","PF18051","PF18149","PF18264","PF19026"};




static LinkedList<String> repeat_all;
static LinkedHashMap<String,String> repeat_to_clan;
//repeats from pfam and interpro

static String[] repeat_pfam =  {"PF00021","PF00023","PF00039","PF00045","PF00057","PF00058","PF00066","PF00084","PF00086","PF00090","PF00132","PF00153","PF00191","PF00249","PF00353","PF00382","PF00399","PF00400","PF00402","PF00404","PF00414","PF00415","PF00418","PF00432","PF00435","PF00514","PF00515","PF00520","PF00526","PF00560","PF00567","PF00608","PF00624","PF00626","PF00630","PF00634","PF00637","PF00653","PF00672","PF00681","PF00724","PF00748","PF00754","PF00791","PF00805","PF00806","PF00807","PF00818","PF00823","PF00823","PF00839","PF00878","PF00880","PF00899","PF00904","PF00909","PF00934","PF00990","PF01011","PF01051","PF01239","PF01304","PF01344","PF01345","PF01378","PF01381","PF01391","PF01394","PF01413","PF01419","PF01436","PF01437","PF01462","PF01463","PF01469","PF01473","PF01473","PF01505","PF01508","PF01530","PF01535","PF01549","PF01628","PF01684","PF01744","PF01816","PF01821","PF01839","PF01839","PF01851","PF01930","PF02012","PF02071","PF02095","PF02162","PF02184","PF02185","PF02189","PF02218","PF02246","PF02281","PF02359","PF02363","PF02369","PF02370","PF02374","PF02412","PF02415","PF02420","PF02493","PF02494","PF02524","PF02526","PF02551","PF02671","PF02720","PF02755","PF02818","PF02820","PF02825","PF02861","PF02910","PF02933","PF02946","PF02985","PF02986","PF03057","PF03128","PF03130","PF03160","PF03177","PF03181","PF03335","PF03373","PF03377","PF03406","PF03444","PF03482","PF03561","PF03572","PF03578","PF03625","PF03640","PF03707","PF03710","PF03729","PF03736","PF03752","PF03778","PF03779","PF03793","PF03795","PF03860","PF03943","PF03961","PF03984","PF03988","PF03989","PF03990","PF03991","PF03993","PF03994","PF04022","PF04122","PF04193","PF04270","PF04385","PF04508","PF04553","PF04613","PF04624","PF04648","PF04649","PF04664","PF04671","PF04680","PF04778","PF04799","PF04806","PF04826","PF04886","PF05001","PF05017","PF05022","PF05036","PF05171","PF05202","PF05267","PF05386","PF05444","PF05465","PF05484","PF05488","PF05506","PF05552","PF05593","PF05593","PF05594","PF05647","PF05650","PF05658","PF05671","PF05725","PF05731","PF05735","PF05738","PF05792","PF05906","PF05923","PF05924","PF05972","PF06049","PF06131","PF06303","PF06392","PF06394","PF06435","PF06458","PF06462","PF06513","PF06598","PF06671","PF06696","PF06715","PF06739","PF06740","PF06757","PF06848","PF07004","PF07012","PF07016","PF07046","PF07054","PF07122","PF07142","PF07145","PF07177","PF07197","PF07199","PF07202","PF07244","PF07276","PF07292","PF07337","PF07391","PF07397","PF07411","PF07460","PF07469","PF07494","PF07538","PF07552","PF07563","PF07571","PF07634","PF07639","PF07646","PF07661","PF07671","PF07676","PF07709","PF07719","PF07720","PF07721","PF07723","PF07725","PF07769","PF07802","PF07806","PF07839","PF07918","PF07981","PF08043","PF08061","PF08062","PF08065","PF08140","PF08144","PF08149","PF08154","PF08161","PF08166","PF08191","PF08230","PF08237","PF08238","PF08263","PF08309","PF08310","PF08321","PF08324","PF08344","PF08377","PF08381","PF08441","PF08481","PF08517","PF08548","PF08558","PF08920","PF09042","PF09070","PF09111","PF09304","PF09372","PF09373","PF09408","PF09469","PF09479","PF09528","PF09681","PF09689","PF09698","PF09717","PF09759","PF09765","PF09976","PF10077","PF10131","PF10281","PF10300","PF10408","PF10421","PF10473","PF10511","PF10516","PF10529","PF10539","PF10541","PF10545","PF10564","PF10578","PF10685","PF10988","PF11396","PF11616","PF11617","PF11620","PF11701","PF11703","PF11732","PF11763","PF11768","PF11834","PF11838","PF11846","PF11901","PF11914","PF11921","PF11966","PF12009","PF12042","PF12135","PF12265","PF12331","PF12346","PF12347","PF12356","PF12372","PF12397","PF12460","PF12468","PF12484","PF12534","PF12688","PF12733","PF12763","PF12765","PF12778","PF12779","PF12789","PF12796","PF12799","PF12815","PF12844","PF12854","PF12868","PF12951","PF13041","PF13088","PF13101","PF13174","PF13176","PF13181","PF13281","PF13283","PF13287","PF13306","PF13313","PF13330","PF13332","PF13342","PF13349","PF13360","PF13368","PF13371","PF13374","PF13414","PF13422","PF13424","PF13428","PF13429","PF13431","PF13432","PF13443","PF13446","PF13449","PF13512","PF13513","PF13516","PF13517","PF13525","PF13540","PF13570","PF13573","PF13576","PF13599","PF13606","PF13634","PF13637","PF13646","PF13753","PF13808","PF13812","PF13855","PF13857","PF13859","PF13928","PF13948","PF14046","PF14077","PF14186","PF14312","PF14349","PF14420","PF14432","PF14559","PF14561","PF14580","PF14585","PF14602","PF14625","PF14652","PF14654","PF14660","PF14692","PF14726","PF14852","PF14853","PF14873","PF14882","PF14903","PF14912","PF14914","PF14939","PF15176","PF15236","PF15287","PF15390","PF15620","PF15651","PF15779","PF15783","PF15788","PF15789","PF15808","PF15892","PF15899","PF15904","PF15907","PF15911","PF15913","PF15935","PF15967","PF15984","PF16000","PF16058","PF16103","PF16168","PF16186","PF16244","PF16300","PF16364","PF16416","PF16418","PF16419","PF16469","PF16529","PF16546","PF16547","PF16568","PF16597","PF16601","PF16608","PF16641","PF16669","PF16673","PF16689","PF16705","PF16755","PF16772","PF16865","PF16910","PF16918","PF16920","PF17004","PF17017","PF17034","PF17107","PF17108","PF17164","PF17177","PF17210","PF17262","PF17432","PF17660","PF17726","PF17780","PF17794","PF17795","PF17796","PF17874","PF17888","PF17889","PF17953","PF17955","PF17961","PF17981","PF18025","PF18028","PF18061","PF18073","PF18190","PF18200","PF18210","PF18253","PF18275","PF18278","PF18346","PF18366","PF18373","PF18378","PF18381","PF18382","PF18391","PF18411","PF18418","PF18420","PF18444","PF18484","PF18487","PF18511","PF18529","PF18581","PF18584","PF18595","PF18600","PF18601","PF18617","PF18651","PF18656","PF18715","PF18727","PF18764","PF18768","PF18770","PF18773","PF18776","PF18777","PF18779","PF18780","PF18781","PF18783","PF18784","PF18786","PF18787","PF18792","PF18793","PF18797","PF18805","PF18806","PF18807","PF18808","PF18811","PF18815","PF18816","PF18817","PF18829","PF18831","PF18833","PF18835","PF18836","PF18837","PF18841","PF18861","PF18868","PF18872","PF18874","PF18877","PF18884","PF18885","PF18886","PF18888","PF18889","PF18916","PF18947","PF18981","PF18998","PF19039","PF19056","PF19076","PF19077","PF19078","PF19079","PF19081","PF19085","PF19087","PF19114","PF19116","PF19127","PF19193","PF19221","PF19264","PF19403","PF19404","PF19405","PF19406","PF19407","PF19408","PF19427","PF19440","PF19729","PF19755","PF19914","PF20023","PF20033","PF20041","PF20080","PF20141","PF20160","PF20175","PF20206","PF20210","PF20269","PF20270","PF20271","PF20302","PF20308","PF20309","PF20430","PF20431","PF20478","PF20493","PF20500","PF20502","PF20579","PF20585","PF20592","PF20596","PF20597"};		
//get repeats pfam
void map_repeat_pfam() throws IOException{

	System.out.println("map_repeat_pfam():" );

	repeat_all = new LinkedList();
 	repeat_to_clan = new LinkedHashMap();

  	Pattern space_pattern = Pattern.compile("\\s+");
	Pattern tab_pattern = Pattern.compile("	");
	Pattern comma_pattern = Pattern.compile(",");
	Pattern colon_pattern = Pattern.compile(":");
	
	String input="data/Pfam-A.clans.tsv.repeat";
	
	List<String> lines  = FileUtils.readLines(new File(input));

	for(int q= 0; q < lines.size(); q++){
	
		String one_line = lines.get(q).trim().toUpperCase();
		
		if(!one_line.equals("")){

			String[] tab_split = space_pattern.split(one_line);
			String pfam = tab_split[0].trim();
			String clan = tab_split[1].trim();
			repeat_all.add(pfam);
			repeat_to_clan.put(pfam,clan);
			
		}
	
	}//q

	input="data/repeats.from.interpro.sort.uniq";
	
	lines  = FileUtils.readLines(new File(input));

	for(int q= 0; q < lines.size(); q++){
	
		String pfam = lines.get(q).trim();
		
		if(!pfam.equals("")){

			String clan = pfam_clan_map_only.get(pfam);

			if(!repeat_all.contains(pfam)){
				repeat_all.add(pfam);
			}
			if (clan != null){
				repeat_to_clan.put(pfam,clan);
			}
			
		}
	
	}//q


	System.out.println("repeat_all:" + repeat_all.size());
	System.out.println("repeat_to_clan:" + repeat_to_clan.size());

}

static LinkedList<String> binding_all;
static LinkedHashMap<String,String> binding_to_clan;
static String[] binding_clan = {"CL0001","CL0004","CL0006","CL0007","CL0010","CL0012","CL0013","CL0020","CL0021","CL0023","CL0026","CL0029","CL0032","CL0036","CL0039","CL0043","CL0045","CL0049","CL0051","CL0054","CL0056","CL0057","CL0058","CL0059","CL0063","CL0066","CL0070","CL0072","CL0073","CL0076","CL0077","CL0080","CL0081","CL0083","CL0085","CL0089","CL0091","CL0092","CL0094","CL0101","CL0105","CL0106","CL0109","CL0110","CL0116","CL0123","CL0126","CL0128","CL0140","CL0144","CL0145","CL0151","CL0155","CL0159","CL0161","CL0167","CL0169","CL0172","CL0173","CL0175","CL0177","CL0178","CL0179","CL0181","CL0183","CL0186","CL0188","CL0193","CL0195","CL0196","CL0202","CL0203","CL0204","CL0210","CL0214","CL0220","CL0221","CL0223","CL0229","CL0236","CL0244","CL0246","CL0254","CL0258","CL0263","CL0265","CL0266","CL0268","CL0273","CL0274","CL0277","CL0279","CL0282","CL0289","CL0291","CL0298","CL0314","CL0317","CL0318","CL0319","CL0326","CL0329","CL0332","CL0333","CL0336","CL0342","CL0344","CL0350","CL0360","CL0361","CL0368","CL0369","CL0378","CL0382","CL0390","CL0391","CL0399","CL0404","CL0405","CL0407","CL0441","CL0457","CL0458","CL0462","CL0465","CL0483","CL0486","CL0494","CL0504","CL0506","CL0507","CL0522","CL0531","CL0535","CL0537","CL0547","CL0548","CL0552","CL0559","CL0572","CL0575","CL0576","CL0585","CL0592","CL0603","CL0607","CL0608","CL0609","CL0613","CL0632","CL0634","CL0635","CL0648","CL0651","CL0660","CL0667","CL0684","CL0689","CL0694","CL0705","CL0717","CL0720","NA"};
void map_binding_pfam() throws IOException{

	System.out.println("map_binding_pfam():" );

	binding_all = new LinkedList();
 	binding_to_clan = new LinkedHashMap();

  	Pattern space_pattern = Pattern.compile("\\s+");
	Pattern tab_pattern = Pattern.compile("	");
	Pattern comma_pattern = Pattern.compile(",");
	Pattern colon_pattern = Pattern.compile(":");
	
	String input="data/Pfam-A.clans.tsv.binding";
	
	List<String> lines  = FileUtils.readLines(new File(input));

	for(int q= 0; q < lines.size(); q++){
	
		String one_line = lines.get(q).trim().toUpperCase();
		
		if(!one_line.equals("")){

			String[] tab_split = space_pattern.split(one_line);
			String pfam = tab_split[0].trim();
			String clan = tab_split[1].trim();
			binding_all.add(pfam);
			binding_to_clan.put(pfam,clan);
			
		}
	
	}//q
	System.out.println("binding_all:" + binding_all.size());
	System.out.println("binding_to_clan:" + binding_to_clan.size());

}  

static String[] interpro_binding ={
"PF00004","PF00005","PF00006","PF00009","PF00012","PF00013","PF00016","PF00018","PF00020","PF00023","PF00025","PF00028","PF00034","PF00036","PF00041","PF00042","PF00044","PF00046","PF00050","PF00057","PF00063","PF00067","PF00069","PF00071","PF00075","PF00076","PF00080","PF00081","PF00091","PF00093","PF00097","PF00098","PF00105","PF00110","PF00111","PF00115","PF00116","PF00118","PF00125","PF00127","PF00131","PF00133","PF00136","PF00139","PF00140","PF00141","PF00142","PF00143","PF00152","PF00154","PF00155","PF00158","PF00163","PF00165","PF00166","PF00172","PF00176","PF00178","PF00183","PF00185","PF00187","PF00191","PF00193","PF00199","PF00202","PF00204","PF00205","PF00210","PF00216","PF00224","PF00225","PF00229","PF00235","PF00239","PF00240","PF00241","PF00242","PF00243","PF00246","PF00250","PF00258","PF00260","PF00262","PF00265","PF00269","PF00270","PF00282","PF00284","PF00288","PF00292","PF00301","PF00305","PF00307","PF00313","PF00317","PF00319","PF00320","PF00325","PF00333","PF00337","PF00346","PF00347","PF00349","PF00352","PF00353","PF00355","PF00356","PF00374","PF00376","PF00382","PF00389","PF00397","PF00400","PF00403","PF00413","PF00416","PF00418","PF00421","PF00423","PF00433","PF00435","PF00436","PF00439","PF00440","PF00445","PF00447","PF00448","PF00453","PF00458","PF00465","PF00469","PF00476","PF00479","PF00484","PF00485","PF00486","PF00488","PF00489","PF00490","PF00491","PF00493","PF00498","PF00503","PF00509","PF00511","PF00514","PF00515","PF00519","PF00521","PF00527","PF00531","PF00536","PF00538","PF00545","PF00547","PF00552","PF00553","PF00554","PF00555","PF00560","PF00562","PF00564","PF00569","PF00570","PF00575","PF00579","PF00580","PF00587","PF00588","PF00589","PF00594","PF00595","PF00598","PF00600","PF00602","PF00603","PF00604","PF00605","PF00612","PF00622","PF00623","PF00633","PF00642","PF00643","PF00645","PF00646","PF00649","PF00651","PF00658","PF00659","PF00664","PF00680","PF00684","PF00686","PF00693","PF00705","PF00709","PF00712","PF00714","PF00715","PF00719","PF00724","PF00727","PF00732","PF00734","PF00735","PF00737","PF00743","PF00745","PF00747","PF00749","PF00751","PF00764","PF00772","PF00773","PF00775","PF00787","PF00789","PF00790","PF00806","PF00810","PF00811","PF00815","PF00816","PF00825","PF00841","PF00845","PF00848","PF00849","PF00853","PF00856","PF00870","PF00872","PF00878","PF00883","PF00887","PF00888","PF00905","PF00910","PF00917","PF00919","PF00931","PF00937","PF00942","PF00946","PF00949","PF00958","PF00960","PF00963","PF00972","PF00978","PF00981","PF00984","PF00986","PF00998","PF01005","PF01021","PF01025","PF01028","PF01029","PF01044","PF01049","PF01053","PF01058","PF01068","PF01076","PF01077","PF01078","PF01082","PF01096","PF01101","PF01106","PF01108","PF01109","PF01110","PF01116","PF01118","PF01119","PF01121","PF01122","PF01131","PF01142","PF01149","PF01152","PF01155","PF01176","PF01179","PF01186","PF01191","PF01192","PF01194","PF01210","PF01213","PF01216","PF01223","PF01231","PF01237","PF01248","PF01250","PF01254","PF01258","PF01268","PF01269","PF01272","PF01273","PF01287","PF01289","PF01290","PF01293","PF01297","PF01300","PF01310","PF01314","PF01320","PF01322","PF01325","PF01326","PF01330","PF01331","PF01333","PF01335","PF01336","PF01342","PF01344","PF01363","PF01367","PF01380","PF01382","PF01386","PF01388","PF01392","PF01395","PF01396","PF01398","PF01403","PF01404","PF01408","PF01409","PF01411","PF01415","PF01416","PF01420","PF01422","PF01424","PF01426","PF01428","PF01429","PF01430","PF01433","PF01434","PF01436","PF01439","PF01442","PF01443","PF01446","PF01472","PF01477","PF01479","PF01485","PF01491","PF01494","PF01498","PF01517","PF01518","PF01525","PF01527","PF01530","PF01532","PF01548","PF01555","PF01565","PF01568","PF01578","PF01580","PF01585","PF01588","PF01590","PF01591","PF01592","PF01607","PF01608","PF01609","PF01612","PF01613","PF01623","PF01624","PF01628","PF01637","PF01642","PF01648","PF01649","PF01652","PF01660","PF01665","PF01668","PF01676","PF01695","PF01717","PF01719","PF01730","PF01736","PF01742","PF01743","PF01752","PF01754","PF01774","PF01787","PF01789","PF01797","PF01799","PF01805","PF01806","PF01807","PF01818","PF01834","PF01844","PF01852","PF01867","PF01868","PF01874","PF01880","PF01912","PF01918","PF01920","PF01921","PF01922","PF01924","PF01926","PF01964","PF01984","PF01985","PF01997","PF02005","PF02008","PF02020","PF02022","PF02025","PF02031","PF02041","PF02053","PF02059","PF02063","PF02066","PF02067","PF02068","PF02069","PF02079","PF02085","PF02087","PF02091","PF02092","PF02098","PF02101","PF02110","PF02115","PF02123","PF02126","PF02127","PF02128","PF02132","PF02137","PF02140","PF02146","PF02148","PF02151","PF02153","PF02155","PF02161","PF02166","PF02167","PF02170","PF02171","PF02173","PF02176","PF02177","PF02178","PF02179","PF02183","PF02187","PF02198","PF02205","PF02207","PF02209","PF02212","PF02213","PF02216","PF02217","PF02224","PF02229","PF02232","PF02236","PF02245","PF02257","PF02259","PF02260","PF02263","PF02265","PF02272","PF02276","PF02282","PF02283","PF02286","PF02290","PF02294","PF02295","PF02303","PF02310","PF02316","PF02334","PF02362","PF02365","PF02371","PF02372","PF02376","PF02384","PF02394","PF02399","PF02401","PF02404","PF02412","PF02421","PF02429","PF02438","PF02445","PF02452","PF02459","PF02486","PF02491","PF02509","PF02511","PF02536","PF02556","PF02562","PF02572","PF02575","PF02583","PF02586","PF02599","PF02603","PF02606","PF02655","PF02664","PF02670","PF02685","PF02689","PF02701","PF02710","PF02727","PF02728","PF02730","PF02732","PF02735","PF02736","PF02737","PF02739","PF02742","PF02747","PF02761","PF02765","PF02768","PF02771","PF02775","PF02776","PF02777","PF02781","PF02786","PF02796","PF02805","PF02806","PF02816","PF02826","PF02829","PF02839","PF02841","PF02845","PF02854","PF02862","PF02863","PF02864","PF02881","PF02886","PF02888","PF02891","PF02892","PF02899","PF02900","PF02905","PF02912","PF02913","PF02914","PF02915","PF02919","PF02920","PF02926","PF02944","PF02949","PF02954","PF02955","PF02961","PF02963","PF02970","PF02971","PF02976","PF02978","PF02979","PF02980","PF02981","PF02985","PF03014","PF03039","PF03068","PF03081","PF03089","PF03097","PF03100","PF03106","PF03110","PF03114","PF03118","PF03123","PF03126","PF03127","PF03131","PF03135","PF03144","PF03146","PF03159","PF03170","PF03175","PF03178","PF03184","PF03193","PF03194","PF03199","PF03205","PF03234","PF03246","PF03250","PF03271","PF03280","PF03293","PF03301","PF03310","PF03315","PF03327","PF03367","PF03370","PF03373","PF03374","PF03378","PF03396","PF03400","PF03404","PF03410","PF03412","PF03422","PF03423","PF03427","PF03444","PF03446","PF03447","PF03449","PF03473","PF03483","PF03484","PF03485","PF03513","PF03526","PF03533","PF03549","PF03574","PF03589","PF03604","PF03615","PF03618","PF03627","PF03630","PF03668","PF03702","PF03714","PF03717","PF03720","PF03721","PF03726","PF03727","PF03728","PF03730","PF03744","PF03754","PF03764","PF03789","PF03790","PF03791","PF03796","PF03810","PF03832","PF03836","PF03837","PF03854","PF03857","PF03859","PF03861","PF03869","PF03871","PF03875","PF03884","PF03910","PF03917","PF03920","PF03925","PF03936","PF03938","PF03949","PF03950","PF03955","PF03965","PF03969","PF03979","PF03983","PF03989","PF03996","PF04014","PF04023","PF04029","PF04042","PF04055","PF04057","PF04060","PF04082","PF04086","PF04090","PF04116","PF04130","PF04135","PF04137","PF04146","PF04152","PF04166","PF04198","PF04205","PF04218","PF04225","PF04234","PF04261","PF04263","PF04265","PF04310","PF04313","PF04362","PF04364","PF04382","PF04397","PF04406","PF04427","PF04433","PF04434","PF04442","PF04444","PF04446","PF04471","PF04499","PF04514","PF04522","PF04546","PF04548","PF04555","PF04556","PF04557","PF04558","PF04560","PF04561","PF04563","PF04565","PF04566","PF04589","PF04661","PF04670","PF04675","PF04684","PF04689","PF04704","PF04711","PF04726","PF04739","PF04767","PF04769","PF04810","PF04825","PF04845","PF04848","PF04851","PF04868","PF04881","PF04891","PF04926","PF04931","PF04939","PF04940","PF04941","PF04963","PF04983","PF04986","PF04988","PF04990","PF04992","PF04997","PF04998","PF05000","PF05001","PF05023","PF05025","PF05026","PF05033","PF05036","PF05038","PF05044","PF05049","PF05051","PF05087","PF05100","PF05130","PF05132","PF05149","PF05153","PF05180","PF05188","PF05190","PF05192","PF05194","PF05195","PF05197","PF05201","PF05204","PF05224","PF05225","PF05261","PF05269","PF05273","PF05275","PF05280","PF05320","PF05342","PF05349","PF05413","PF05424","PF05428","PF05443","PF05445","PF05456","PF05460","PF05461","PF05470","PF05472","PF05491","PF05495","PF05509","PF05517","PF05622","PF05634","PF05639","PF05645","PF05694","PF05715","PF05719","PF05722","PF05731","PF05733","PF05735","PF05737","PF05746","PF05757","PF05773","PF05778","PF05788","PF05793","PF05822","PF05823","PF05829","PF05835","PF05847","PF05864","PF05866","PF05869","PF05902","PF05920","PF05924","PF05927","PF05937","PF05944","PF05956","PF05972","PF05993","PF05994","PF05995","PF05996","PF06003","PF06007","PF06008","PF06016","PF06018","PF06047","PF06052","PF06056","PF06061","PF06068","PF06090","PF06100","PF06134","PF06144","PF06189","PF06203","PF06220","PF06221","PF06236","PF06268","PF06297","PF06298","PF06309","PF06315","PF06367","PF06371","PF06384","PF06387","PF06397","PF06401","PF06414","PF06415","PF06420","PF06422","PF06431","PF06437","PF06440","PF06452","PF06456","PF06461","PF06463","PF06467","PF06470","PF06472","PF06478","PF06480","PF06506","PF06507","PF06524","PF06530","PF06546","PF06573","PF06613","PF06616","PF06621","PF06632","PF06657","PF06658","PF06689","PF06694","PF06701","PF06714","PF06733","PF06734","PF06778","PF06831","PF06839","PF06849","PF06858","PF06862","PF06870","PF06892","PF06929","PF06951","PF06953","PF06957","PF06973","PF07022","PF07057","PF07058","PF07088","PF07127","PF07159","PF07160","PF07163","PF07174","PF07213","PF07229","PF07238","PF07352","PF07361","PF07378","PF07382","PF07404","PF07432","PF07460","PF07464","PF07475","PF07492","PF07496","PF07497","PF07499","PF07503","PF07508","PF07517","PF07527","PF07533","PF07535","PF07541","PF07546","PF07573","PF07580","PF07645","PF07646","PF07647","PF07648","PF07650","PF07651","PF07652","PF07653","PF07669","PF07700","PF07702","PF07706","PF07711","PF07721","PF07724","PF07726","PF07728","PF07731","PF07732","PF07765","PF07766","PF07776","PF07821","PF07825","PF07830","PF07837","PF07839","PF07840","PF07846","PF07925","PF07927","PF07934","PF07941","PF07946","PF07967","PF07972","PF07973","PF07975","PF08029","PF08031","PF08043","PF08063","PF08072","PF08144","PF08147","PF08152","PF08188","PF08198","PF08210","PF08211","PF08245","PF08267","PF08272","PF08273","PF08281","PF08289","PF08297","PF08299","PF08300","PF08302","PF08303","PF08326","PF08332","PF08352","PF08361","PF08401","PF08402","PF08416","PF08430","PF08436","PF08447","PF08463","PF08465","PF08469","PF08471","PF08490","PF08491","PF08492","PF08493","PF08494","PF08509","PF08513","PF08515","PF08517","PF08519","PF08526","PF08527","PF08536","PF08548","PF08558","PF08563","PF08603","PF08613","PF08640","PF08661","PF08675","PF08676","PF08683","PF08685","PF08688","PF08702","PF08703","PF08710","PF08720","PF08755","PF08769","PF08771","PF08777","PF08782","PF08783","PF08797","PF08804","PF08815","PF08826","PF08831","PF08845","PF08880","PF08912","PF08915","PF08917","PF08918","PF08919","PF08926","PF08943","PF08998","PF09000","PF09003","PF09005","PF09019","PF09026","PF09029","PF09034","PF09040","PF09048","PF09055","PF09077","PF09095","PF09106","PF09107","PF09110","PF09111","PF09115","PF09127","PF09142","PF09150","PF09157","PF09162","PF09166","PF09179","PF09180","PF09181","PF09182","PF09190","PF09194","PF09197","PF09201","PF09202","PF09204","PF09208","PF09213","PF09223","PF09226","PF09229","PF09236","PF09239","PF09242","PF09246","PF09259","PF09260","PF09262","PF09264","PF09265","PF09266","PF09269","PF09270","PF09271","PF09280","PF09281","PF09284","PF09289","PF09297","PF09307","PF09326","PF09328","PF09330","PF09334","PF09339","PF09360","PF09401","PF09405","PF09416","PF09452","PF09456","PF09458","PF09459","PF09478","PF09519","PF09520","PF09521","PF09553","PF09567","PF09568","PF09570","PF09571","PF09572","PF09573","PF09728","PF09730","PF09732","PF09905","PF09907","PF10073","PF10150","PF10228","PF10288","PF10309","PF10341","PF10384","PF10391","PF10403","PF10404","PF10405","PF10430","PF10447","PF10458","PF10473","PF10523","PF10576","PF10579","PF10589","PF10591","PF10596","PF10597","PF10598","PF10637","PF10645","PF10660","PF10662","PF10729","PF10995","PF11109","PF11357","PF11403","PF11408","PF11421","PF11427","PF11435","PF11507","PF11520","PF11525","PF11538","PF11545","PF11547","PF11561","PF11563","PF11575","PF11605","PF11610","PF11633","PF11716","PF11734","PF11774","PF11789","PF11799","PF11806","PF11931","PF11955","PF12109","PF12144","PF12165","PF12189","PF12191","PF12199","PF12202","PF12235","PF12404","PF12470","PF12515","PF12539","PF12619","PF12632","PF12641","PF12658","PF12678","PF12682","PF12753","PF12763","PF12766","PF12774","PF12796","PF12814","PF12829","PF12833","PF12861","PF12884","PF12906","PF12924","PF12937","PF12940","PF13008","PF13013","PF13085","PF13174","PF13176","PF13180","PF13181","PF13184","PF13185","PF13202","PF13225","PF13304","PF13307","PF13361","PF13397","PF13404","PF13405","PF13411","PF13442","PF13456","PF13492","PF13495","PF13499","PF13516","PF13545","PF13580","PF13606","PF13637","PF13724","PF13742","PF13748","PF13833","PF13855","PF13857","PF13867","PF13869","PF13892","PF13914","PF13922","PF13925","PF13931","PF13947","PF13949","PF13954","PF13958","PF14073","PF14144","PF14372","PF14432","PF14532","PF14554","PF14560","PF14572","PF14604","PF14619","PF14641","PF14659","PF14722","PF14833","PF14860","PF14895","PF14925","PF14928","PF15036","PF15068","PF15077","PF15085","PF15127","PF15129","PF15180","PF15247","PF15281","PF15293","PF15313","PF15320","PF15337","PF15340","PF15360","PF15367","PF15427","PF15489","PF15490","PF15499","PF15501","PF15510","PF15549","PF15673","PF15741","PF15745","PF15750","PF15773","PF15806","PF15836","PF15854","PF15886","PF15898","PF15965","PF15966","PF15985","PF16011","PF16045","PF16099","PF16179","PF16251","PF16276","PF16326","PF16367","PF16411","PF16422","PF16525","PF16557","PF16656","PF16686","PF16711","PF16714","PF16719","PF16746","PF16752","PF16760","PF16785","PF16787","PF16790","PF16794","PF16796","PF16969","PF16990","PF17066","PF17077","PF17095","PF17144","PF17209","PF17257","PF17308","PF17366","PF17538","PF17548","PF17659","PF17764","PF17785","PF17879","PF18024","PF18329","PF18361","PF18465","PF18507","PF18872","PF18972","PF19046","PF19060","PF19097","PF19225","PF19335","PF19368","PF19429","PF19444","PF19567","PF19977","PF20144","PF20432","PF20450","PF20491","PF20511","PR01976","PR01977","PR01978","PR01979","PR01980","PR01981","PR01982"
};
static String[] interpro_activity =
{
"PF00001","PF00002","PF00003","PF00004","PF00004","PF00009","PF00010","PF00014","PF00016","PF00017","PF00019","PF00025","PF00031","PF00032","PF00033","PF00034","PF00048","PF00049","PF00056","PF00060","PF00063","PF00064","PF00067","PF00068","PF00069","PF00069","PF00071","PF00073","PF00075","PF00081","PF00082","PF00083","PF00089","PF00095","PF00102","PF00103","PF00105","PF00106","PF00108","PF00112","PF00112","PF00115","PF00116","PF00117","PF00119","PF00120","PF00120","PF00121","PF00123","PF00124","PF00126","PF00127","PF00133","PF00137","PF00140","PF00141","PF00142","PF00145","PF00148","PF00149","PF00150","PF00151","PF00152","PF00157","PF00159","PF00160","PF00161","PF00162","PF00165","PF00167","PF00170","PF00171","PF00172","PF00175","PF00176","PF00176","PF00178","PF00182","PF00183","PF00184","PF00185","PF00186","PF00197","PF00198","PF00199","PF00201","PF00202","PF00204","PF00207","PF00208","PF00212","PF00213","PF00214","PF00215","PF00217","PF00218","PF00220","PF00224","PF00225","PF00228","PF00230","PF00231","PF00232","PF00233","PF00236","PF00239","PF00242","PF00245","PF00246","PF00250","PF00254","PF00255","PF00264","PF00264","PF00265","PF00267","PF00271","PF00274","PF00275","PF00278","PF00280","PF00282","PF00285","PF00286","PF00290","PF00295","PF00296","PF00299","PF00302","PF00305","PF00309","PF00311","PF00317","PF00319","PF00326","PF00329","PF00331","PF00332","PF00336","PF00340","PF00341","PF00342","PF00343","PF00346","PF00349","PF00351","PF00365","PF00367","PF00368","PF00370","PF00375","PF00378","PF00384","PF00387","PF00389","PF00390","PF00391","PF00392","PF00393","PF00404","PF00408","PF00413","PF00424","PF00430","PF00432","PF00433","PF00438","PF00438","PF00441","PF00443","PF00445","PF00446","PF00447","PF00450","PF00451","PF00458","PF00463","PF00465","PF00472","PF00473","PF00474","PF00475","PF00476","PF00478","PF00479","PF00483","PF00484","PF00485","PF00490","PF00499","PF00500","PF00503","PF00506","PF00507","PF00510","PF00511","PF00512","PF00513","PF00517","PF00519","PF00520","PF00521","PF00524","PF00527","PF00530","PF00534","PF00537","PF00539","PF00540","PF00543","PF00545","PF00548","PF00549","PF00553","PF00554","PF00556","PF00558","PF00562","PF00577","PF00578","PF00579","PF00583","PF00587","PF00588","PF00588","PF00590","PF00591","PF00598","PF00599","PF00602","PF00609","PF00614","PF00617","PF00621","PF00623","PF00632","PF00636","PF00639","PF00644","PF00647","PF00648","PF00649","PF00654","PF00656","PF00657","PF00661","PF00664","PF00667","PF00668","PF00669","PF00676","PF00680","PF00682","PF00685","PF00685","PF00693","PF00697","PF00701","PF00703","PF00709","PF00712","PF00713","PF00715","PF00716","PF00718","PF00719","PF00720","PF00721","PF00722","PF00724","PF00725","PF00727","PF00728","PF00729","PF00732","PF00733","PF00736","PF00738","PF00740","PF00741","PF00743","PF00745","PF00749","PF00752","PF00758","PF00759","PF00761","PF00762","PF00763","PF00764","PF00765","PF00768","PF00770","PF00772","PF00773","PF00775","PF00777","PF00781","PF00782","PF00797","PF00799","PF00800","PF00815","PF00821","PF00825","PF00834","PF00837","PF00840","PF00844","PF00847","PF00849","PF00851","PF00852","PF00853","PF00854","PF00858","PF00859","PF00860","PF00862","PF00863","PF00867","PF00869","PF00871","PF00872","PF00873","PF00878","PF00883","PF00884","PF00889","PF00891","PF00893","PF00894","PF00895","PF00897","PF00898","PF00901","PF00906","PF00907","PF00908","PF00909","PF00910","PF00918","PF00919","PF00920","PF00926","PF00927","PF00933","PF00933","PF00939","PF00941","PF00943","PF00944","PF00946","PF00947","PF00949","PF00953","PF00954","PF00958","PF00959","PF00961","PF00962","PF00965","PF00971","PF00972","PF00973","PF00978","PF00979","PF00980","PF00982","PF00983","PF00984","PF00986","PF00996","PF00998","PF00999","PF01000","PF01001","PF01002","PF01003","PF01017","PF01022","PF01024","PF01025","PF01026","PF01028","PF01032","PF01035","PF01040","PF01047","PF01048","PF01050","PF01051","PF01055","PF01056","PF01061","PF01062","PF01063","PF01064","PF01066","PF01068","PF01070","PF01073","PF01074","PF01075","PF01077","PF01080","PF01081","PF01082","PF01083","PF01086","PF01087","PF01088","PF01091","PF01095","PF01109","PF01111","PF01112","PF01114","PF01116","PF01118","PF01120","PF01121","PF01123","PF01126","PF01127","PF01128","PF01129","PF01131","PF01132","PF01139","PF01142","PF01144","PF01149","PF01150","PF01151","PF01156","PF01174","PF01176","PF01177","PF01179","PF01180","PF01183","PF01186","PF01189","PF01191","PF01192","PF01193","PF01194","PF01195","PF01204","PF01208","PF01209","PF01210","PF01212","PF01214","PF01218","PF01219","PF01220","PF01222","PF01223","PF01225","PF01226","PF01228","PF01229","PF01230","PF01232","PF01233","PF01234","PF01235","PF01239","PF01244","PF01252","PF01253","PF01255","PF01256","PF01263","PF01264","PF01265","PF01266","PF01266","PF01268","PF01269","PF01270","PF01274","PF01276","PF01278","PF01279","PF01285","PF01287","PF01288","PF01291","PF01292","PF01293","PF01295","PF01296","PF01306","PF01308","PF01314","PF01316","PF01318","PF01321","PF01322","PF01323","PF01326","PF01327","PF01328","PF01329","PF01330","PF01331","PF01333","PF01339","PF01340","PF01341","PF01343","PF01347","PF01351","PF01355","PF01356","PF01361","PF01364","PF01365","PF01367","PF01369","PF01371","PF01372","PF01373","PF01374","PF01375","PF01379","PF01384","PF01396","PF01397","PF01398","PF01400","PF01401","PF01409","PF01411","PF01412","PF01415","PF01416","PF01418","PF01421","PF01427","PF01431","PF01432","PF01433","PF01434","PF01435","PF01440","PF01443","PF01447","PF01450","PF01453","PF01457","PF01467","PF01473","PF01474","PF01475","PF01478","PF01483","PF01486","PF01487","PF01493","PF01496","PF01501","PF01502","PF01504","PF01506","PF01507","PF01510","PF01513","PF01515","PF01516","PF01518","PF01520","PF01522","PF01525","PF01526","PF01527","PF01529","PF01531","PF01532","PF01536","PF01538","PF01542","PF01543","PF01544","PF01545","PF01546","PF01548","PF01553","PF01554","PF01555","PF01557","PF01558","PF01559","PF01563","PF01566","PF01568","PF01577","PF01589","PF01591","PF01593","PF01596","PF01603","PF01609","PF01612","PF01625","PF01630","PF01634","PF01640","PF01641","PF01642","PF01643","PF01644","PF01645","PF01648","PF01650","PF01652","PF01653","PF01654","PF01660","PF01660","PF01670","PF01674","PF01676","PF01678","PF01687","PF01694","PF01700","PF01702","PF01704","PF01716","PF01717","PF01719","PF01725","PF01726","PF01728","PF01729","PF01731","PF01733","PF01735","PF01738","PF01742","PF01743","PF01747","PF01749","PF01750","PF01752","PF01756","PF01757","PF01762","PF01766","PF01767","PF01769","PF01770","PF01786","PF01790","PF01791","PF01793","PF01795","PF01797","PF01799","PF01802","PF01804","PF01806","PF01807","PF01808","PF01813","PF01819","PF01828","PF01829","PF01830","PF01831","PF01832","PF01835","PF01840","PF01844","PF01845","PF01853","PF01855","PF01862","PF01866","PF01867","PF01872","PF01873","PF01874","PF01880","PF01881","PF01884","PF01885","PF01888","PF01896","PF01899","PF01903","PF01909","PF01913","PF01915","PF01917","PF01921","PF01933","PF01934","PF01936","PF01939","PF01958","PF01959","PF01960","PF01968","PF01974","PF01975","PF01977","PF01979","PF01981","PF01982","PF01983","PF01988","PF01990","PF01991","PF01992","PF01993","PF01994","PF02005","PF02007","PF02011","PF02015","PF02018","PF02024","PF02025","PF02028","PF02031","PF02038","PF02040","PF02045","PF02048","PF02049","PF02056","PF02057","PF02058","PF02059","PF02060","PF02073","PF02074","PF02075","PF02076","PF02080","PF02083","PF02085","PF02086","PF02091","PF02092","PF02099","PF02100","PF02101","PF02102","PF02107","PF02110","PF02112","PF02113","PF02115","PF02116","PF02117","PF02118","PF02119","PF02121","PF02122","PF02123","PF02127","PF02128","PF02129","PF02130","PF02133","PF02136","PF02137","PF02145","PF02152","PF02153","PF02154","PF02155","PF02156","PF02159","PF02160","PF02161","PF02166","PF02167","PF02172","PF02175","PF02188","PF02189","PF02200","PF02211","PF02212","PF02219","PF02224","PF02226","PF02228","PF02230","PF02234","PF02240","PF02241","PF02241","PF02245","PF02247","PF02249","PF02253","PF02261","PF02263","PF02264","PF02265","PF02267","PF02273","PF02276","PF02277","PF02278","PF02283","PF02286","PF02289","PF02294","PF02295","PF02298","PF02302","PF02305","PF02312","PF02315","PF02317","PF02321","PF02323","PF02324","PF02329","PF02331","PF02333","PF02335","PF02336","PF02337","PF02344","PF02347","PF02354","PF02358","PF02364","PF02366","PF02371","PF02378","PF02382","PF02383","PF02384","PF02386","PF02388","PF02390","PF02395","PF02401","PF02406","PF02407","PF02411","PF02417","PF02428","PF02434","PF02435","PF02441","PF02445","PF02446","PF02447","PF02449","PF02450","PF02462","PF02472","PF02474","PF02478","PF02485","PF02486","PF02502","PF02504","PF02511","PF02514","PF02515","PF02516","PF02517","PF02522","PF02527","PF02530","PF02535","PF02538","PF02542","PF02543","PF02544","PF02545","PF02547","PF02548","PF02550","PF02553","PF02557","PF02563","PF02567","PF02568","PF02569","PF02570","PF02571","PF02572","PF02577","PF02580","PF02590","PF02595","PF02600","PF02601","PF02602","PF02603","PF02606","PF02609","PF02610","PF02611","PF02614","PF02615","PF02627","PF02628","PF02632","PF02634","PF02637","PF02649","PF02652","PF02653","PF02654","PF02660","PF02664","PF02666","PF02668","PF02669","PF02673","PF02675","PF02684","PF02685","PF02689","PF02690","PF02702","PF02705","PF02710","PF02727","PF02728","PF02729","PF02730","PF02732","PF02733","PF02734","PF02736","PF02738","PF02740","PF02741","PF02742","PF02744","PF02745","PF02749","PF02767","PF02768","PF02770","PF02771","PF02772","PF02772","PF02773","PF02773","PF02774","PF02775","PF02777","PF02778","PF02781","PF02782","PF02783","PF02783","PF02784","PF02788","PF02789","PF02793","PF02794","PF02796","PF02799","PF02800","PF02803","PF02805","PF02806","PF02807","PF02811","PF02812","PF02816","PF02817","PF02819","PF02822","PF02827","PF02833","PF02836","PF02837","PF02839","PF02841","PF02843","PF02844","PF02864","PF02865","PF02866","PF02868","PF02870","PF02872","PF02873","PF02875","PF02877","PF02878","PF02880","PF02882","PF02884","PF02888","PF02895","PF02896","PF02897","PF02898","PF02900","PF02901","PF02902","PF02903","PF02907","PF02910","PF02912","PF02913","PF02914","PF02915","PF02917","PF02919","PF02920","PF02921","PF02922","PF02927","PF02929","PF02931","PF02934","PF02940","PF02943","PF02947","PF02949","PF02950","PF02951","PF02952","PF02955","PF02962","PF02963","PF02964","PF02965","PF02971","PF02973","PF02975","PF02976","PF02979","PF02982","PF02983","PF02988","PF03002","PF03007","PF03009","PF03012","PF03014","PF03028","PF03030","PF03033","PF03034","PF03039","PF03047","PF03051","PF03055","PF03059","PF03060","PF03062","PF03063","PF03065","PF03068","PF03069","PF03071","PF03074","PF03079","PF03088","PF03095","PF03106","PF03118","PF03119","PF03120","PF03122","PF03139","PF03141","PF03150","PF03155","PF03157","PF03159","PF03161","PF03169","PF03170","PF03175","PF03179","PF03185","PF03186","PF03189","PF03193","PF03199","PF03203","PF03211","PF03219","PF03223","PF03224","PF03227","PF03239","PF03243","PF03253","PF03254","PF03255","PF03261","PF03265","PF03266","PF03275","PF03279","PF03283","PF03293","PF03294","PF03296","PF03298","PF03301","PF03306","PF03309","PF03315","PF03320","PF03325","PF03328","PF03331","PF03332","PF03334","PF03335","PF03341","PF03352","PF03358","PF03360","PF03372","PF03379","PF03390","PF03391","PF03395","PF03396","PF03400","PF03402","PF03404","PF03405","PF03410","PF03411","PF03412","PF03414","PF03416","PF03418","PF03419","PF03424","PF03425","PF03431","PF03435","PF03445","PF03447","PF03460","PF03473","PF03483","PF03485","PF03488","PF03491","PF03492","PF03497","PF03510","PF03512","PF03516","PF03521","PF03522","PF03523","PF03528","PF03529","PF03530","PF03539","PF03542","PF03543","PF03552","PF03559","PF03561","PF03562","PF03567","PF03572","PF03574","PF03575","PF03577","PF03583","PF03586","PF03587","PF03588","PF03590","PF03594","PF03598","PF03603","PF03604","PF03605","PF03612","PF03614","PF03616","PF03618","PF03623","PF03630","PF03632","PF03636","PF03644","PF03648","PF03659","PF03662","PF03664","PF03702","PF03709","PF03710","PF03711","PF03720","PF03721","PF03727","PF03727","PF03730","PF03734","PF03740","PF03742","PF03744","PF03759","PF03770","PF03785","PF03786","PF03792","PF03796","PF03803","PF03806","PF03808","PF03812","PF03814","PF03820","PF03824","PF03825","PF03827","PF03829","PF03830","PF03840","PF03849","PF03851","PF03852","PF03855","PF03870","PF03871","PF03872","PF03894","PF03898","PF03900","PF03901","PF03907","PF03908","PF03917","PF03936","PF03944","PF03945","PF03950","PF03951","PF03956","PF03967","PF03969","PF03971","PF03974","PF03975","PF03976","PF03977","PF03982","PF03983","PF03987","PF03989","PF03996","PF04013","PF04019","PF04029","PF04030","PF04031","PF04043","PF04053","PF04055","PF04066","PF04069","PF04072","PF04073","PF04075","PF04086","PF04090","PF04101","PF04107","PF04115","PF04116","PF04131","PF04134","PF04137","PF04140","PF04142","PF04145","PF04148","PF04152","PF04185","PF04188","PF04196","PF04197","PF04199","PF04206","PF04207","PF04210","PF04211","PF04220","PF04223","PF04227","PF04231","PF04252","PF04258","PF04261","PF04262","PF04263","PF04267","PF04272","PF04273","PF04275","PF04277","PF04295","PF04313","PF04336","PF04344","PF04345","PF04346","PF04364","PF04371","PF04376","PF04377","PF04378","PF04406","PF04408","PF04414","PF04421","PF04424","PF04428","PF04431","PF04443","PF04444","PF04445","PF04446","PF04451","PF04464","PF04471","PF04493","PF04498","PF04501","PF04509","PF04512","PF04513","PF04515","PF04517","PF04522","PF04539","PF04542","PF04545","PF04546","PF04551","PF04552","PF04555","PF04556","PF04557","PF04558","PF04560","PF04561","PF04563","PF04564","PF04565","PF04566","PF04568","PF04577","PF04579","PF04587","PF04602","PF04608","PF04613","PF04616","PF04621","PF04627","PF04632","PF04643","PF04644","PF04647","PF04648","PF04655","PF04663","PF04664","PF04675","PF04679","PF04685","PF04692","PF04700","PF04705","PF04709","PF04710","PF04718","PF04722","PF04723","PF04724","PF04735","PF04736","PF04752","PF04766","PF04777","PF04799","PF04805","PF04816","PF04820","PF04828","PF04848","PF04851","PF04863","PF04864","PF04868","PF04873","PF04879","PF04898","PF04901","PF04902","PF04904","PF04909","PF04911","PF04916","PF04922","PF04928","PF04934","PF04940","PF04941","PF04952","PF04958","PF04960","PF04961","PF04962","PF04966","PF04971","PF04973","PF04979","PF04983","PF04986","PF04987","PF04989","PF04990","PF04992","PF04996","PF04997","PF04998","PF05000","PF05007","PF05011","PF05023","PF05025","PF05028","PF05033","PF05035","PF05051","PF05052","PF05060","PF05088","PF05090","PF05091","PF05096","PF05115","PF05136","PF05148","PF05153","PF05165","PF05175","PF05183","PF05191","PF05195","PF05196","PF05197","PF05198","PF05199","PF05201","PF05204","PF05206","PF05208","PF05219","PF05270","PF05273","PF05292","PF05296","PF05301","PF05320","PF05327","PF05336","PF05337","PF05342","PF05353","PF05355","PF05362","PF05366","PF05367","PF05369","PF05373","PF05374","PF05375","PF05379","PF05381","PF05384","PF05388","PF05395","PF05397","PF05401","PF05405","PF05407","PF05407","PF05408","PF05409","PF05410","PF05411","PF05413","PF05416","PF05418","PF05426","PF05430","PF05431","PF05438","PF05440","PF05445","PF05453","PF05464","PF05470","PF05476","PF05491","PF05493","PF05496","PF05497","PF05506","PF05511","PF05525","PF05543","PF05547","PF05577","PF05578","PF05579","PF05586","PF05587","PF05609","PF05631","PF05637","PF05652","PF05653","PF05669","PF05679","PF05680","PF05681","PF05683","PF05693","PF05699","PF05704","PF05706","PF05724","PF05746","PF05788","PF05822","PF05824","PF05826","PF05830","PF05842","PF05853","PF05864","PF05869","PF05870","PF05873","PF05874","PF05875","PF05876","PF05881","PF05889","PF05891","PF05893","PF05896","PF05902","PF05903","PF05925","PF05933","PF05935","PF05944","PF05953","PF05958","PF05970","PF05971","PF05983","PF05985","PF05992","PF05995","PF05996","PF06007","PF06016","PF06017","PF06021","PF06026","PF06027","PF06039","PF06052","PF06058","PF06064","PF06070","PF06083","PF06087","PF06090","PF06100","PF06130","PF06134","PF06144","PF06151","PF06152","PF06175","PF06179","PF06180","PF06184","PF06189","PF06206","PF06214","PF06237","PF06253","PF06268","PF06273","PF06280","PF06281","PF06309","PF06314","PF06315","PF06317","PF06324","PF06326","PF06327","PF06330","PF06333","PF06337","PF06339","PF06350","PF06351","PF06357","PF06368","PF06369","PF06377","PF06379","PF06389","PF06403","PF06404","PF06405","PF06414","PF06415","PF06416","PF06418","PF06422","PF06423","PF06426","PF06427","PF06433","PF06434","PF06436","PF06437","PF06439","PF06440","PF06442","PF06444","PF06448","PF06450","PF06452","PF06455","PF06457","PF06459","PF06466","PF06471","PF06472","PF06478","PF06479","PF06480","PF06481","PF06506","PF06512","PF06519","PF06546","PF06558","PF06559","PF06560","PF06574","PF06580","PF06609","PF06610","PF06616","PF06617","PF06621","PF06630","PF06652","PF06668","PF06689","PF06701","PF06725","PF06733","PF06734","PF06736","PF06737","PF06738","PF06751","PF06753","PF06769","PF06778","PF06800","PF06815","PF06817","PF06821","PF06825","PF06831","PF06841","PF06849","PF06859","PF06872","PF06874","PF06883","PF06888","PF06917","PF06925","PF06929","PF06941","PF06951","PF06954","PF06955","PF06957","PF06963","PF06964","PF06973","PF06974","PF06990","PF07057","PF07075","PF07109","PF07110","PF07124","PF07137","PF07140","PF07156","PF07194","PF07212","PF07221","PF07224","PF07259","PF07260","PF07284","PF07294","PF07297","PF07328","PF07335","PF07355","PF07357","PF07361","PF07365","PF07421","PF07428","PF07429","PF07463","PF07475","PF07477","PF07478","PF07479","PF07486","PF07487","PF07488","PF07491","PF07492","PF07499","PF07508","PF07536","PF07541","PF07544","PF07562","PF07565","PF07578","PF07580","PF07652","PF07663","PF07664","PF07669","PF07685","PF07690","PF07694","PF07701","PF07706","PF07711","PF07714","PF07716","PF07718","PF07722","PF07724","PF07726","PF07728","PF07730","PF07731","PF07733","PF07740","PF07745","PF07748","PF07757","PF07780","PF07781","PF07819","PF07821","PF07822","PF07823","PF07826","PF07827","PF07829","PF07830","PF07831","PF07834","PF07836","PF07837","PF07847","PF07850","PF07859","PF07881","PF07882","PF07925","PF07930","PF07934","PF07936","PF07940","PF07941","PF07942","PF07943","PF07952","PF07955","PF07959","PF07966","PF07973","PF07984","PF07992","PF07994","PF07998","PF08015","PF08022","PF08027","PF08029","PF08030","PF08031","PF08032","PF08037","PF08064","PF08072","PF08086","PF08089","PF08092","PF08093","PF08094","PF08098","PF08099","PF08100","PF08111","PF08112","PF08114","PF08117","PF08119","PF08120","PF08121","PF08123","PF08125","PF08126","PF08127","PF08133","PF08138","PF08147","PF08152","PF08187","PF08210","PF08211","PF08214","PF08218","PF08220","PF08241","PF08245","PF08246","PF08264","PF08267","PF08272","PF08273","PF08276","PF08278","PF08281","PF08283","PF08289","PF08290","PF08302","PF08303","PF08326","PF08328","PF08329","PF08332","PF08335","PF08336","PF08337","PF08354","PF08360","PF08369","PF08375","PF08392","PF08396","PF08398","PF08402","PF08405","PF08407","PF08408","PF08411","PF08414","PF08417","PF08437","PF08440","PF08445","PF08452","PF08459","PF08463","PF08465","PF08467","PF08468","PF08469","PF08471","PF08472","PF08476","PF08485","PF08488","PF08490","PF08491","PF08494","PF08496","PF08498","PF08500","PF08501","PF08502","PF08503","PF08509","PF08515","PF08519","PF08529","PF08530","PF08532","PF08533","PF08534","PF08540","PF08545","PF08552","PF08558","PF08587","PF08589","PF08597","PF08612","PF08618","PF08619","PF08633","PF08638","PF08658","PF08671","PF08675","PF08685","PF08689","PF08694","PF08703","PF08704","PF08707","PF08714","PF08715","PF08717","PF08718","PF08727","PF08731","PF08744","PF08752","PF08767","PF08769","PF08774","PF08797","PF08815","PF08825","PF08826","PF08845","PF08915","PF08917","PF08918","PF08919","PF08926","PF08941","PF08943","PF08990","PF08992","PF08996","PF09000","PF09003","PF09004","PF09009","PF09013","PF09015","PF09017","PF09019","PF09028","PF09029","PF09030","PF09036","PF09040","PF09055","PF09061","PF09064","PF09095","PF09106","PF09107","PF09115","PF09126","PF09127","PF09128","PF09139","PF09142","PF09154","PF09157","PF09165","PF09166","PF09168","PF09171","PF09172","PF09175","PF09179","PF09180","PF09181","PF09184","PF09190","PF09194","PF09195","PF09198","PF09202","PF09206","PF09208","PF09226","PF09229","PF09230","PF09231","PF09238","PF09239","PF09242","PF09243","PF09249","PF09254","PF09258","PF09260","PF09261","PF09265","PF09266","PF09268","PF09271","PF09272","PF09281","PF09284","PF09286","PF09290","PF09296","PF09297","PF09298","PF09308","PF09317","PF09326","PF09328","PF09334","PF09338","PF09363","PF09382","PF09396","PF09412","PF09416","PF09419","PF09445","PF09456","PF09472","PF09488","PF09497","PF09505","PF09506","PF09515","PF09519","PF09520","PF09521","PF09553","PF09564","PF09567","PF09568","PF09570","PF09571","PF09572","PF09573","PF09594","PF09596","PF09604","PF09606","PF09618","PF09637","PF09663","PF09668","PF09730","PF09743","PF09748","PF09749","PF09768","PF09788","PF09810","PF09830","PF09861","PF09907","PF09949","PF09995","PF10014","PF10018","PF10093","PF10120","PF10137","PF10143","PF10156","PF10163","PF10230","PF10232","PF10237","PF10255","PF10261","PF10272","PF10278","PF10280","PF10324","PF10354","PF10371","PF10380","PF10385","PF10391","PF10399","PF10401","PF10408","PF10410","PF10415","PF10417","PF10430","PF10432","PF10458","PF10459","PF10466","PF10467","PF10468","PF10473","PF10486","PF10502","PF10503","PF10530","PF10579","PF10588","PF10605","PF10613","PF10620","PF10637","PF10640","PF10664","PF10672","PF10716","PF10744","PF10766","PF10778","PF11035","PF11051","PF11080","PF11266","PF11289","PF11380","PF11389","PF11408","PF11411","PF11421","PF11429","PF11461","PF11468","PF11522","PF11590","PF11593","PF11606","PF11616","PF11629","PF11640","PF11663","PF11704","PF11722","PF11734","PF11791","PF11803","PF11806","PF11808","PF11815","PF11837","PF11847","PF11857","PF11883","PF11889","PF11890","PF11896","PF11909","PF11910","PF11956","PF11960","PF11965","PF11973","PF11975","PF11991","PF12009","PF12011","PF12017","PF12062","PF12063","PF12070","PF12105","PF12106","PF12122","PF12125","PF12131","PF12137","PF12141","PF12142","PF12142","PF12143","PF12143","PF12162","PF12169","PF12170","PF12179","PF12190","PF12202","PF12217","PF12242","PF12249","PF12250","PF12257","PF12285","PF12289","PF12300","PF12343","PF12356","PF12387","PF12398","PF12404","PF12409","PF12424","PF12437","PF12464","PF12467","PF12474","PF12483","PF12503","PF12513","PF12549","PF12567","PF12581","PF12589","PF12590","PF12601","PF12605","PF12643","PF12679","PF12689","PF12695","PF12740","PF12802","PF12822","PF12829","PF12833","PF12861","PF12897","PF12899","PF12905","PF12919","PF12929","PF12940","PF13000","PF13001","PF13085","PF13086","PF13145","PF13292","PF13302","PF13303","PF13304","PF13307","PF13350","PF13354","PF13361","PF13367","PF13442","PF13456","PF13463","PF13476","PF13506","PF13508","PF13520","PF13539","PF13597","PF13603","PF13609","PF13631","PF13656","PF13673","PF13718","PF13748","PF13806","PF13822","PF13839","PF13853","PF13939","PF13958","PF13979","PF14010","PF14021","PF14027","PF14130","PF14249","PF14369","PF14436","PF14437","PF14489","PF14496","PF14521","PF14528","PF14529","PF14572","PF14583","PF14587","PF14622","PF14718","PF14721","PF14724","PF14736","PF14752","PF14829","PF14850","PF14863","PF15019","PF15024","PF15048","PF15085","PF15095","PF15108","PF15129","PF15170","PF15171","PF15172","PF15177","PF15216","PF15270","PF15291","PF15299","PF15313","PF15328","PF15360","PF15461","PF15721","PF15785","PF15937","PF15953","PF15971","PF16011","PF16178","PF16179","PF16257","PF16317","PF16421","PF16499","PF16554","PF16590","PF16647","PF16649","PF16656","PF16683","PF16685","PF16715","PF16754","PF16782","PF16845","PF16850","PF16867","PF16892","PF16944","PF16952","PF16954","PF16957","PF16965","PF16981","PF16983","PF17049","PF17222","PF17297","PF17317","PF17321","PF17327","PF17433","PF17825","PF17907","PF17951","PF18089","PF18253","PF18325","PF18678","PF18916","PF18927","PF19034","PF19045","PF19048","PF19055","PF19088","PF19112","PF19188","PF19298","PF19315","PF19325","PF19326","PF19567","PF19580","PF19697","PF19778","PF20085","PF20162","PF20170","PF20441","PF20454","PF20511","PF07963","PF10581","PF12393","PF14665"
};

static LinkedList<String> interpro_binding_list;
static LinkedList<String> interpro_activity_list;
//get repeats pfam
void get_interpro_binding() throws IOException{

	interpro_binding_list = new LinkedList();
	interpro_activity_list = new LinkedList();

	for(int q= 0; q < interpro_binding.length; q++){

		interpro_binding_list.add(interpro_binding[q]);
	}

	for(int q= 0; q < interpro_activity.length; q++){

		interpro_activity_list.add(interpro_activity[q]);
	}

}
static LinkedHashMap<LinkedList<String>,LinkedList<String>> human_disordered_all_neighbor_domain;
static LinkedList<LinkedList<String>> human_disordered;

static LinkedList<LinkedList<String>> low_complex_gene_pfam_human;

static LinkedList<String> low_complex_gene_human;

void map_low_complex_pfams() throws IOException{

	System.out.println("map_low_complex_pfams():" );

	low_complex_gene_pfam_human = new LinkedList();
	

	low_complex_gene_human    = new LinkedList(); 	
	

  	Pattern space_pattern = Pattern.compile("\\s+");
	Pattern tab_pattern = Pattern.compile("	");
	Pattern comma_pattern = Pattern.compile(",");
	Pattern colon_pattern = Pattern.compile(":");
	
	String input="data/LCR-eXXXplorer.txt";
	
	List<String> lines  = FileUtils.readLines(new File(input));

	for(int q= 0; q < lines.size(); q++){
	
		String one_line = lines.get(q).trim().toUpperCase();
		
		if(!one_line.equals("")){

			

			String[] tab_split = tab_pattern.split(one_line);

			if(tab_split[1].trim().contains("ENSG")){
				String humanid = tab_split[1].trim();
				String enst = ensg_enst.get(humanid);
				LinkedList<String> pfams = map_pfam_human_gene.get(enst);

				if(pfams != null){

					Collections.sort((List)pfams);
					if(!low_complex_gene_human.contains(humanid)){

						low_complex_gene_human.add(humanid);
					}

					if(!low_complex_gene_pfam_human.contains(pfams)){

						low_complex_gene_pfam_human.add(pfams);
					}
				}
			}

		}
	
	}//q
	System.out.println("low_complex_gene_pfam_human:" + low_complex_gene_pfam_human.size());
	
}


/////////////////////

static LinkedList<String> llps_uniprot;
static LinkedList<LinkedList<String>> llps_pfam;
static LinkedList<LinkedList<String>> llps_dimer_pfam;
static LinkedList<String> llps_one_pfam;
static LinkedList<String> llps_one_pfam_all;

void  get_llps_uniprot_pfam()  throws IOException{

	Pattern space_pattern = Pattern.compile("\\s+");

	String path = "data/LLPS.txt";
 	
	List<String> lines  = FileUtils.readLines(new File(path));
	llps_uniprot = new LinkedList();
	llps_pfam = new LinkedList();
	llps_dimer_pfam = new LinkedList();
	llps_one_pfam = new LinkedList();
	llps_one_pfam_all = new LinkedList();
	

	for(int k = 1; k < lines.size(); k++){
				
		String one_line = lines.get(k).toUpperCase();
		String[] space_split = space_pattern.split(one_line);
		llps_uniprot.add(space_split[1].trim());

		LinkedList<String> pfams = sifts_uniprot_pfam_new.get(space_split[1].trim());
		
		if(pfams != null){

			Collections.sort((List)pfams);
			if(!llps_pfam.contains(pfams)){
			
				llps_pfam.add(pfams);
			}

			//System.out.println("llps_pfam:" + llps_pfam.size());

			for(int q = 0; q < pfams.size(); q++){

				LinkedList<String> temp_dimer = new LinkedList();
				temp_dimer.add(pfams.get(q));
				temp_dimer.add(pfams.get(q));

				if(!llps_dimer_pfam.contains(temp_dimer)){

					llps_dimer_pfam.add(temp_dimer);
				}
			}


			if(pfams.size() > 1){

				Combinations comb= new Combinations(pfams.size(),2);
				Iterator<int[]> iter = comb.iterator();
				
													 	
				while(iter.hasNext()){
													 	
					int[] temp_set = iter.next();
					String comb1 = pfams.get(temp_set[0]);
					String comb2 = pfams.get(temp_set[1]);
					LinkedList<String> comb_set = new LinkedList();
											
					comb_set.add(comb1);
					comb_set.add(comb2);
					Collections.sort((List)comb_set);

					if(!llps_one_pfam_all.contains(comb1)){

						llps_one_pfam_all.add(comb1);
				
					}

					if(!llps_one_pfam_all.contains(comb2)){

						llps_one_pfam_all.add(comb2);
				
					}

					if(!llps_dimer_pfam.contains(comb_set)){

						llps_dimer_pfam.add(comb_set);
					}
				}
			}else{
				if(!llps_one_pfam.contains(pfams.get(0))){

					llps_one_pfam.add(pfams.get(0));
			
				}

				if(!llps_one_pfam_all.contains(pfams.get(0))){

					llps_one_pfam_all.add(pfams.get(0));
			
				}

				LinkedList<String> comb_set = new LinkedList();
											
				comb_set.add(pfams.get(0));
				comb_set.add(pfams.get(0));
				if(!llps_dimer_pfam.contains(comb_set)){

					llps_dimer_pfam.add(comb_set);
				}

			}	
		}else{
		
			System.out.println("pfam null error 6135:" + one_line);
		}

        }//k
								
								
    }//method


static String[] llps_func_type = {"Client","Regulator","Scaffold"};

static String[][] conden_cat = {
{"Balbiani body"},
{"Cajal body"},
{"Cajal body","Centrosome@Spindle pole body"},
{"Cajal body","Gemini of cajal body","P-body","Stress granule","U body","Others"},
{"Cajal body","Histone locus body"},
{"Cajal body","Histone locus body","U body"},
{"Cajal body","Neuronal granule","Stress granule","Postsynaptic density"},
{"Cajal body","Nuclear speckle"},
{"Cajal body","Nuclear speckle","Nucleolus"},
{"Cajal body","Nuclear speckle","Nucleolus","Centrosome@Spindle pole body","Stress granule"},
{"Cajal body","Nuclear speckle","Nucleolus","PML nuclear body","Others"},
{"Cajal body","Nucleolus"},
{"Cajal body","Nucleolus","Centrosome@Spindle pole body"},
{"Cajal body","Nucleolus","P-body"},
{"Cajal body","Nucleolus","P-body","Stress granule"},
{"Cajal body","Nucleolus","Stress granule"},
{"Cajal body","Others"},
{"Cajal body","P-body","Stress granule"},
{"Cajal body","PML nuclear body","Others"},
{"Cajal body","Postsynaptic density"},
{"Cajal body","Sam68 nuclear body","Stress granule"},
{"Cajal body","Stress granule"},
{"Cajal body","Stress granule","Others"},
{"Centrosome@Spindle pole body"},
{"Centrosome@Spindle pole body","Chromatoid body"},
{"Centrosome@Spindle pole body","Microtubule"},
{"Centrosome@Spindle pole body","Microtubule","Stress granule"},
{"Centrosome@Spindle pole body","Others"},
{"Centrosome@Spindle pole body","P granule"},
{"Centrosome@Spindle pole body","P-body"},
{"Centrosome@Spindle pole body","P-body","Others"},
{"Centrosome@Spindle pole body","P-body","Stress granule"},
{"Centrosome@Spindle pole body","P-body","Stress granule","Others"},
{"Centrosome@Spindle pole body","P-body","Stress granule","Postsynaptic density"},
{"Centrosome@Spindle pole body","Pericentriolar matrix"},
{"Centrosome@Spindle pole body","Pericentriolar matrix","P granule"},
{"Centrosome@Spindle pole body","Postsynaptic density"},
{"Centrosome@Spindle pole body","Postsynaptic density","Others"},
{"Centrosome@Spindle pole body","Spindle apparatus"},
{"Centrosome@Spindle pole body","Spindle apparatus","Balbiani body"},
{"Centrosome@Spindle pole body","Spindle apparatus","Postsynaptic density"},
{"Centrosome@Spindle pole body","Stress granule"},
{"Centrosome@Spindle pole body","Stress granule","Others"},
{"Centrosome@Spindle pole body","Stress granule","Postsynaptic density"},
{"Centrosome@Spindle pole body","Stress granule","Receptor cluster"},
{"Chromatoid body"},
{"Chromatoid body","Nuage"},
{"Chromatoid body","Postsynaptic density"},
{"Cleavage body","DDX1 body","Nucleolus","P-body","Stress granule","Postsynaptic density"},
{"Cleavage body","Histone locus body"},
{"Condensate"},
{"DNA damage foci"},
{"DNA damage foci","Nuclear speckle","Nucleolus","PML nuclear body"},
{"DNA damage foci","Nucleolus"},
{"DNA damage foci","Nucleolus","Centrosome@Spindle pole body"},
{"DNA damage foci","Nucleolus","Centrosome@Spindle pole body","Stress granule"},
{"DNA damage foci","Nucleolus","PML nuclear body","Centrosome@Spindle pole body","Stress granule"},
{"DNA damage foci","OPT domain"},
{"DNA damage foci","PML nuclear body","Stress granule"},
{"Droplet"},
{"Droplet","Cajal body","Gemini of cajal body","Paraspeckle","P-body","Stress granule","Others"},
{"Droplet","Cajal body","Neuronal granule","P-body","Stress granule","Others"},
{"Droplet","Cajal body","Nuclear speckle","Nucleolus","PML nuclear body","Centrosome@Spindle pole body","Postsynaptic density"},
{"Droplet","Cajal body","Nucleolus","Stress granule"},
{"Droplet","Centrosome@Spindle pole body"},
{"Droplet","Centrosome@Spindle pole body","Microtubule","Stress granule","Postsynaptic density"},
{"Droplet","Centrosome@Spindle pole body","Others"},
{"Droplet","Centrosome@Spindle pole body","P granule"},
{"Droplet","Centrosome@Spindle pole body","Pericentriolar matrix","Spindle apparatus","P granule"},
{"Droplet","Centrosome@Spindle pole body","Postsynaptic density"},
{"Droplet","Centrosome@Spindle pole body","Stress granule"},
{"Droplet","Chromatin"},
{"Droplet","Cleavage body","DDX1 body"},
{"Droplet","DNA damage foci","Gemini of cajal body","Nuclear speckle","Nucleolus","Paraspeckle","P-body","Stress granule","Others"},
{"Droplet","Nuage","Others"},
{"Droplet","Nuclear pore complex"},
{"Droplet","Nuclear pore complex","Stress granule"},
{"Droplet","Nuclear speckle","Nucleolus"},
{"Droplet","Nuclear speckle","Nucleolus","P-body","Stress granule"},
{"Droplet","Nuclear speckle","Nucleolus","Paraspeckle","Sam68 nuclear body","Stress granule","Postsynaptic density","Others"},
{"Droplet","Nuclear speckle","Nucleolus","Paraspeckle","Stress granule"},
{"Droplet","Nuclear speckle","Nucleolus","Stress granule","Others"},
{"Droplet","Nuclear speckle","P-body","Stress granule","Chromatoid body"},
{"Droplet","Nucleolus"},
{"Droplet","Nucleolus","Centrosome@Spindle pole body","Postsynaptic density"},
{"Droplet","Nucleolus","Centrosome@Spindle pole body","Stress granule"},
{"Droplet","Nucleolus","Others"},
{"Droplet","Nucleolus","P-body"},
{"Droplet","Nucleolus","P-body","Stress granule"},
{"Droplet","Nucleolus","P-body","Stress granule","Postsynaptic density"},
{"Droplet","Nucleolus","PML nuclear body","Centrosome@Spindle pole body","Stress granule","Postsynaptic density"},
{"Droplet","Nucleolus","Paraspeckle"},
{"Droplet","Nucleolus","Postsynaptic density"},
{"Droplet","Nucleolus","Sam68 nuclear body","Stress granule"},
{"Droplet","Nucleolus","Spindle apparatus","Others"},
{"Droplet","Nucleolus","Stress granule"},
{"Droplet","Others"},
{"Droplet","P granule"},
{"Droplet","P-body"},
{"Droplet","P-body","P granule"},
{"Droplet","P-body","Stress granule"},
{"Droplet","P-body","Stress granule","Balbiani body"},
{"Droplet","P-body","Stress granule","Others"},
{"Droplet","PML nuclear body"},
{"Droplet","PML nuclear body","Centrosome@Spindle pole body"},
{"Droplet","Paraspeckle","PML nuclear body","Centrosome@Spindle pole body"},
{"Droplet","PcG body"},
{"Droplet","Postsynaptic density"},
{"Droplet","Pyrenoid matrix"},
{"Droplet","Receptor cluster"},
{"Droplet","Stress granule"},
{"Droplet","Stress granule","Others"},
{"Droplet","Stress granule","Postsynaptic density"},
{"Gemini of cajal body"},
{"Gemini of cajal body","Nucleolus"},
{"Gemini of cajal body","Stress granule"},
{"Gemini of cajal body","Stress granule","Postsynaptic density"},
{"Germ plasm@Polar granule"},
{"Histone locus body"},
{"Histone locus body","Insulator body"},
{"Histone locus body","PcG body"},
{"Histone locus body","PcG body","Centrosome@Spindle pole body"},
{"Histone locus body","Stress granule"},
{"Insulator body"},
{"Insulator body","Centrosome@Spindle pole body"},
{"Microtubule"},
{"Mitochondrial RNA granule"},
{"Neuronal granule"},
{"Neuronal granule","Chromatoid body"},
{"Neuronal granule","Chromatoid body","Postsynaptic density"},
{"Neuronal granule","Others"},
{"Neuronal granule","P-body","Stress granule"},
{"Neuronal granule","P-body","Stress granule","Others"},
{"Neuronal granule","Postsynaptic density"},
{"Neuronal granule","Stress granule"},
{"Neuronal granule","Stress granule","Chromatoid body"},
{"Neuronal granule","Stress granule","Postsynaptic density"},
{"Nuclear speckle"},
{"Nuclear speckle","Centrosome@Spindle pole body"},
{"Nuclear speckle","Centrosome@Spindle pole body","Stress granule"},
{"Nuclear speckle","Nuclear stress body","Nucleolus","Stress granule"},
{"Nuclear speckle","Nucleolus"},
{"Nuclear speckle","Nucleolus","Centrosome@Spindle pole body"},
{"Nuclear speckle","Nucleolus","P-body"},
{"Nuclear speckle","Nucleolus","P-body","Stress granule"},
{"Nuclear speckle","Nucleolus","P-body","Stress granule","Others"},
{"Nuclear speckle","Nucleolus","P-body","Stress granule","Postsynaptic density"},
{"Nuclear speckle","Nucleolus","Paraspeckle","Neuronal granule","P-body","Stress granule"},
{"Nuclear speckle","Nucleolus","Paraspeckle","Stress granule"},
{"Nuclear speckle","Nucleolus","Postsynaptic density"},
{"Nuclear speckle","Nucleolus","Sam68 nuclear body","Stress granule","Postsynaptic density"},
{"Nuclear speckle","Nucleolus","Stress granule"},
{"Nuclear speckle","P-body"},
{"Nuclear speckle","P-body","Stress granule"},
{"Nuclear speckle","PML nuclear body"},
{"Nuclear speckle","Paraspeckle"},
{"Nuclear speckle","Postsynaptic density"},
{"Nuclear speckle","Sam68 nuclear body"},
{"Nuclear speckle","Spindle apparatus","Stress granule"},
{"Nuclear speckle","Stress granule"},
{"Nuclear stress body"},
{"Nuclear stress body","Centrosome@Spindle pole body","Stress granule"},
{"Nuclear stress body","Stress granule"},
{"Nucleolus"},
{"Nucleolus","Centrosome@Spindle pole body"},
{"Nucleolus","Centrosome@Spindle pole body","P-body"},
{"Nucleolus","Centrosome@Spindle pole body","P-body","Stress granule","Postsynaptic density"},
{"Nucleolus","Centrosome@Spindle pole body","Postsynaptic density"},
{"Nucleolus","Centrosome@Spindle pole body","Stress granule"},
{"Nucleolus","Centrosome@Spindle pole body","Stress granule","Postsynaptic density"},
{"Nucleolus","Chromatoid body"},
{"Nucleolus","Chromatoid body","Postsynaptic density"},
{"Nucleolus","Mitochondrial RNA granule"},
{"Nucleolus","Neuronal granule","Stress granule"},
{"Nucleolus","Others"},
{"Nucleolus","P-body"},
{"Nucleolus","P-body","Others"},
{"Nucleolus","P-body","Postsynaptic density"},
{"Nucleolus","P-body","Stress granule"},
{"Nucleolus","P-body","Stress granule","Others"},
{"Nucleolus","P-body","Stress granule","Postsynaptic density"},
{"Nucleolus","P-body","Stress granule","Postsynaptic density","Others"},
{"Nucleolus","PML nuclear body"},
{"Nucleolus","PML nuclear body","Centrosome@Spindle pole body"},
{"Nucleolus","PML nuclear body","Centrosome@Spindle pole body","Postsynaptic density"},
{"Nucleolus","PML nuclear body","Stress granule","Postsynaptic density"},
{"Nucleolus","Paraspeckle"},
{"Nucleolus","Paraspeckle","Centrosome@Spindle pole body","P-body","Stress granule"},
{"Nucleolus","Paraspeckle","P-body"},
{"Nucleolus","Paraspeckle","P-body","Stress granule"},
{"Nucleolus","Paraspeckle","Stress granule"},
{"Nucleolus","PcG body"},
{"Nucleolus","Postsynaptic density"},
{"Nucleolus","Postsynaptic density","Others"},
{"Nucleolus","Sam68 nuclear body"},
{"Nucleolus","Sam68 nuclear body","P-body","Stress granule"},
{"Nucleolus","Sam68 nuclear body","Stress granule"},
{"Nucleolus","Spindle apparatus"},
{"Nucleolus","Spindle apparatus","Stress granule"},
{"Nucleolus","Stress granule"},
{"Nucleolus","Stress granule","Mitochondrial RNA granule"},
{"Nucleolus","Stress granule","Others"},
{"Nucleolus","Stress granule","Postsynaptic density"},
{"Nucleolus","Stress granule","Postsynaptic density","Others"},
{"Nucleolus","TAM body"},
{"Nucleolus","siRNA body"},
{"OPT domain"},
{"OPT domain","Centrosome@Spindle pole body"},
{"OPT domain","P-body","Stress granule"},
{"Others"},
{"P granule"},
{"P-body"},
{"P-body","Chromatoid body"},
{"P-body","Germ plasm@Polar granule"},
{"P-body","Nuage","Sponge body"},
{"P-body","Others"},
{"P-body","P granule"},
{"P-body","Postsynaptic density"},
{"P-body","Spindle apparatus"},
{"P-body","Sponge body"},
{"P-body","Stress granule"},
{"P-body","Stress granule","Chromatoid body"},
{"P-body","Stress granule","Mitochondrial RNA granule"},
{"P-body","Stress granule","Mitochondrial RNA granule","Postsynaptic density"},
{"P-body","Stress granule","Others"},
{"P-body","Stress granule","P granule"},
{"P-body","Stress granule","Postsynaptic density"},
{"P-body","Stress granule","Sponge body"},
{"P-body","Stress granule","TAM body","Others"},
{"P-body","siRNA body"},
{"PML nuclear body"},
{"PML nuclear body","Centrosome@Spindle pole body"},
{"PML nuclear body","Others"},
{"PML nuclear body","P granule"},
{"PML nuclear body","P-body"},
{"PML nuclear body","Postsynaptic density"},
{"PML nuclear body","Stress granule"},
{"PML nuclear body","Stress granule","Others"},
{"Paraspeckle"},
{"Paraspeckle","Centrosome@Spindle pole body"},
{"Paraspeckle","Neuronal granule","Postsynaptic density"},
{"Paraspeckle","P-body","Postsynaptic density"},
{"PcG body"},
{"PcG body","Others"},
{"PcG body","PML nuclear body"},
{"Perinucleolar compartment"},
{"Perinucleolar compartment","P-body","Stress granule"},
{"Postsynaptic density"},
{"Postsynaptic density","Receptor cluster"},
{"Pyrenoid matrix"},
{"Receptor cluster"},
{"Sam68 nuclear body"},
{"Spindle apparatus"},
{"Spindle apparatus","Postsynaptic density"},
{"Spindle apparatus","Stress granule","Others"},
{"Sponge body"},
{"Stress granule"},
{"Stress granule","Chromatoid body","Postsynaptic density","Others"},
{"Stress granule","Mitochondrial RNA granule"},
{"Stress granule","Others"},
{"Stress granule","P granule"},
{"Stress granule","Postsynaptic density"},
{"Stress granule","Postsynaptic density","Others"},
{"TAM body"},
{"U body"}
};

static String[] conden_cat_big ={
"Balbiani body",
"Cajal body",
"Cajal body&Centrosome@Spindle pole body",
"Cajal body&Gemini of cajal body&P-body&Stress granule&U body&Others",
"Cajal body&Histone locus body",
"Cajal body&Histone locus body&U body",
"Cajal body&Neuronal granule&Stress granule&Postsynaptic density",
"Cajal body&Nuclear speckle",
"Cajal body&Nuclear speckle&Nucleolus",
"Cajal body&Nuclear speckle&Nucleolus&Centrosome@Spindle pole body&Stress granule",
"Cajal body&Nuclear speckle&Nucleolus&PML nuclear body&Others",
"Cajal body&Nucleolus",
"Cajal body&Nucleolus&Centrosome@Spindle pole body",
"Cajal body&Nucleolus&P-body",
"Cajal body&Nucleolus&P-body&Stress granule",
"Cajal body&Nucleolus&Stress granule",
"Cajal body&Others",
"Cajal body&P-body&Stress granule",
"Cajal body&PML nuclear body&Others",
"Cajal body&Postsynaptic density",
"Cajal body&Sam68 nuclear body&Stress granule",
"Cajal body&Stress granule",
"Cajal body&Stress granule&Others",
"Centrosome@Spindle pole body",
"Centrosome@Spindle pole body&Chromatoid body",
"Centrosome@Spindle pole body&Microtubule",
"Centrosome@Spindle pole body&Microtubule&Stress granule",
"Centrosome@Spindle pole body&Others",
"Centrosome@Spindle pole body&P granule",
"Centrosome@Spindle pole body&P-body",
"Centrosome@Spindle pole body&P-body&Others",
"Centrosome@Spindle pole body&P-body&Stress granule",
"Centrosome@Spindle pole body&P-body&Stress granule&Others",
"Centrosome@Spindle pole body&P-body&Stress granule&Postsynaptic density",
"Centrosome@Spindle pole body&Pericentriolar matrix",
"Centrosome@Spindle pole body&Pericentriolar matrix&P granule",
"Centrosome@Spindle pole body&Postsynaptic density",
"Centrosome@Spindle pole body&Postsynaptic density&Others",
"Centrosome@Spindle pole body&Spindle apparatus",
"Centrosome@Spindle pole body&Spindle apparatus&Balbiani body",
"Centrosome@Spindle pole body&Spindle apparatus&Postsynaptic density",
"Centrosome@Spindle pole body&Stress granule",
"Centrosome@Spindle pole body&Stress granule&Others",
"Centrosome@Spindle pole body&Stress granule&Postsynaptic density",
"Centrosome@Spindle pole body&Stress granule&Receptor cluster",
"Chromatoid body",
"Chromatoid body&Nuage",
"Chromatoid body&Postsynaptic density",
"Cleavage body&DDX1 body&Nucleolus&P-body&Stress granule&Postsynaptic density",
"Cleavage body&Histone locus body",
"Condensate",
"DNA damage foci",
"DNA damage foci&Nuclear speckle&Nucleolus&PML nuclear body",
"DNA damage foci&Nucleolus",
"DNA damage foci&Nucleolus&Centrosome@Spindle pole body",
"DNA damage foci&Nucleolus&Centrosome@Spindle pole body&Stress granule",
"DNA damage foci&Nucleolus&PML nuclear body&Centrosome@Spindle pole body&Stress granule",
"DNA damage foci&OPT domain",
"DNA damage foci&PML nuclear body&Stress granule",
"Droplet",
"Droplet&Cajal body&Gemini of cajal body&Paraspeckle&P-body&Stress granule&Others",
"Droplet&Cajal body&Neuronal granule&P-body&Stress granule&Others",
"Droplet&Cajal body&Nuclear speckle&Nucleolus&PML nuclear body&Centrosome@Spindle pole body&Postsynaptic density",
"Droplet&Cajal body&Nucleolus&Stress granule",
"Droplet&Centrosome@Spindle pole body",
"Droplet&Centrosome@Spindle pole body&Microtubule&Stress granule&Postsynaptic density",
"Droplet&Centrosome@Spindle pole body&Others",
"Droplet&Centrosome@Spindle pole body&P granule",
"Droplet&Centrosome@Spindle pole body&Pericentriolar matrix&Spindle apparatus&P granule",
"Droplet&Centrosome@Spindle pole body&Postsynaptic density",
"Droplet&Centrosome@Spindle pole body&Stress granule",
"Droplet&Chromatin",
"Droplet&Cleavage body&DDX1 body",
"Droplet&DNA damage foci&Gemini of cajal body&Nuclear speckle&Nucleolus&Paraspeckle&P-body&Stress granule&Others",
"Droplet&Nuage&Others",
"Droplet&Nuclear pore complex",
"Droplet&Nuclear pore complex&Stress granule",
"Droplet&Nuclear speckle&Nucleolus",
"Droplet&Nuclear speckle&Nucleolus&P-body&Stress granule",
"Droplet&Nuclear speckle&Nucleolus&Paraspeckle&Sam68 nuclear body&Stress granule&Postsynaptic density&Others",
"Droplet&Nuclear speckle&Nucleolus&Paraspeckle&Stress granule",
"Droplet&Nuclear speckle&Nucleolus&Stress granule&Others",
"Droplet&Nuclear speckle&P-body&Stress granule&Chromatoid body",
"Droplet&Nucleolus",
"Droplet&Nucleolus&Centrosome@Spindle pole body&Postsynaptic density",
"Droplet&Nucleolus&Centrosome@Spindle pole body&Stress granule",
"Droplet&Nucleolus&Others",
"Droplet&Nucleolus&P-body",
"Droplet&Nucleolus&P-body&Stress granule",
"Droplet&Nucleolus&P-body&Stress granule&Postsynaptic density",
"Droplet&Nucleolus&PML nuclear body&Centrosome@Spindle pole body&Stress granule&Postsynaptic density",
"Droplet&Nucleolus&Paraspeckle",
"Droplet&Nucleolus&Postsynaptic density",
"Droplet&Nucleolus&Sam68 nuclear body&Stress granule",
"Droplet&Nucleolus&Spindle apparatus&Others",
"Droplet&Nucleolus&Stress granule",
"Droplet&Others",
"Droplet&P granule",
"Droplet&P-body",
"Droplet&P-body&P granule",
"Droplet&P-body&Stress granule",
"Droplet&P-body&Stress granule&Balbiani body",
"Droplet&P-body&Stress granule&Others",
"Droplet&PML nuclear body",
"Droplet&PML nuclear body&Centrosome@Spindle pole body",
"Droplet&Paraspeckle&PML nuclear body&Centrosome@Spindle pole body",
"Droplet&PcG body",
"Droplet&Postsynaptic density",
"Droplet&Pyrenoid matrix",
"Droplet&Receptor cluster",
"Droplet&Stress granule",
"Droplet&Stress granule&Others",
"Droplet&Stress granule&Postsynaptic density",
"Gemini of cajal body",
"Gemini of cajal body&Nucleolus",
"Gemini of cajal body&Stress granule",
"Gemini of cajal body&Stress granule&Postsynaptic density",
"Germ plasm@Polar granule",
"Histone locus body",
"Histone locus body&Insulator body",
"Histone locus body&PcG body",
"Histone locus body&PcG body&Centrosome@Spindle pole body",
"Histone locus body&Stress granule",
"Insulator body",
"Insulator body&Centrosome@Spindle pole body",
"Microtubule",
"Mitochondrial RNA granule",
"Neuronal granule",
"Neuronal granule&Chromatoid body",
"Neuronal granule&Chromatoid body&Postsynaptic density",
"Neuronal granule&Others",
"Neuronal granule&P-body&Stress granule",
"Neuronal granule&P-body&Stress granule&Others",
"Neuronal granule&Postsynaptic density",
"Neuronal granule&Stress granule",
"Neuronal granule&Stress granule&Chromatoid body",
"Neuronal granule&Stress granule&Postsynaptic density",
"Nuclear speckle",
"Nuclear speckle&Centrosome@Spindle pole body",
"Nuclear speckle&Centrosome@Spindle pole body&Stress granule",
"Nuclear speckle&Nuclear stress body&Nucleolus&Stress granule",
"Nuclear speckle&Nucleolus",
"Nuclear speckle&Nucleolus&Centrosome@Spindle pole body",
"Nuclear speckle&Nucleolus&P-body",
"Nuclear speckle&Nucleolus&P-body&Stress granule",
"Nuclear speckle&Nucleolus&P-body&Stress granule&Others",
"Nuclear speckle&Nucleolus&P-body&Stress granule&Postsynaptic density",
"Nuclear speckle&Nucleolus&Paraspeckle&Neuronal granule&P-body&Stress granule",
"Nuclear speckle&Nucleolus&Paraspeckle&Stress granule",
"Nuclear speckle&Nucleolus&Postsynaptic density",
"Nuclear speckle&Nucleolus&Sam68 nuclear body&Stress granule&Postsynaptic density",
"Nuclear speckle&Nucleolus&Stress granule",
"Nuclear speckle&P-body",
"Nuclear speckle&P-body&Stress granule",
"Nuclear speckle&PML nuclear body",
"Nuclear speckle&Paraspeckle",
"Nuclear speckle&Postsynaptic density",
"Nuclear speckle&Sam68 nuclear body",
"Nuclear speckle&Spindle apparatus&Stress granule",
"Nuclear speckle&Stress granule",
"Nuclear stress body",
"Nuclear stress body&Centrosome@Spindle pole body&Stress granule",
"Nuclear stress body&Stress granule",
"Nucleolus",
"Nucleolus&Centrosome@Spindle pole body",
"Nucleolus&Centrosome@Spindle pole body&P-body",
"Nucleolus&Centrosome@Spindle pole body&P-body&Stress granule&Postsynaptic density",
"Nucleolus&Centrosome@Spindle pole body&Postsynaptic density",
"Nucleolus&Centrosome@Spindle pole body&Stress granule",
"Nucleolus&Centrosome@Spindle pole body&Stress granule&Postsynaptic density",
"Nucleolus&Chromatoid body",
"Nucleolus&Chromatoid body&Postsynaptic density",
"Nucleolus&Mitochondrial RNA granule",
"Nucleolus&Neuronal granule&Stress granule",
"Nucleolus&Others",
"Nucleolus&P-body",
"Nucleolus&P-body&Others",
"Nucleolus&P-body&Postsynaptic density",
"Nucleolus&P-body&Stress granule",
"Nucleolus&P-body&Stress granule&Others",
"Nucleolus&P-body&Stress granule&Postsynaptic density",
"Nucleolus&P-body&Stress granule&Postsynaptic density&Others",
"Nucleolus&PML nuclear body",
"Nucleolus&PML nuclear body&Centrosome@Spindle pole body",
"Nucleolus&PML nuclear body&Centrosome@Spindle pole body&Postsynaptic density",
"Nucleolus&PML nuclear body&Stress granule&Postsynaptic density",
"Nucleolus&Paraspeckle",
"Nucleolus&Paraspeckle&Centrosome@Spindle pole body&P-body&Stress granule",
"Nucleolus&Paraspeckle&P-body",
"Nucleolus&Paraspeckle&P-body&Stress granule",
"Nucleolus&Paraspeckle&Stress granule",
"Nucleolus&PcG body",
"Nucleolus&Postsynaptic density",
"Nucleolus&Postsynaptic density&Others",
"Nucleolus&Sam68 nuclear body",
"Nucleolus&Sam68 nuclear body&P-body&Stress granule",
"Nucleolus&Sam68 nuclear body&Stress granule",
"Nucleolus&Spindle apparatus",
"Nucleolus&Spindle apparatus&Stress granule",
"Nucleolus&Stress granule",
"Nucleolus&Stress granule&Mitochondrial RNA granule",
"Nucleolus&Stress granule&Others",
"Nucleolus&Stress granule&Postsynaptic density",
"Nucleolus&Stress granule&Postsynaptic density&Others",
"Nucleolus&TAM body",
"Nucleolus&siRNA body",
"OPT domain",
"OPT domain&Centrosome@Spindle pole body",
"OPT domain&P-body&Stress granule",
"Others",
"P granule",
"P-body",
"P-body&Chromatoid body",
"P-body&Germ plasm@Polar granule",
"P-body&Nuage&Sponge body",
"P-body&Others",
"P-body&P granule",
"P-body&Postsynaptic density",
"P-body&Spindle apparatus",
"P-body&Sponge body",
"P-body&Stress granule",
"P-body&Stress granule&Chromatoid body",
"P-body&Stress granule&Mitochondrial RNA granule",
"P-body&Stress granule&Mitochondrial RNA granule&Postsynaptic density",
"P-body&Stress granule&Others",
"P-body&Stress granule&P granule",
"P-body&Stress granule&Postsynaptic density",
"P-body&Stress granule&Sponge body",
"P-body&Stress granule&TAM body&Others",
"P-body&siRNA body",
"PML nuclear body",
"PML nuclear body&Centrosome@Spindle pole body",
"PML nuclear body&Others",
"PML nuclear body&P granule",
"PML nuclear body&P-body",
"PML nuclear body&Postsynaptic density",
"PML nuclear body&Stress granule",
"PML nuclear body&Stress granule&Others",
"Paraspeckle",
"Paraspeckle&Centrosome@Spindle pole body",
"Paraspeckle&Neuronal granule&Postsynaptic density",
"Paraspeckle&P-body&Postsynaptic density",
"PcG body",
"PcG body&Others",
"PcG body&PML nuclear body",
"Perinucleolar compartment",
"Perinucleolar compartment&P-body&Stress granule",
"Postsynaptic density",
"Postsynaptic density&Receptor cluster",
"Pyrenoid matrix",
"Receptor cluster",
"Sam68 nuclear body",
"Spindle apparatus",
"Spindle apparatus&Postsynaptic density",
"Spindle apparatus&Stress granule&Others",
"Sponge body",
"Stress granule",
"Stress granule&Chromatoid body&Postsynaptic density&Others",
"Stress granule&Mitochondrial RNA granule",
"Stress granule&Others",
"Stress granule&P granule",
"Stress granule&Postsynaptic density",
"Stress granule&Postsynaptic density&Others",
"TAM body",
"U body"
};

static String[] conden_type = {"Balbiani body","Cajal body","Centrosome@Spindle pole body","Chromatin","Chromatoid body","Cleavage body","DDX1 body","DNA damage foci","Droplet","Gemini of cajal body","Germ plasm@Polar granule","Histone locus body","Insulator body","Microtubule","Mitochondrial RNA granule","Neuronal granule","Nuage","Nuclear pore complex","Nuclear speckle","Nuclear stress body","Nucleolus","OPT domain","Others","Paraspeckle","P-body","PcG body","Pericentriolar matrix","Perinucleolar compartment, ","P granule","PML nuclear body","Postsynaptic density","Pyrenoid matrix","Receptor cluster","Sam68 nuclear body","siRNA body","Spindle apparatus","Sponge body","Stress granule","TAM body","U body"};

static LinkedHashMap<String,LinkedList<String>> uniprot_to_gene;
static LinkedHashMap<String,String> uniprot_to_func_type;
static LinkedHashMap<String,Boolean[][]> uniprot_to_func_type_per_conden_cat_big;
static LinkedHashMap<String,LinkedList<String>> uniprot_to_pfam_conden;
static LinkedHashMap<String,Boolean[]> uniprot_to_conden;
static LinkedHashMap<String,Boolean[]> uniprot_to_conden_cat_big;
static LinkedHashMap<String,LinkedList<String>> conden_cat_big_to_uniprot;
static LinkedHashMap<String,LinkedHashMap<String,LinkedList<String>>> conden_cat_big_to_uniprot_by_num;

static LinkedHashMap<String,Integer[]> one_pfam_to_type;
static LinkedHashMap<String,Integer[]> one_pfam_to_conden;
static LinkedHashMap<LinkedList<String>,Integer[]> dimer_pfam_to_type;
static LinkedHashMap<LinkedList<String>,Integer[]> dimer_pfam_to_conden;

static LinkedList<String> nucleus_pfam_llps;
static LinkedList<String> nucleus_gene_llps;

void  map_drllps_to_type_conden_freq()  throws IOException{

	String path = "data/LLPS.txt";
	nucleus_pfam_llps = new LinkedList();
	nucleus_gene_llps = new LinkedList();
	
	for(int k = 0; k < nucleus_atxg_llps_pfam.length; k++){
		nucleus_pfam_llps.add(nucleus_atxg_llps_pfam[k]);
	}

	LinkedList<LinkedList<String>> conden_cat_list = new LinkedList();


	for(int k = 0; k < conden_cat.length; k++){

		
		LinkedList<String> temp = new LinkedList();

		for(int q = 0; q < conden_cat[k].length; q++){

			temp.add(conden_cat[k][q].toUpperCase());

		}
		Collections.sort((List)temp);
		conden_cat_list.add(temp);
		
	}
 	
	List<String> lines  = FileUtils.readLines(new File(path));
	Pattern space_pattern = Pattern.compile("\\s+");
	Pattern tab_pattern = Pattern.compile("	");
	Pattern comma_pattern = Pattern.compile(",");
	Pattern colon_pattern = Pattern.compile(":");

	uniprot_to_gene = new LinkedHashMap();
	uniprot_to_func_type = new LinkedHashMap();
	uniprot_to_conden = new LinkedHashMap();
	uniprot_to_conden_cat_big = new LinkedHashMap();
	conden_cat_big_to_uniprot = new LinkedHashMap();
	conden_cat_big_to_uniprot_by_num = new LinkedHashMap();
	uniprot_to_func_type_per_conden_cat_big = new LinkedHashMap();
	uniprot_to_pfam_conden = new LinkedHashMap();
	
	LinkedHashMap<String,LinkedHashMap<String,LinkedList<String>>> conden_cat_big_to_uniprot_by_num_no_order = new LinkedHashMap();

	one_pfam_to_type = new LinkedHashMap();
	one_pfam_to_conden = new LinkedHashMap();
	dimer_pfam_to_type = new LinkedHashMap();
	dimer_pfam_to_conden = new LinkedHashMap();

	for(int k = 1; k < lines.size(); k++){

		String one_line = lines.get(k).toUpperCase();
		String[] space_split = tab_pattern.split(one_line);
		
		String uniid = space_split[1].trim();
		String gene = space_split[2].trim();
		String conden = space_split[5].trim();

		String[] comma_split = comma_pattern.split(conden);

		LinkedList<String> conden_cat_comp = new LinkedList();
		Boolean[] value = new Boolean[conden_type.length];
		for(int q = 0; q < value.length; q++){
			 
			 value[q] = new Boolean(false);
		}

		for(int q = 0; q < comma_split.length; q++){

			if(comma_split[q].contains("CENTROSOME") && comma_split[q].contains("SPINDLE POLE BODY")){
				comma_split[q] = "CENTROSOME@SPINDLE POLE BODY";
			}

			if(comma_split[q].contains("GERM PLASM") && comma_split[q].contains("POLAR GRANULE")){
				comma_split[q] = "GERM PLASM@POLAR GRANULE";
			}

			for(int w = 0; w < conden_type.length; w++){

				if(comma_split[q].trim().equals(conden_type[w].toUpperCase())){

					value[w] = new Boolean(true);
					conden_cat_comp.add(conden_type[w].toUpperCase());
				}

			}
		}//q

		//System.out.println("conden_cat_comp:" + Arrays.toString(conden_cat_comp.toArray()));
		Collections.sort((List)conden_cat_comp);
		int conden_cat_ind = -1;

		Collections.sort((List)conden_cat_comp);
		for(int y = 0; y < conden_cat_list.size(); y++){
					
			LinkedList<String> comp = conden_cat_list.get(y);
			//Collections.sort((List)comp);

			if(comp.containsAll(conden_cat_comp) && conden_cat_comp.containsAll(comp) && comp.size() == conden_cat_comp.size()){

				//System.out.println("inside conden:" + Arrays.toString(conden_cat_comp.toArray()));
		
				conden_cat_ind = y;
				break;
			}
		}

		
		if(conden_cat_ind != -1){

			String conden_big = conden_cat_big[conden_cat_ind].toUpperCase();

			String type = space_split[6].trim();
			//System.out.println("type:" + type);
			int type_ind = -1;

			for(int y = 0; y < llps_func_type.length; y++){

				if(one_line.contains(llps_func_type[y].toUpperCase())){
					
					type_ind = y;
					//System.out.println("inside type:" + type);
					break;
				}
			}
			
			if(uniprot_to_gene.containsKey(uniid)){
			
				LinkedList<String> exist = uniprot_to_gene.get(uniid);
				if(!exist.contains(gene)){

					exist.add(gene);
				}
				uniprot_to_gene.put(uniid,exist);
				
			}else{
				LinkedList<String> exist = new LinkedList();
				exist.add(gene);
				uniprot_to_gene.put(uniid,exist);
			}

			if(uniprot_to_func_type.containsKey(uniid)){
			
				
			}else{
				
				uniprot_to_func_type.put(uniid,type);
			}
			
			if(uniprot_to_conden.containsKey(uniid)){
			
				Boolean[] exist = uniprot_to_conden.get(uniid);
				for(int r = 0; r < value.length; r++){
			
					if(value[r]){
						exist[r] = true;
					}
				}
				uniprot_to_conden.put(uniid,exist);
				
			}else{
			
				uniprot_to_conden.put(uniid,value);
			}
	 
			if(uniprot_to_conden_cat_big.containsKey(uniid)){
			
				Boolean[] exist = uniprot_to_conden_cat_big.get(uniid);
				exist[conden_cat_ind] = new Boolean(true);
				uniprot_to_conden_cat_big.put(uniid,exist);
				
			}else{
			
				Boolean[] value_big = new Boolean[conden_cat_big.length];
				for(int q = 0; q < value_big.length; q++){
				
					value_big[q] = new Boolean(false);
				}
				value_big[conden_cat_ind] = new Boolean(true);
				uniprot_to_conden_cat_big.put(uniid,value_big);
			}

			if(conden_cat_big_to_uniprot.containsKey(conden_big)){
			
				LinkedList<String> exist = conden_cat_big_to_uniprot.get(conden_big);
				if(!exist.contains(uniid)){
					exist.add(uniid);
				}
				conden_cat_big_to_uniprot.put(conden_big,exist);
				
			}else{
			
				LinkedList<String> exist = new LinkedList();
				exist.add(uniid);
				
				conden_cat_big_to_uniprot.put(conden_big,exist);
			}

			
			if(uniprot_to_func_type_per_conden_cat_big.containsKey(uniid)){
			
				Boolean[][] exist = uniprot_to_func_type_per_conden_cat_big.get(uniid);
				exist[conden_cat_ind][type_ind] = new Boolean(true);
				uniprot_to_func_type_per_conden_cat_big.put(uniid,exist);
				
			}else{
			
				Boolean[][] value_big = new Boolean[conden_cat_big.length][llps_func_type.length];
				for(int q = 0; q < value_big.length; q++){
					for(int r = 0; r < llps_func_type.length; r++){
					
						value_big[q][r] = new Boolean(false);
					}
				}
				value_big[conden_cat_ind][type_ind] = new Boolean(true);
				uniprot_to_func_type_per_conden_cat_big.put(uniid,value_big);
			}

			LinkedList<String> pfams = sifts_uniprot_pfam_new.get(uniid);
			

			if(pfams != null){

				Collections.sort((List)pfams);
				if(uniprot_to_pfam_conden.containsKey(uniid)){
				
				}else{
				
					uniprot_to_pfam_conden.put(uniid,pfams);
				}
				//freq

				if(pfams.size() == 1){//one_pfam
					
					if(one_pfam_to_type.containsKey(pfams.get(0))){

						Integer[] exist = one_pfam_to_type.get(pfams.get(0));
					
						for(int y = 0; y < llps_func_type.length; y++){

							if(type.equals(llps_func_type[y].toUpperCase())){

								exist[y] = exist[y]  +new Integer(1);
								break;
							}
						}
						one_pfam_to_type.put(pfams.get(0),exist);

					}else{

						Integer[] exist = new Integer[llps_func_type.length];
					
						for(int y = 0; y < llps_func_type.length; y++){

							if(type.equals(llps_func_type[y].toUpperCase())){

								exist[y] = new Integer(1);
							}else{
								exist[y] = new Integer(0);
							}
						}
						one_pfam_to_type.put(pfams.get(0),exist);

					}

					if(one_pfam_to_conden.containsKey(pfams.get(0))){

						Integer[] exist = one_pfam_to_conden.get(pfams.get(0));
					
						exist[conden_cat_ind]=exist[conden_cat_ind] + new Integer(1);
						one_pfam_to_conden.put(pfams.get(0),exist);

					}else{

						Integer[] exist = new Integer[conden_cat_big.length];
					
						for(int y = 0; y < conden_cat_big.length; y++){

							exist[y] = new Integer(0);
							
						}
						exist[conden_cat_ind] = new Integer(1);
						one_pfam_to_conden.put(pfams.get(0),exist);

					}

					LinkedList<String> temp_dimer = new LinkedList();
					temp_dimer.add(pfams.get(0));
					temp_dimer.add(pfams.get(0));
					Collections.sort((List)temp_dimer);

					if(dimer_pfam_to_type.containsKey(temp_dimer)){

						Integer[] exist = dimer_pfam_to_type.get(temp_dimer);
						
						for(int y = 0; y < llps_func_type.length; y++){

							if(type.equals(llps_func_type[y].toUpperCase())){

								exist[y] = exist[y]  +new Integer(1);
								break;
							}
						}
						dimer_pfam_to_type.put(temp_dimer,exist);

					}else{

						Integer[] exist = new Integer[llps_func_type.length];
						
						for(int y = 0; y < llps_func_type.length; y++){

							if(type.equals(llps_func_type[y].toUpperCase())){

								exist[y] = new Integer(1);
							}else{
								exist[y] = new Integer(0);
							}
						}
						dimer_pfam_to_type.put(temp_dimer,exist);

					}

					if(dimer_pfam_to_conden.containsKey(temp_dimer)){

						Integer[] exist = dimer_pfam_to_conden.get(temp_dimer);
					
						exist[conden_cat_ind]=exist[conden_cat_ind] + new Integer(1);
						dimer_pfam_to_conden.put(temp_dimer,exist);

					}else{

						Integer[] exist = new Integer[conden_cat_big.length];
					
						for(int y = 0; y < conden_cat_big.length; y++){

							exist[y] = new Integer(0);
							
						}
						exist[conden_cat_ind] = new Integer(1);
						dimer_pfam_to_conden.put(temp_dimer,exist);

					}

					


				}else{//dimer

					for(int q = 0; q < pfams.size(); q++){

						LinkedList<String> temp_dimer = new LinkedList();
						temp_dimer.add(pfams.get(q));
						temp_dimer.add(pfams.get(q));
						Collections.sort((List)temp_dimer);

						if(dimer_pfam_to_type.containsKey(temp_dimer)){

							Integer[] exist = dimer_pfam_to_type.get(temp_dimer);
						
							for(int y = 0; y < llps_func_type.length; y++){

								if(type.equals(llps_func_type[y].toUpperCase())){

									exist[y] = exist[y]  +new Integer(1);
									break;
								}
							}
							dimer_pfam_to_type.put(temp_dimer,exist);

						}else{

							Integer[] exist = new Integer[llps_func_type.length];
						
							for(int y = 0; y < llps_func_type.length; y++){

								if(type.equals(llps_func_type[y].toUpperCase())){

									exist[y] = new Integer(1);
								}else{
									exist[y] = new Integer(0);
								}
							}
							dimer_pfam_to_type.put(temp_dimer,exist);

						}


						if(dimer_pfam_to_conden.containsKey(temp_dimer)){

							Integer[] exist = dimer_pfam_to_conden.get(temp_dimer);
						
							exist[conden_cat_ind]=exist[conden_cat_ind] + new Integer(1);
							dimer_pfam_to_conden.put(temp_dimer,exist);

						}else{

							Integer[] exist = new Integer[conden_cat_big.length];
						
							for(int y = 0; y < conden_cat_big.length; y++){

								exist[y] = new Integer(0);
								
							}
							exist[conden_cat_ind] = new Integer(1);
							dimer_pfam_to_conden.put(temp_dimer,exist);

						}

					Combinations comb= new Combinations(pfams.size(),2);
					Iterator<int[]> iter = comb.iterator();
					
														 	
					while(iter.hasNext()){
														 	
						int[] temp_set = iter.next();
						String comb1 = pfams.get(temp_set[0]);
						String comb2 = pfams.get(temp_set[1]);
						LinkedList<String> comb_set = new LinkedList();
												
						comb_set.add(comb1);
						comb_set.add(comb2);
						Collections.sort((List)comb_set);

						if(dimer_pfam_to_type.containsKey(comb_set)){

							Integer[] exist = dimer_pfam_to_type.get(comb_set);
						
							for(int y = 0; y < llps_func_type.length; y++){

								if(type.equals(llps_func_type[y].toUpperCase())){

									exist[y] = exist[y]  +new Integer(1);
								}
							}
							dimer_pfam_to_type.put(comb_set,exist);

						}else{

							Integer[] exist = new Integer[llps_func_type.length];
						
							for(int y = 0; y < llps_func_type.length; y++){

								if(type.equals(llps_func_type[y].toUpperCase())){

									exist[y] = new Integer(1);
								}else{
									exist[y] = new Integer(0);
								}
							}
							dimer_pfam_to_type.put(comb_set,exist);

						}


						if(dimer_pfam_to_conden.containsKey(comb_set)){

							Integer[] exist = dimer_pfam_to_conden.get(comb_set);
						
							exist[conden_cat_ind]=exist[conden_cat_ind] + new Integer(1);
							dimer_pfam_to_conden.put(comb_set,exist);

						}else{

							Integer[] exist = new Integer[conden_cat_big.length];
						
							for(int y = 0; y < conden_cat_big.length; y++){

								exist[y] = new Integer(0);
								
							}
							exist[conden_cat_ind] = new Integer(1);
							dimer_pfam_to_conden.put(comb_set,exist);

						}

						
					}//while

					}//q
				}//dimer else
			}else{
			
				//System.out.println(" sifts_uniprot_pfam_new null error:" + uniid);
			}
		}//not -1
		else{

			System.out.println("conden_type error 7195:"+ one_line);
		}

        }//k

	
	List<String> keys_list = new LinkedList<String>(conden_cat_big_to_uniprot.keySet());

	for(int q = 0; q < keys_list.size(); q++){
	
		String conden_type = keys_list.get(q);
		LinkedList<String> uni_list = conden_cat_big_to_uniprot.get(conden_type);
		for(int w =0; w < uni_list.size(); w++){
			String uni = uni_list.get(w);
			LinkedList<String> pfams = uniprot_to_pfam_conden.get(uni);
			if(pfams != null){
				String pfam_num = new Integer(pfams.size()).toString();

				if(conden_cat_big_to_uniprot_by_num_no_order.containsKey(conden_type)){
					LinkedHashMap<String,LinkedList<String>> uni_num_pfam = conden_cat_big_to_uniprot_by_num_no_order.get(conden_type);

					if(uni_num_pfam.containsKey(pfam_num)){
						LinkedList<String> exist = uni_num_pfam.get(pfam_num);
						if(!exist.contains(uni)){
							exist.add(uni);
						}
						uni_num_pfam.put(pfam_num,exist);
					}else{

						LinkedList<String> exist = new LinkedList();
						exist.add(uni);
						uni_num_pfam.put(pfam_num,exist);
					}
					conden_cat_big_to_uniprot_by_num_no_order.put(conden_type,uni_num_pfam);
				}else{

					LinkedHashMap<String,LinkedList<String>> uni_num_pfam = new LinkedHashMap();

					LinkedList<String> exist = new LinkedList();
					exist.add(uni);
					uni_num_pfam.put(pfam_num,exist);

					conden_cat_big_to_uniprot_by_num_no_order.put(conden_type,uni_num_pfam);
				}
			}
		}//w

	}

	List<String> keys_no_order = new LinkedList<String>(conden_cat_big_to_uniprot_by_num_no_order.keySet());
	
	for(int i = 0; i < keys_no_order.size(); i++){

		LinkedHashMap<String,LinkedList<String>> hash = conden_cat_big_to_uniprot_by_num_no_order.get(keys_no_order.get(i));
		List<String> keys_pfam_num = new LinkedList<String>(hash.keySet());

		double[] no_order_double = new double[keys_pfam_num.size()];
		//System.out.println("keys_no_order.get(i):" +keys_no_order.get(i));
		//if(!keys_no_order.get(i).equals("null") && !keys_no_order.get(i).equals("NaN")){
		for(int j = 0; j < keys_pfam_num.size(); j++){
			int size = new Integer(keys_pfam_num.get(j)).intValue();
			no_order_double[j] = size*1.0;
			
		}
		MathArrays.sortInPlace(no_order_double, MathArrays.OrderDirection.INCREASING);
		LinkedHashMap<String,LinkedList<String>> hash_new = new LinkedHashMap();
		for(int j =0; j < no_order_double.length; j++){

			LinkedList<String> uni_list_new =  hash.get(new Integer((int)no_order_double[j]).toString());
			hash_new.put(new Integer((int)no_order_double[j]).toString(), uni_list_new);
		}
		conden_cat_big_to_uniprot_by_num.put(keys_no_order.get(i),hash_new);
	}
	
	List<LinkedList<String>> keys_dimer_pfam_to_conden = new LinkedList<LinkedList<String>>(dimer_pfam_to_conden.keySet());
	for(int i = 0; i < keys_dimer_pfam_to_conden.size(); i++){

		LinkedList<String> keys_dimer_pfam = keys_dimer_pfam_to_conden.get(i);
		Integer[] exist =dimer_pfam_to_conden.get(keys_dimer_pfam);
		//System.out.println("dimer_pfam_to_conden:" + Arrays.toString(keys_dimer_pfam.toArray()) + ":" + Arrays.toString(exist));
	}

	List<LinkedList<String>> keys_dimer_pfam_to_type = new LinkedList<LinkedList<String>>(dimer_pfam_to_type.keySet());
	for(int i = 0; i < keys_dimer_pfam_to_type.size(); i++){

		LinkedList<String> keys_dimer_pfam = keys_dimer_pfam_to_type.get(i);
		Integer[] exist =dimer_pfam_to_type.get(keys_dimer_pfam);
		//System.out.println("dimer_pfam_to_type:" + Arrays.toString(keys_dimer_pfam.toArray()) + ":" + Arrays.toString(exist));
	}

	List<String> keys_one_pfam_to_conden = new LinkedList<String>(one_pfam_to_conden.keySet());
	for(int i = 0; i < keys_one_pfam_to_conden.size(); i++){

		String keys_dimer_pfam = keys_one_pfam_to_conden.get(i);
		Integer[] exist =one_pfam_to_conden.get(keys_dimer_pfam);
		//System.out.println("one_pfam_to_conden:" + keys_dimer_pfam + ":" + Arrays.toString(exist));
	}

	List<String> keys_one_pfam_to_type = new LinkedList<String>(one_pfam_to_type.keySet());
	for(int i = 0; i < keys_one_pfam_to_type.size(); i++){

		String keys_dimer_pfam = keys_one_pfam_to_type.get(i);
		Integer[] exist =one_pfam_to_type.get(keys_dimer_pfam);
		//System.out.println("one_pfam_to_type:" + keys_dimer_pfam + ":" + Arrays.toString(exist));
	}
		

	System.out.println("uniprot_to_func_type:" + uniprot_to_func_type.size());
	System.out.println("uniprot_to_gene:" + uniprot_to_gene.size());
	System.out.println("uniprot_to_func_type_per_conden_cat_big:" + uniprot_to_func_type_per_conden_cat_big.size());
	System.out.println("uniprot_to_pfam_conden:" + uniprot_to_pfam_conden.size());
	System.out.println("uniprot_to_conden:" + uniprot_to_conden.size());
	System.out.println("uniprot_to_conden_cat_big:" + uniprot_to_conden_cat_big.size());
	System.out.println("one_pfam_to_type:" + one_pfam_to_type.size());
	System.out.println("one_pfam_to_conden:" + one_pfam_to_conden.size());
	System.out.println("dimer_pfam_to_type:" + dimer_pfam_to_type.size());
	System.out.println("dimer_pfam_to_conden:" + dimer_pfam_to_conden.size());

    }//method

/////////////////////////////////////////////////////////////////

static String[] path_big_types = {"hormone","metabolic_mol","Hydper","kinase","light","cell_cell","chloroplast","pathogen","apoptot","mitochondria","hypoxia","osmosensory"};

static String[][] path_types = {{"abscis","auxin","brassino","cytokinin","ethylene","gibberell","hormone","jasmon","salicylic","SREBP"},{"glucose","lipopolysaccharide","phosphatidylinositol","sugar"},{"hydrogen peroxide"},{"G protein-coupled","kinase"},{"light"},{"cell surface","pattern recognition"},{"chloroplast"},{"immune","pathogen","sphingosine"},{"apoptot"},{"mitochondria"},{"hypoxia"},{"osmosensory"}};

static String[] llps_types = {"llps","non-llps"};



///////////////////////////////////////////////////////////

static LinkedHashMap<String,LinkedList<String>> pdb_to_uniprot;
	static LinkedHashMap<String,LinkedList<String>> uniprot_to_pdb;

    void  map_pdb_to_uniprot()  throws IOException{

	pdb_to_uniprot = new LinkedHashMap();
	uniprot_to_pdb = new LinkedHashMap();

	String path = "data/uniprot-pdb.tsv.only.uni.pdb";
 	
	pdb_to_uniprot = new LinkedHashMap();
	Pattern space_pattern = Pattern.compile("\\s+");
	Pattern tab_pattern = Pattern.compile("\\t+");
	Pattern comma_pattern = Pattern.compile(",");
	Pattern colon_pattern = Pattern.compile(":");
	Pattern left_pattern = Pattern.compile("left");
	Pattern semi_pattern = Pattern.compile(";");

	List<String> lines  = FileUtils.readLines(new File(path));
	
	//A0A022MRT4 6SIW;6SIX;6SIY;6SIZ;6TM4;				
	for(int k = 0; k <lines.size(); k++){
				
		String one_line = lines.get(k).toUpperCase();
		String[] space_split = space_pattern.split(one_line);
		String uniprot = space_split[0].trim();
		String pdbs = space_split[1].trim();
		String[] semi_split = semi_pattern.split(pdbs);
		LinkedList<String> pdb_list = new LinkedList();

		for(int q = 0; q < semi_split.length; q++){

			String pdb = semi_split[q].trim();
			pdb_list.add(pdb);
			if(pdb_to_uniprot.containsKey(pdb)){

				LinkedList<String> exist = pdb_to_uniprot.get(pdb);
				if(!exist.contains(uniprot)){
					exist.add(uniprot);
				}
				pdb_to_uniprot.put(pdb,exist);

			}else{
				LinkedList<String> exist = new LinkedList();
				exist.add(uniprot);
				
				pdb_to_uniprot.put(pdb,exist);
			}
		}
		uniprot_to_pdb.put(uniprot,pdb_list);
	}//k

	System.out.println("uniprot_to_pdb:"+uniprot_to_pdb.size());
	System.out.println("pdb_to_uniprot:"+pdb_to_uniprot.size());
		
    }

static LinkedHashMap<String,LinkedList<String>> sifts_uniprot_pfam_new;
static LinkedHashMap<LinkedList<String>,LinkedList<String>> sifts_nr_pfam_uniprot_new;

void  map_sifts_pdb_pfam()  throws IOException{

	String path = "data/PDB.pfam.id";

	Pattern space_pattern = Pattern.compile("\\s+");
	Pattern tab_pattern = Pattern.compile("\\t+");
	Pattern comma_pattern = Pattern.compile(",");
	Pattern colon_pattern = Pattern.compile(":");

	
	List<String> lines  = FileUtils.readLines(new File(path));
	
	sifts_uniprot_pfam_new = new LinkedHashMap();
	sifts_nr_pfam_uniprot_new = new LinkedHashMap();
					
	for(int k = 0; k < lines.size(); k++){
				
		String one_line = lines.get(k);
		String[] space_split = space_pattern.split(one_line);
		String pdbid = space_split[0].trim();
		LinkedList<String> uniid_list = pdb_to_uniprot.get(pdbid.toUpperCase());

		if(uniid_list != null){

			for(int p = 0; p < uniid_list.size(); p++){

				String uniid = uniid_list.get(p).toUpperCase();

				String pfam = space_split[1].trim();
				
				
				if(sifts_uniprot_pfam_new.containsKey(uniid)){
				
					LinkedList<String> temp_pfamlist = sifts_uniprot_pfam_new.get(uniid);
					
					if(!temp_pfamlist.contains(pfam)){
					
						temp_pfamlist.add(pfam);
					}
					
					sifts_uniprot_pfam_new.put(uniid, temp_pfamlist);
				
				}else{
				
					LinkedList<String> temp_pfamlist = new LinkedList();
					
					temp_pfamlist.add(pfam);
					sifts_uniprot_pfam_new.put(uniid, temp_pfamlist);
				}		
			}//p
			
			
		}//not null
		

        }//k

	List<String> keys_list = new LinkedList<String>(sifts_uniprot_pfam_new.keySet());

	for (int a = 0; a < keys_list.size(); a++){

			String uniid = keys_list.get(a);

			LinkedList<String> nr_pfam = sifts_uniprot_pfam_new.get(uniid);

			//redundant
			
			Set<String> pfams_h_inv = new LinkedHashSet<>();
			pfams_h_inv.addAll((List)nr_pfam);
									
			// Clear the list
			((List)nr_pfam).clear();
															  
			// add the elements of set
			// with no duplicates to the list
			((List)nr_pfam).addAll(pfams_h_inv);
			Collections.sort((List)nr_pfam);
					

			if(sifts_nr_pfam_uniprot_new.containsKey(nr_pfam)){
			
				LinkedList<String> temp_unilist = sifts_nr_pfam_uniprot_new.get(nr_pfam);
				
				if(!temp_unilist.contains(uniid)){
				
					temp_unilist.add(uniid);
				}
				
				sifts_nr_pfam_uniprot_new.put(nr_pfam, temp_unilist);
			
			}else{
			
				LinkedList<String> temp_unilist = new LinkedList();
				
				temp_unilist.add(uniid);
				sifts_nr_pfam_uniprot_new.put(nr_pfam, temp_unilist);
			}
	}
	System.out.println("sifts_uniprot_pfam_new:" + sifts_uniprot_pfam_new.size());
	System.out.println("sifts_nr_pfam_uniprot_new:" + sifts_nr_pfam_uniprot_new.size());
    }//method



static LinkedHashMap<String,String> ensp_enst;
static LinkedHashMap<String,String> ensg_enst;

void map_ensp_enst() throws IOException{

 	ensp_enst = new LinkedHashMap();
	ensg_enst = new LinkedHashMap();
 	
  	Pattern space_pattern = Pattern.compile("\\s+");
	Pattern tab_pattern = Pattern.compile("\\t+");
	Pattern comma_pattern = Pattern.compile(",");
	Pattern colon_pattern = Pattern.compile(":");
	
	String input="data/human/map_ensg_enst_ensp.sort.uniq";
	//ENSG00000000003 ENST00000373020 ENSP00000362111
	
	List<String> lines  = FileUtils.readLines(new File(input));
	
	
	for(int q= 0; q < lines.size(); q++){
	
		String one_line = lines.get(q).trim();
		
		LinkedHashMap<String,String> hash = new LinkedHashMap();
		
		String[] colon_split = colon_pattern.split(one_line);
		String ensg = colon_split[1];
		String enst = colon_split[0];
		String ensp = colon_split[2];
		////System.out.println("ensg:"+ensg+":enst:"+enst+":ensp:"+ensp);
		ensg_enst.put(ensg,enst);
		ensp_enst.put(ensp,enst);
		

	}//q

	System.out.println("ensp_enst.size():"+ensp_enst.size());
	System.out.println("ensg_enst.size():"+ensg_enst.size());

}//method


static LinkedHashMap<String,LinkedList<String>> map_pfam_human_gene;
static LinkedList<LinkedList<String>> pfam_human_gene_list;
 
 void map_pfam_to_human_gene() throws IOException{
 
 	System.out.println("map_pfam_to_human_gene():" );
 
	Pattern space_pattern = Pattern.compile("\\s+");
	Pattern tab_pattern = Pattern.compile("\\t+");
	Pattern comma_pattern = Pattern.compile(",");
	Pattern colon_pattern = Pattern.compile(":");

	
	map_pfam_human_gene= new LinkedHashMap();
	pfam_human_gene_list= new LinkedList();
	
 
 	String path = "data/human/knownToPfam.txt";
	List<String> lines  = FileUtils.readLines(new File(path));
					
	for(int k = 0; k < lines.size(); k++){
	
		String one_line = lines.get(k).toUpperCase();
		String[] space_split = space_pattern.split(one_line);
		String enst = space_split[0].trim();
		enst = enst.substring(0,enst.indexOf("."));
		String pfam = space_split[1].trim();
		
		if(map_pfam_human_gene.containsKey(enst)){
		
			LinkedList<String> exist = map_pfam_human_gene.get(enst);
			exist.add(pfam);
			Collections.sort((List)exist);
			map_pfam_human_gene.put(enst,exist);
			
		}else{
		
			LinkedList<String> new_list = new LinkedList();
			new_list.add(pfam);
			map_pfam_human_gene.put(enst,new_list);
		}
				
		
	}
	
	
	List<String> keys_list = new LinkedList<String>(map_pfam_human_gene.keySet());
	
	for(int i = 0; i < keys_list.size(); i++){
	
		pfam_human_gene_list.add(map_pfam_human_gene.get(keys_list.get(i)));
	}
	
	System.out.println("map_pfam_human_gene.size():" + map_pfam_human_gene.size());
			

}//method

/////////////////


static String[][] human_tf_family = {
{"AP-2"},{"ARID/BRIGHT","ARID/BRIGHT,RFX"},{"AT_hook"},{"BED_ZF","BED_ZF,C2H2_ZF"},{"bHLH","bHLH,T-box"},{"bZIP","bZIP,C2H2_ZF"},{"C2H2_ZF","C2H2_ZF,Homeodomain","C2H2_ZF,MADF","C2H2_ZF,Myb/SANT","C2HC_ZF"},{"CBF/NF-Y"},{"CG-1"},{"CSD"},{"E2F"},{"FLYWCH"},{"GATA"},{"Homeodomain","Homeodomain,Paired_box","Homeodomain,POU","CUT,Homeodomain"},{"HSF"},{"MADF"},{"MADS_box"},{"MBD"},{"mTERF"},{"Myb/SANT"},{"NFX"},{"SAND"},{"Sox"},{"TBP"},{"TCR/CxC"},{"Unknown"}

};
static String[] tf_family_name = {"AP","ARID","hook","BED","HLH","bZIP","C2H2","CBF","CG","CSD","E2F","FLYWCH","GATA","Homeodomain","HSF","MADF","MADS","MBD","mTERF","Myb","NFX","SAND","Sox","TBP","TCR","Unknown"};


static LinkedHashMap<String, LinkedList<String>> map_human_tf_family;
static LinkedHashMap<String, LinkedList<String>> map_human_family_tf;

void map_tf_family() throws IOException{

System.out.println("map_tf_family()");


 	map_human_tf_family = new LinkedHashMap();
 	map_human_family_tf= new LinkedHashMap();
 	
 	
  	Pattern space_pattern = Pattern.compile(" ");
	Pattern tab_pattern = Pattern.compile("\\t+");
	Pattern comma_pattern = Pattern.compile(",");
	Pattern colon_pattern = Pattern.compile(":");
	Pattern semicolon_pattern = Pattern.compile(";");
	
	
	String input="data/human/TF.TF.family.sort.uniq.two.cols";
	
	List<String> lines  = FileUtils.readLines(new File(input));
	
	for(int q= 0; q < lines.size(); q++){
	
		String one_line = lines.get(q).trim();
		
		if(!one_line.equals("")){
		
			String[] one_line_tab = space_pattern.split(one_line);
			String gene = one_line_tab[0].toUpperCase();
			String[] families = comma_pattern.split(one_line_tab[1].toUpperCase());
			LinkedList<String> temp = new LinkedList();

			for(int w = 0; w < families.length; w++){
			
				if(!families[w].equals("")){
					temp.add(families[w]);
				}
			}
			
			if(!map_human_tf_family.containsKey(gene)){
				
					
					map_human_tf_family.put(gene, temp);	
					
							
			}else{
					//System.out.println(q + "double key error map_human_tf_family:" + gene +","+ common_tf_family);
			}
			
			for(int l = 0; l < temp.size(); l++){
	
				if(!map_human_family_tf.containsKey(temp.get(l))){
						
					LinkedList<String> new_array = new LinkedList();
					new_array.add(gene);	
					map_human_family_tf.put(temp.get(l),new_array);
								
				}else{
					LinkedList<String> exist = map_human_family_tf.get(temp.get(l));	
					exist.add(gene);
					map_human_family_tf.put(temp.get(l),exist);
						
				}
			}
			
		}//if
			

	}//q
	
	System.out.println("map_human_family_tf.size():"+map_human_family_tf.size());
	System.out.println("map_human_tf_family.size():"+map_human_tf_family.size());
	
}//method


static LinkedList<String> cis_bp;
static LinkedList<String> cis_bp_ensg;

void get_cis_bp_tf() throws IOException{

	cis_bp = new LinkedList();
	cis_bp_ensg= new LinkedList();
	String input="data/human/human_TF_list.sort.uniq.gene.only";
	
	List<String> lines  = FileUtils.readLines(new File(input));
	for(int q= 0; q < lines.size(); q++){
	
		String one_line = lines.get(q).trim().toUpperCase();
		cis_bp.add(one_line);
		cis_bp_ensg.add(gene_name_to_ensg.get(one_line));
	}
}


static LinkedHashMap<String,LinkedList<String>> string_db_tf_co_human;


void make_tf_cofactor_list() throws IOException{

	Pattern colon_pattern = Pattern.compile(":");
	Pattern tab_pattern = Pattern.compile("\\t");
	Pattern space_pattern = Pattern.compile("\\s+");
	string_db_tf_co_human = new LinkedHashMap();

	
	String path = "data/human/physical.protein.inter.cutoff.500.id.only";
	//String tf_path = "/media/centos2/7eb36bdc-3f99-4b9e-a42b-dea20251d497/abstract_submission_peach/TF_TFOFATOR_list/tf";
	//List<String> tf_list  = FileUtils.readLines(new File(tf_path));

    	List<String> tf_lines  = FileUtils.readLines(new File("/run/media/centos2/string_db_ensp_from_cisbp_tf.ensp"));
    
    
  
		
    List<String> lines  = FileUtils.readLines(new File(path));
	
	for(int q= 0; q < lines.size(); q++){
	
	
		String one_line = lines.get(q).trim();
		String[] split_str = space_pattern.split(one_line);
		
		String tf_ensp = split_str[0];
		String cofactor_ensp = split_str[1];
		String tf_gene ="";
		
		if(tf_lines.contains(tf_ensp)){
		
			//System.out.println("tf_lines.contains(tf_ensp):"+tf_ensp);
		
			
			if(!ensg_ensp_enst.containsKey(tf_ensp)){
			
				System.out.println("error no tf_ensp:"+tf_ensp);
			
			}else{
			
				LinkedHashMap<String,String> hash = ensg_ensp_enst.get(tf_ensp);
				List<String> keys_list = new LinkedList<String>(hash.keySet());
				if(keys_list.size()>1){
				
					//System.out.println("error duplicate ensp to enst");
				}
				
				
				String tf_enst = keys_list.get(0);
				String tf_ensg = hash.get(tf_enst);
				tf_gene = ensg_to_gene_name.get(tf_ensg);
				
				//System.out.println("else tf_gene:"+tf_gene);
				
				if(!ensg_ensp_enst.containsKey(cofactor_ensp)){
				
					System.out.println("error no cofactor_ensp:"+cofactor_ensp);
				
				}else{
				
					LinkedHashMap<String,String> cofactor_hash = ensg_ensp_enst.get(cofactor_ensp);
					List<String> cofactor_keys_list = new LinkedList<String>(cofactor_hash.keySet());
					if(cofactor_keys_list.size()>1){
					
						//System.out.println("error cofactor_ duplicate ensp to enst");
					}
					
					
					String cofactor_enst = cofactor_keys_list.get(0);
					String cofactor_ensg = cofactor_hash.get(cofactor_enst);
					String cofactor_gene = ensg_to_gene_name.get(cofactor_ensg);
					
					if(string_db_tf_co_human.containsKey(tf_gene)){
					
						LinkedList<String> exist = string_db_tf_co_human.get(tf_gene);
						if(!exist.contains(cofactor_gene)){
						
							exist.add(cofactor_gene);
						}
						string_db_tf_co_human.put(tf_gene,exist);
						
					}else{
					
						LinkedList<String> exist = new LinkedList();
						exist.add(cofactor_gene);
						string_db_tf_co_human.put(tf_gene,exist);
						
					}
					
					
				}//else
				
			}//else

		}else if(tf_lines.contains(cofactor_ensp)){
		
			if(!ensg_ensp_enst.containsKey(cofactor_ensp)){
				
					System.out.println("error no cofactor_ensp:"+cofactor_ensp);
				
			}else{
				
					LinkedHashMap<String,String> cofactor_hash = ensg_ensp_enst.get(cofactor_ensp);
					List<String> cofactor_keys_list = new LinkedList<String>(cofactor_hash.keySet());
					if(cofactor_keys_list.size()>1){
					
						//System.out.println("error cofactor_ duplicate ensp to enst");
					}
					
					
					String cofactor_enst = cofactor_keys_list.get(0);
					String cofactor_ensg = cofactor_hash.get(cofactor_enst);
					String cofactor_gene = ensg_to_gene_name.get(cofactor_ensg);
					
					if(string_db_tf_co_human.containsKey(cofactor_gene)){
						
							LinkedList<String> exist = string_db_tf_co_human.get(cofactor_gene);
							if(!exist.contains(tf_gene)){
							
								exist.add(tf_gene);
							}
							string_db_tf_co_human.put(cofactor_gene,exist);
							
					}else{
						
							LinkedList<String> exist = new LinkedList();
							exist.add(tf_gene);
							string_db_tf_co_human.put(cofactor_gene,exist);
							
					}
						
						
			}//else
					
		}	
				
			
 	}//q
 	List<String> tf_keys_list = new LinkedList<String>(string_db_tf_co_human.keySet());
}


static LinkedHashMap<String,LinkedList<String>> tfco_lncrna_human;

void  map_lnc_tfco_human()  throws IOException{

	Pattern colon_pattern = Pattern.compile(":");
	Pattern tab_pattern = Pattern.compile("\\t");
	Pattern space_pattern = Pattern.compile("\\s+");

	//System.out.println("map_lnc_tfco_human():" );
	
	LinkedList<String> all_enst = new LinkedList();
	
	tfco_lncrna_human=new LinkedHashMap();
	
	String path = "data/human/lncRNA_string_tfco_intersect.desc";
 	//237839
	List<String> lines  = FileUtils.readLines(new File(path));
	
				
	for(int k = 0; k < lines.size(); k++){
	//PCA3 ADAR
				
		String one_line = lines.get(k).toUpperCase();
		
		String[] space_split = space_pattern.split(one_line);
		
		String lnc = space_split[0].trim();
		String tfco = space_split[1].trim();
		
		
		if(tfco_lncrna_human.containsKey(tfco)){
		
			LinkedList<String> exist = tfco_lncrna_human.get(tfco);
			exist.add(lnc);
			tfco_lncrna_human.put(tfco,exist);
			
		}else{
		
			LinkedList<String> new_list = new LinkedList();
			new_list.add(lnc);
			tfco_lncrna_human.put(tfco,new_list);
		}
		
		
	}//
		
	
	System.out.println("tfco_lncrna_human.size():" + tfco_lncrna_human.size());
}


static LinkedHashMap<String,String> ensg_to_gene_name;
 static  LinkedHashMap<String,String> gene_name_to_ensg;
 
void  map_ensg_to_gene_name()  throws IOException{

	//System.out.println("map_ensg_to_gene_name():" );

	Pattern space_pattern = Pattern.compile("\\s+");
	Pattern colon_pattern = Pattern.compile(":");
	
	ensg_to_gene_name= new LinkedHashMap();
	gene_name_to_ensg=new LinkedHashMap();
 
 	String path = "data/human/homo.sapiens.38.ensg_gene_map";
 	//237839
	List<String> lines  = FileUtils.readLines(new File(path));
	//ENSG00000222623:RNU6-1100P
	//NSG00000279928:DDX11L17

					
	for(int k = 0; k < lines.size(); k++){
				
		String one_line = lines.get(k).toUpperCase();
		String[] space_split = colon_pattern.split(one_line);
		String ensg = space_split[0].trim();
		String gene = space_split[1].trim();
		
		ensg_to_gene_name.put(ensg,gene);
		gene_name_to_ensg.put(gene,ensg);
		
	}
	//System.out.println("ensg_to_gene_name.size():" + ensg_to_gene_name.size());
	
	//System.out.println("gene_name_to_ensg:" +gene_name_to_ensg.size());
}

static LinkedHashMap<String,String> uni_to_gene_name_human;
 static LinkedHashMap<String,String> gene_name_to_uni_human;
 
void  map_uni_to_gene_name()  throws IOException{

	//System.out.println("map_ensg_to_gene_name():" );

	Pattern space_pattern = Pattern.compile("\\s+");
	Pattern colon_pattern = Pattern.compile(":");
	
	uni_to_gene_name_human= new LinkedHashMap();
	gene_name_to_uni_human=new LinkedHashMap();
 
 	String path = "data/human/HUMAN_9606_idmapping.dat.gene_name";
 	//237839
	List<String> lines  = FileUtils.readLines(new File(path));
	//A5YRU3	MUC1
	//F6K7K3	ABHD5
	
					
	for(int k = 0; k < lines.size(); k++){
				
		String one_line = lines.get(k).toUpperCase();
		String[] space_split = space_pattern.split(one_line);
		String uni = space_split[0].trim();
		String gene = space_split[1].trim();
		
		uni_to_gene_name_human.put(uni,gene);
		gene_name_to_uni_human.put(gene,uni);
		
	}
	System.out.println("uni_to_gene_name_human:" + uni_to_gene_name_human.size());
	
	System.out.println("gene_name_to_uni_human:" +gene_name_to_uni_human.size());
}

static LinkedHashMap<String,LinkedHashMap<String,String>> ensg_ensp_enst;

void map_ensg_enst_ensp() throws IOException{

 	ensg_ensp_enst = new LinkedHashMap();
 	
  	Pattern space_pattern = Pattern.compile("\\s+");
	Pattern tab_pattern = Pattern.compile("\\t+");
	Pattern comma_pattern = Pattern.compile(",");
	Pattern colon_pattern = Pattern.compile(":");
	
	String input="data/map_ensg_enst_ensp.sort.uniq";
	//ENSG00000000003 ENST00000373020 ENSP00000362111
	
	List<String> lines  = FileUtils.readLines(new File(input));
	
	
	for(int q= 0; q < lines.size(); q++){
	
		String one_line = lines.get(q).trim();
		
		LinkedHashMap<String,String> hash = new LinkedHashMap();
		
		String[] colon_split = colon_pattern.split(one_line);
		String ensg = colon_split[1];
		String enst = colon_split[0];
		String ensp = colon_split[2];
		////System.out.println("ensg:"+ensg+":enst:"+enst+":ensp:"+ensp);
		hash.put(enst,ensg);
		ensg_ensp_enst.put(ensp,hash);
		

	}//q

	System.out.println("ensg_ensp_enst.size():"+ensg_ensp_enst.size());
}//method

static LinkedHashMap<String, String> pfam_clan_map_only;
static  LinkedHashMap<String, String> pfam_domain;
static LinkedHashMap<String, String> domain_pfam;
static LinkedHashMap<String, LinkedList<String>> clan_to_pfam;




void map_pfam_clans_only() throws IOException{

	System.out.println("map_pfam_clans_only():" );

	pfam_clan_map_only = new LinkedHashMap();
 	clan_to_pfam = new LinkedHashMap();
 	pfam_domain = new LinkedHashMap();
 	domain_pfam = new LinkedHashMap();

 	
  	Pattern space_pattern = Pattern.compile("\\s+");
	Pattern tab_pattern = Pattern.compile("\\t+");
	Pattern comma_pattern = Pattern.compile(",");
	Pattern colon_pattern = Pattern.compile(":");
	
	String input="data/Pfam-A.clans.tsv";
	
	List<String> lines  = FileUtils.readLines(new File(input));
	
	for(int q= 0; q < lines.size(); q++){
	
		String one_line = lines.get(q).trim().toUpperCase();
		
		if(!one_line.equals("")){
		
			String[] one_line_tab = tab_pattern.split(one_line);
			
			if(one_line_tab.length != 5){
			
				//System.out.println("tab error:"+one_line_tab.length + ":" +q + ":"+one_line);
			}
			String pre_clan_id = "";
			String clan ="";
			if(one_line_tab[1].trim().equals("NA")){
			
				
				one_line_tab[1]=one_line_tab[0].toUpperCase();
				clan = one_line_tab[0].toUpperCase();
			
			}else{
			
				clan = one_line_tab[1].toUpperCase();
				
			
			}
			String pfamid = one_line_tab[0].toUpperCase();
			String domain = one_line_tab[3].toUpperCase();
			
			////////////System.out.println("pfamid:" + pfamid + ":"+ name);
			
			if(!pfam_clan_map_only.containsKey(pfamid)){
				
				//pfam_clan_map_only.put(pfamid, one_line_tab[1]+":"+one_line_tab[2]+":"+one_line_tab[3]+":"+one_line_tab[4]);
				pfam_clan_map_only.put(pfamid, clan);	
				
						
			}else{
				//System.out.println(q + ":double key error:" + pfamid+":"+one_line);
			}
			
			
			
			pfam_domain.put(pfamid,domain);
			domain_pfam.put(domain,pfamid);
			
			if(clan_to_pfam.containsKey(clan)){
			
				LinkedList<String> exist = clan_to_pfam.get(clan);
				exist.add(pfamid);
				Collections.sort((List)exist);
				clan_to_pfam.put(clan,exist);
			}else{
			
				LinkedList<String> new_list = new LinkedList();
				new_list.add(pfamid);
				clan_to_pfam.put(clan,new_list);
			
			}	
					
				
			
		}//if
			

}//q
System.out.println("clan_to_pfam:" + clan_to_pfam.size());
}


}//inner class


}//main class
